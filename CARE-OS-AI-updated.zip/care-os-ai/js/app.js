// ═══════════════════════════════════════════════
// DATA
// ═══════════════════════════════════════════════
const DATA = {
  copilot: [],
  doctors: [
    { id:1, name:"Dr. Petra Winsburry", specialty:"General Medicine", status:"Available", hours:"09:00–12:00 PM", patients:150, appointments:320, phone:"+1 555-234-5678", email:"petra.wins@careos.ai", avatar:"PW", about:"Dr. Winsburry is a board-certified general practitioner with 14 years of experience in preventive medicine and chronic disease management." },
    { id:2, name:"Dr. Ameena Karim", specialty:"Orthopedics", status:"Unavailable", hours:"10:00–02:00 PM", patients:98, appointments:210, avatar:"AK", phone:"+1 555-234-5679", email:"a.karim@careos.ai", about:"Specialist in musculoskeletal disorders with expertise in joint replacement and sports medicine rehabilitation." },
    { id:3, name:"Dr. Olivia Martinez", specialty:"Cardiology", status:"Available", hours:"10:00–01:00 PM", patients:134, appointments:287, avatar:"OM", phone:"+1 555-234-5680", email:"o.martinez@careos.ai", about:"Interventional cardiologist with a focus on heart failure management, echocardiography, and cardiac catherization." },
    { id:4, name:"Dr. Damian Sanchez", specialty:"Pediatrics", status:"Available", hours:"11:00–02:00 PM", patients:201, appointments:445, avatar:"DS", phone:"+1 555-234-5681", email:"d.sanchez@careos.ai", about:"Dedicated pediatrician with 10 years of experience in childhood development, vaccinations, and pediatric emergency care." },
    { id:5, name:"Dr. Chloe Harrington", specialty:"Dermatology", status:"Unavailable", hours:"09:00–01:00 PM", patients:89, appointments:176, avatar:"CH", phone:"+1 555-234-5682", email:"c.harrington@careos.ai", about:"Dermatologist specializing in acne, eczema, psoriasis, and skin cancer screening procedures." },
    { id:6, name:"Dr. Emily Smith", specialty:"General Medicine", status:"Available", hours:"08:00–12:00 PM", patients:112, appointments:234, avatar:"ES", phone:"+1 555-234-5683", email:"e.smith@careos.ai", about:"Family medicine physician committed to holistic patient care and preventive health strategies for all ages." },
    { id:7, name:"Dr. Samuel Thompson", specialty:"Cardiology", status:"Available", hours:"01:00–05:00 PM", patients:145, appointments:312, avatar:"ST", phone:"+1 555-234-5684", email:"s.thompson@careos.ai", about:"Cardiologist specializing in arrhythmia management, pacemaker implantation, and cardiac rehabilitation programs." },
    { id:8, name:"Dr. Sarah Johnson", specialty:"Pediatrics", status:"Available", hours:"09:00–01:00 PM", patients:178, appointments:389, avatar:"SJ", phone:"+1 555-234-5685", email:"s.johnson@careos.ai", about:"Experienced pediatrician focused on neonatal care, developmental pediatrics, and childhood nutrition." }
  ],
  patients: [
    { id:301, name:"Caren G. Simpson", dob:"1989-06-15", gender:"Female", age:35, occupation:"Software Engineer", insurance:"HealthPlus", phone:"+1 555-123-4567", email:"caren.simpson@example.com", address:"123 Maple Street, Springfield, IL, USA", emergency:"John Simpson — Brother +1 555-234-5678", status:"Active", membership:"Blue Member", height:"5 ft 1.5 in", weight:"140 lbs", bmi:26.5, heartRate:72, bp:"120/80 mmHg", sugar:90, cholesterol:180, respiratory:16, hemoglobin:14, allergies:["Penicillin","Latex","Shellfish"], conditions:["Hypertension","Asthma","Hypothyroidism"], meds:["Lisinopril","Albuterol Inhaler","Levothyroxine"], notes:[{date:"Jun 8, 2027",title:"Asthma",text:"Ensure the patient always carries an inhaler and avoids allergy triggers."},{date:"Apr 9, 2028",title:"Hypertension",text:"Advise the patient to engage in light exercise and monitor blood pressure weekly."},{date:"Oct 10, 2027",title:"Type 2 Diabetes",text:"Patient needs to monitor blood sugar levels regularly & follow the recommended diet."}] },
    { id:302, name:"Edgar Warrow", dob:"1975-03-22", gender:"Male", age:49, occupation:"Teacher", insurance:"MedCare", phone:"+1 555-234-5679", email:"edgar.warrow@example.com", address:"456 Oak Ave, Chicago, IL, USA", emergency:"Mary Warrow — Wife +1 555-345-6789", status:"Active", membership:"Silver Member", height:"5 ft 11 in", weight:"185 lbs", bmi:25.8, heartRate:68, bp:"130/85 mmHg", sugar:105, cholesterol:210, respiratory:18, hemoglobin:15.2, allergies:["Aspirin"], conditions:["Cardiac Arrhythmia"], meds:["Metoprolol","Warfarin"], notes:[{date:"Mar 5, 2028",title:"Cardiac Consultation",text:"Patient requires monthly ECG monitoring and strict medication adherence."}] },
    { id:303, name:"Ocean Jane Lupre", dob:"2015-09-10", gender:"Female", age:9, occupation:"Student", insurance:"KidsCare", phone:"+1 555-345-6780", email:"lupre.family@example.com", address:"789 Pine Rd, Oak Park, IL, USA", emergency:"Sam Lupre — Father +1 555-456-7890", status:"Active", membership:"Bronze Member", height:"4 ft 2 in", weight:"65 lbs", bmi:16.1, heartRate:88, bp:"95/60 mmHg", sugar:82, cholesterol:140, respiratory:22, hemoglobin:12.8, allergies:["Peanuts","Dairy"], conditions:["Asthma"], meds:["Montelukast"], notes:[{date:"Jul 15, 2028",title:"Pediatric Check-Up",text:"Growth is on track. Continue current asthma management plan."}] },
    { id:304, name:"Shane Riddick", dob:"1990-12-05", gender:"Male", age:33, occupation:"Architect", insurance:"BlueCross", phone:"+1 555-456-7891", email:"sridddick@example.com", address:"321 Elm St, Evanston, IL, USA", emergency:"Lisa Riddick — Wife +1 555-567-8901", status:"Inactive", membership:"Gold Member", height:"6 ft 1 in", weight:"195 lbs", bmi:25.7, heartRate:74, bp:"118/78 mmHg", sugar:95, cholesterol:165, respiratory:16, hemoglobin:14.5, allergies:["Sulfa"], conditions:["Skin Allergy","Eczema"], meds:["Hydrocortisone Cream","Cetirizine"], notes:[{date:"Jun 20, 2028",title:"Skin Allergy",text:"Avoid known allergens. Apply prescribed cream twice daily."}] },
    { id:305, name:"Queen Lawnston", dob:"1965-07-30", gender:"Female", age:63, occupation:"Retired", insurance:"Medicare", phone:"+1 555-567-8902", email:"q.lawnston@example.com", address:"654 Birch Blvd, Naperville, IL, USA", emergency:"Robert Lawnston — Son +1 555-678-9012", status:"Active", membership:"Platinum Member", height:"5 ft 4 in", weight:"155 lbs", bmi:26.6, heartRate:76, bp:"140/90 mmHg", sugar:118, cholesterol:225, respiratory:17, hemoglobin:13.1, allergies:["Iodine","Codeine"], conditions:["Hypertension","Type 2 Diabetes","Arthritis"], meds:["Metformin","Amlodipine","Ibuprofen"], notes:[{date:"May 12, 2028",title:"Follow-Up Visit",text:"Blood pressure remains elevated. Increase medication dose as discussed."}] }
  ],
  appointments: [
    { id:1, patient:"Caren G. Simpson", date:"20 July 2028", time:"09:00 AM", doctor:"Dr. Petra Winsburry", treatment:"Routine Check-Up", status:"Confirmed" },
    { id:2, patient:"Edgar Warrow", date:"20 July 2028", time:"10:30 AM", doctor:"Dr. Olivia Martinez", treatment:"Cardiac Consultation", status:"Confirmed" },
    { id:3, patient:"Ocean Jane Lupre", date:"20 July 2028", time:"11:00 AM", doctor:"Dr. Damian Sanchez", treatment:"Pediatric Check-Up", status:"Pending" },
    { id:4, patient:"Shane Riddick", date:"20 July 2028", time:"01:00 PM", doctor:"Dr. Chloe Harrington", treatment:"Skin Allergy", status:"Cancelled" },
    { id:5, patient:"Queen Lawnston", date:"20 July 2028", time:"02:30 PM", doctor:"Dr. Petra Winsburry", treatment:"Follow-Up Visit", status:"Confirmed" },
    { id:6, patient:"Alice Mitchell", date:"20 July 2028", time:"09:00 AM", doctor:"Dr. Emily Smith", treatment:"Routine Check-Up", status:"Confirmed" },
    { id:7, patient:"Mikhail Morozov", date:"20 July 2028", time:"10:30 AM", doctor:"Dr. Samuel Thompson", treatment:"Cardiac Consultation", status:"Confirmed" },
    { id:8, patient:"Mateus Fernandes", date:"20 July 2028", time:"11:00 AM", doctor:"Dr. Sarah Johnson", treatment:"Pediatric Check-Up", status:"Pending" },
    { id:9, patient:"Rupert Twinny", date:"20 July 2028", time:"09:00 AM", doctor:"Dr. Petra Winsburry", treatment:"Routine Check-Up", status:"Confirmed" },
    { id:10, patient:"Ruth Herdinger", date:"20 July 2028", time:"10:00 AM", doctor:"Dr. Petra Winsburry", treatment:"Follow-Up Visit", status:"Confirmed" }
  ],
  messages: [
    { id:1, from:"John Doe", role:"Patient", avatar:"JD", time:"09:20 AM", preview:"I need to reschedule my appointment f...", unread:2, conversation:[{sender:"John Doe",text:"I need to reschedule my appointment for tomorrow, is that possible?",time:"09:20 AM",mine:false},{sender:"Me",text:"Of course John, let me check availability for you.",time:"09:22 AM",mine:true},{sender:"John Doe",text:"Thank you! Preferably afternoon slots.",time:"09:23 AM",mine:false},{sender:"Me",text:"I've rescheduled you for July 22nd at 2:30 PM with Dr. Winsburry. You'll receive a confirmation shortly.",time:"09:25 AM",mine:true}] },
    { id:2, from:"Dr. Emily Smith", role:"Doctor", avatar:"ES", time:"10:15 AM", preview:"Please review the patient's blood test r...", unread:1, conversation:[{sender:"Dr. Emily Smith",text:"Please review the patient's blood test results for Room 205.",time:"10:15 AM",mine:false},{sender:"Me",text:"Reviewing now, I'll update the chart within the hour.",time:"10:18 AM",mine:true}] },
    { id:3, from:"Dr. Michael Brown", role:"Doctor", avatar:"MB", time:"10:40 AM", preview:"You're welcome, Dr. Brown. If you need any...", unread:0, conversation:[{sender:"Dr. Michael Brown",text:"Can you confirm the schedule for the Geriatric Care session tomorrow afternoon?",time:"10:00 AM",mine:false},{sender:"Me",text:"Sure, Dr. Brown. Let me check the schedule for you.",time:"10:20 AM",mine:true},{sender:"Me",text:"The Geriatric Care session is scheduled for 2:00 PM to 4:00 PM tomorrow. You have five patients lined up.",time:"10:20 AM",mine:true},{sender:"Dr. Michael Brown",text:"Thank you. Can you please provide me the list of patients and their conditions?",time:"10:26 AM",mine:false},{sender:"Me",text:"Of course. The patients are:\n1. James Wilson — Arthritis Management\n2. Mary Johnson — Diabetes Monitoring\n3. Susan Lee — Hypertension Check-Up\n4. Robert Brown — Heart Disease Follow-Up\n5. Emily Thompson — Medication Review",time:"10:30 AM",mine:true},{sender:"Dr. Michael Brown",text:"Great, thanks for the information. I'll be prepared for the session.",time:"10:35 AM",mine:false}] }
  ],
  inventory: [
    { id:1, name:"Lisinopril 10mg", category:"Cardiovascular", stock:450, maxStock:500, unit:"tablets", price:0.45, reorder:50, status:"OK" },
    { id:2, name:"Metformin 500mg", category:"Diabetes", stock:12, maxStock:300, unit:"tablets", price:0.30, reorder:100, status:"LOW" },
    { id:3, name:"Albuterol Inhaler", category:"Respiratory", stock:85, maxStock:100, unit:"units", price:28.50, reorder:20, status:"OK" },
    { id:4, name:"Amoxicillin 250mg", category:"Antibiotic", stock:8, maxStock:200, unit:"capsules", price:0.60, reorder:50, status:"CRITICAL" },
    { id:5, name:"Ibuprofen 400mg", category:"Pain Relief", stock:320, maxStock:500, unit:"tablets", price:0.20, reorder:100, status:"OK" },
    { id:6, name:"Hydrocortisone Cream", category:"Dermatology", stock:34, maxStock:60, unit:"tubes", price:12.00, reorder:15, status:"OK" },
    { id:7, name:"Levothyroxine 50mcg", category:"Thyroid", stock:5, maxStock:100, unit:"tablets", price:0.85, reorder:30, status:"CRITICAL" }
  ],
  recentActivity: [
    { icon:"🏥", bg:"#D1FAE5", text:"Felix Müller was discharged from Room 205 after successful treatment", time:"08:30 AM" },
    { icon:"🛏️", bg:"#DBEAFE", text:"Léa Rousseau admitted to Room 312 for surgery scheduled later today", time:"09:00 AM" },
    { icon:"🔧", bg:"#FEF3C7", text:"MRI machine in Radiology received routine maintenance check", time:"10:00 AM" },
    { icon:"💊", bg:"#CCFBF1", text:"ICU received restock of essential medications", time:"11:00 AM" },
    { icon:"🚨", bg:"#FEE2E2", text:"Code Blue emergency response initiated for a patient in Room 108", time:"01:15 PM" }
  ],
  billing: [
    { id:"INV-2028-001", patient:"Caren G. Simpson", date:"20 Jul 2028", treatment:"Routine Check-Up", doctor:"Dr. Petra Winsburry", amount:150.00, status:"Paid" },
    { id:"INV-2028-002", patient:"Edgar Warrow", date:"20 Jul 2028", treatment:"Cardiac Consultation", doctor:"Dr. Olivia Martinez", amount:320.00, status:"Paid" },
    { id:"INV-2028-003", patient:"Ocean Jane Lupre", date:"20 Jul 2028", treatment:"Pediatric Check-Up", doctor:"Dr. Damian Sanchez", amount:120.00, status:"Pending" },
    { id:"INV-2028-004", patient:"Shane Riddick", date:"20 Jul 2028", treatment:"Skin Allergy", doctor:"Dr. Chloe Harrington", amount:200.00, status:"Pending" },
    { id:"INV-2028-005", patient:"Queen Lawnston", date:"20 Jul 2028", treatment:"Follow-Up Visit", doctor:"Dr. Petra Winsburry", amount:180.00, status:"Paid" },
    { id:"INV-2028-006", patient:"Alice Mitchell", date:"19 Jul 2028", treatment:"Routine Check-Up", doctor:"Dr. Emily Smith", amount:150.00, status:"Paid" },
    { id:"INV-2028-007", patient:"Mikhail Morozov", date:"19 Jul 2028", treatment:"Cardiac Consultation", doctor:"Dr. Samuel Thompson", amount:350.00, status:"Overdue" },
    { id:"INV-2028-008", patient:"Mateus Fernandes", date:"18 Jul 2028", treatment:"Pediatric Check-Up", doctor:"Dr. Sarah Johnson", amount:120.00, status:"Paid" }
  ],
  departments: [
    { name:"General Medicine", emoji:"🩺", color:"#CCFBF1", desc:"Comprehensive primary care and preventive medicine for patients of all ages.", staff:["PW","ES"], img:"https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=400&q=80" },
    { name:"Cardiology", emoji:"❤️", color:"#FEE2E2", desc:"Advanced heart care including ECG, echocardiography, and interventional procedures.", staff:["OM","ST"], img:"https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400&q=80" },
    { name:"Pediatrics", emoji:"👶", color:"#DBEAFE", desc:"Specialized medical care for infants, children, and adolescents up to age 18.", staff:["DS","SJ"], img:"https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=400&q=80" },
    { name:"Orthopedics", emoji:"🦴", color:"#FEF3C7", desc:"Diagnosis and treatment of musculoskeletal injuries, joint replacements, and spine disorders.", staff:["AK"], img:"https://images.unsplash.com/photo-1571772996211-2f02c9727629?w=400&q=80" },
    { name:"Dermatology", emoji:"✨", color:"#EDE9FE", desc:"Skin, hair, and nail conditions with cosmetic and medical dermatology expertise.", staff:["CH"], img:"https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=400&q=80" },
    { name:"Neurology", emoji:"🧠", color:"#D1FAE5", desc:"Brain and nervous system disorders including stroke, epilepsy, and neurodegenerative diseases.", staff:["MB","RC"], img:"https://images.unsplash.com/photo-1559757175-5700dde675bc?w=400&q=80" },
    { name:"Radiology", emoji:"📡", color:"#F1F5F9", desc:"Advanced imaging services: X-Ray, MRI, CT Scan, Ultrasound, and PET scans.", staff:["LK","TM"], img:"https://images.unsplash.com/photo-1587428085012-67e53d8f5b88?w=400&q=80" }
  ],
  allotments: [
    { id:1, patient_id:301, patient_name:"Caren G. Simpson", room_number:"205", bed_number:"Bed-A", ward:"Post-Op Recovery", admitted_date:"2028-07-16", expected_discharge:"2028-07-22", doctor_assigned:"Dr. Petra Winsburry", condition:"Hypertension & Asthma Observation", status:"Admitted" },
    { id:2, patient_id:302, patient_name:"Edgar Warrow", room_number:"201", bed_number:"Bed-B", ward:"Cardiology Wing", admitted_date:"2028-07-18", expected_discharge:"2028-07-25", doctor_assigned:"Dr. Olivia Martinez", condition:"Cardiac Arrhythmia Telemetry", status:"Admitted" },
    { id:3, patient_id:303, patient_name:"Ocean Jane Lupre", room_number:"301", bed_number:"Bed-A", ward:"Pediatric Wing", admitted_date:"2028-07-19", expected_discharge:"2028-07-21", doctor_assigned:"Dr. Damian Sanchez", condition:"Pediatric Asthma Care", status:"Admitted" },
    { id:4, patient_id:305, patient_name:"Queen Lawnston", room_number:"101", bed_number:"Bed-C", ward:"General Ward A", admitted_date:"2028-07-10", expected_discharge:"2028-07-19", discharged_date:"2028-07-19", doctor_assigned:"Dr. Petra Winsburry", condition:"Hypertension Stabilized", status:"Discharged" }
  ]
};

// Opened straight from disk (file://) → talk to the backend on its default port.
// Served by the backend (any port) → same origin, so the API is always reachable.
const BACKEND_URL = window.location.protocol === 'file:' ? 'http://localhost:8080' : '';

// ═══════════════════════════════════════════════
// PERSISTENCE — the SQLite backend is the system of record
//
// The bundled arrays above are only the first-run seed. On boot the app asks
// the backend for /api/bootstrap and swaps those arrays for what the database
// returned. Every array and object is wrapped in a proxy that marks its
// collection dirty on any write (push, splice, property set, delete), and a
// debounced flush PUTs the changed collection back. Reloading the page — or
// restarting the server — therefore keeps patients, appointments, invoices,
// stock and messages exactly as they were left.
//
// With no backend (for example opening index.html from disk) the proxies stay
// dormant and the app keeps running on the in-memory seed.
// ═══════════════════════════════════════════════
// recentActivity is read-only demo copy, so it is deliberately not persisted.
const PERSISTED_COLLECTIONS = ['patients', 'doctors', 'appointments', 'billing', 'inventory', 'messages', 'copilot'];

const Store = (function () {
  const dirty = new Set();
  const proxyCache = new WeakMap();
  let timer = null;
  let flushing = false;
  let online = false;
  let warnedOffline = false;

  function observe(collection, target) {
    if (!target || typeof target !== 'object') return target;
    if (proxyCache.has(target)) return proxyCache.get(target);
    const proxy = new Proxy(target, {
      get(obj, prop, receiver) {
        const value = Reflect.get(obj, prop, receiver);
        return value && typeof value === 'object' ? observe(collection, value) : value;
      },
      set(obj, prop, value) {
        obj[prop] = value;
        mark(collection);
        return true;
      },
      deleteProperty(obj, prop) {
        delete obj[prop];
        mark(collection);
        return true;
      }
    });
    proxyCache.set(target, proxy);
    return proxy;
  }

  function mark(name) {
    if (PERSISTED_COLLECTIONS.indexOf(name) === -1) return;
    dirty.add(name);
    if (!online) return;
    clearTimeout(timer);
    timer = setTimeout(flush, 300);
  }

  async function send(name) {
    const rows = JSON.parse(JSON.stringify(DATA[name] || []));
    const payload = JSON.stringify({ rows: rows });
    const options = {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: payload,
      cache: 'no-store'
    };
    // keepalive lets a final save survive a page close, but browsers cap those
    // requests at ~64 KB, so only use it when the payload fits.
    if (payload.length < 60000) options.keepalive = true;
    const res = await fetch(BACKEND_URL + '/api/collections/' + name, options);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return rows.length;
  }

  async function flush() {
    if (flushing || dirty.size === 0) return;
    flushing = true;
    const names = Array.from(dirty);
    try {
      const results = await Promise.allSettled(names.map(function (name) { return send(name); }));
      results.forEach(function (result, i) {
        if (result.status === 'fulfilled') dirty.delete(names[i]);
      });
      if (results.some(function (r) { return r.status === 'rejected'; })) {
        throw new Error('some collections failed');
      }
      warnedOffline = false;
    } catch (err) {
      if (!warnedOffline) {
        warnedOffline = true;
        showToast('Backend unreachable — changes are being held in this tab.');
      }
    } finally {
      flushing = false;
      if (dirty.size && online) {
        clearTimeout(timer);
        timer = setTimeout(flush, 1500);
      }
    }
  }

  async function bootstrap() {
    try {
      const res = await fetch(BACKEND_URL + '/api/bootstrap', { cache: 'no-store' });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const body = await res.json();
      const collections = body.collections || {};
      const hasData = Object.keys(collections).length > 0;
      PERSISTED_COLLECTIONS.forEach(function (name) {
        if (Array.isArray(collections[name])) DATA[name] = observe(name, collections[name]);
      });
      online = true;
      // First run uploads the bundled seed; a partially seeded database gets
      // whichever collections are still missing.
      PERSISTED_COLLECTIONS.forEach(function (name) {
        if (!Array.isArray(collections[name])) dirty.add(name);
      });
      if (!hasData || dirty.size) await flush();
      return { online: true, seeded: hasData, server_time: body.server_time };
    } catch (err) {
      online = false;
      console.warn('[store] backend unavailable, running on the in-memory seed:', err.message);
      return { online: false, seeded: false };
    }
  }

  function attach() {
    PERSISTED_COLLECTIONS.forEach(function (name) {
      if (Array.isArray(DATA[name])) DATA[name] = observe(name, DATA[name]);
    });
    window.addEventListener('pagehide', function () { if (dirty.size) flush(); });
    document.addEventListener('visibilitychange', function () {
      if (document.hidden && dirty.size) flush();
    });
  }

  return {
    attach: attach,
    bootstrap: bootstrap,
    flush: flush,
    mark: mark,
    isOnline: function () { return online; },
    pending: function () { return dirty.size; }
  };
})();

Store.attach();

function getAiResponse(text) {
  const t = text.toLowerCase();
  if (t.includes('emergency') || t.includes('urgent') || t.includes('code blue'))
    return "If this is a real emergency, call your hospital's emergency response team now and follow your local Code Blue protocol. This prototype cannot contact staff or dispatch responders.";
  if (t.includes('medication') || t.includes('drug') || t.includes('pharmacy') || t.includes('stock')) {
    const low = DATA.inventory.filter(item => item.status === 'LOW' || item.status === 'CRITICAL');
    return low.length
      ? `Inventory alerts: ${low.map(item => `${item.name} has ${item.stock} ${item.unit} (${item.status.toLowerCase()})`).join('; ')}. Review and verify stock before ordering.`
      : 'There are no low-stock alerts in the current inventory data.';
  }
  if (t.includes('appointment') || t.includes('schedule')) {
    const counts = DATA.appointments.reduce((all, item) => {
      const key = item.status.toLowerCase(); all[key] = (all[key] || 0) + 1; return all;
    }, {});
    return `The prototype currently has ${DATA.appointments.length} appointments: ${counts.confirmed || 0} confirmed, ${counts.pending || 0} pending, and ${counts.cancelled || 0} cancelled.`;
  }
  if (t.includes('patient') || t.includes('admit'))
    return `The prototype contains ${DATA.patients.length} patient profiles (${DATA.patients.filter(p => p.status === 'Active').length} active) and ${DATA.allotments.filter(a => a.status === 'Admitted').length} current admissions.`;
  if (t.includes('staff') || t.includes('shift') || t.includes('doctor')) {
    const available = DATA.doctors.filter(d => d.status === 'Available');
    return `${available.length} of ${DATA.doctors.length} doctors are marked available: ${available.map(d => `${d.name} (${d.hours})`).join('; ')}.`;
  }
  if (t.includes('hello') || t.includes('hi') || t.includes('hey')) return "Hello! I'm Mr.Doc. Ask me about the prototype's appointments, patients, doctors, or inventory.";
  if (t.includes('thank')) return "You're welcome. I can help summarize the data shown in this prototype.";
  return "I can summarize the prototype's appointment, patient, doctor, or inventory data. What would you like to check?";
}

// ═══════════════════════════════════════════════
// NAVIGATION
// ═══════════════════════════════════════════════
let currentPage = 'dashboard';

function navTo(page, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  if (el) el.classList.add('active');
  else {
    const navEl = document.querySelector('[data-page="'+page+'"]');
    if (navEl) navEl.classList.add('active');
  }
  currentPage = page;
  document.body.dataset.page = page;
  if (page === 'dashboard') initDashboard();
  if (page === 'ai-copilot') initAiCopilot();
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
}

function toggleTheme() {
  const html = document.documentElement;
  const isDark = html.getAttribute('data-theme') === 'dark';
  html.setAttribute('data-theme', isDark ? 'light' : 'dark');
  if (!isDark) {
    Chart.defaults.color = '#94A3B8';
    Chart.defaults.borderColor = '#1E293B';
  } else {
    Chart.defaults.color = '#64748B';
    Chart.defaults.borderColor = '#E2E8F0';
  }
}

// ═══════════════════════════════════════════════
// MODALS
// ═══════════════════════════════════════════════
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

// ═══════════════════════════════════════════════
// TOAST
// ═══════════════════════════════════════════════
function showToast(msg) {
  const t = document.createElement('div');
  t.className = 'toast';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 3000);
}

// ═══════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════
let chartsInit = false;
let patientChart, revenueChart, deptChart;

function initDashboard() {
  renderCalendar();
  renderTimeline();
  renderActivity();
  renderDashSchedule();
  if (!chartsInit) { initCharts(); chartsInit = true; }
}

function initCharts() {
  // Patient Overview bar chart
  const pCtx = document.getElementById('patientChart').getContext('2d');
  patientChart = new Chart(pCtx, {
    type: 'bar',
    data: {
      labels: ['Jul 13','Jul 14','Jul 15','Jul 16','Jul 17','Jul 18','Jul 19','Jul 20'],
      datasets: [
        { label:'Child', data:[22,18,25,20,19,22,24,21], backgroundColor:'#0D9488', borderRadius:4 },
        { label:'Adult', data:[45,52,38,55,48,42,50,55], backgroundColor:'#0F172A', borderRadius:4 },
        { label:'Elderly', data:[12,10,15,11,13,14,10,12], backgroundColor:'#94A3B8', borderRadius:4 }
      ]
    },
    options: { responsive:true, plugins:{ legend:{ position:'bottom', labels:{ boxWidth:10, font:{size:11} } } }, scales:{ x:{ grid:{display:false} }, y:{ grid:{color:'rgba(0,0,0,0.04)'}, beginAtZero:true } } }
  });

  // Revenue line chart
  const rCtx = document.getElementById('revenueChart').getContext('2d');
  revenueChart = new Chart(rCtx, {
    type: 'line',
    data: {
      labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
      datasets: [
        { label:'Income', data:[980,1200,1050,1495,1300,1100,1250], borderColor:'#0D9488', backgroundColor:'rgba(13,148,136,0.08)', borderWidth:2.5, pointRadius:4, pointBackgroundColor:'#0D9488', tension:0.4, fill:true },
        { label:'Expense', data:[620,720,680,850,760,640,710], borderColor:'#EF4444', backgroundColor:'rgba(239,68,68,0.06)', borderWidth:2.5, pointRadius:4, pointBackgroundColor:'#EF4444', tension:0.4, fill:true }
      ]
    },
    options: { responsive:true, plugins:{ legend:{ position:'bottom', labels:{ boxWidth:10, font:{size:11} } } }, scales:{ x:{ grid:{display:false} }, y:{ grid:{color:'rgba(0,0,0,0.04)'}, ticks:{ callback: v => '$'+v } } } }
  });

  // Dept donut chart
  const dCtx = document.getElementById('deptChart').getContext('2d');
  deptChart = new Chart(dCtx, {
    type: 'doughnut',
    data: {
      labels: ['Emergency','General Medicine','Internal Medicine','Other'],
      datasets: [{ data:[35,28,20,17], backgroundColor:['#0D9488','#06B6D4','#64748B','#E2E8F0'], borderWidth:0, hoverOffset:6 }]
    },
    options: { responsive:true, cutout:'65%', plugins:{ legend:{display:false} } }
  });

  // Dept legend
  const legend = document.getElementById('deptLegend');
  const cols = ['#0D9488','#06B6D4','#64748B','#E2E8F0'];
  ['Emergency 35%','General Medicine 28%','Internal Medicine 20%','Other 17%'].forEach((l,i) => {
    legend.innerHTML += `<div style="display:flex;align-items:center;gap:6px"><div style="width:10px;height:10px;border-radius:50%;background:${cols[i]};flex-shrink:0"></div><span style="font-size:12px;color:var(--slate-600)">${l}</span></div>`;
  });
}

function switchRevenueTab(el, range) {
  el.closest('.tabs').querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
  el.classList.add('active');
  const data = {
    week: { labels:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], income:[980,1200,1050,1495,1300,1100,1250], expense:[620,720,680,850,760,640,710] },
    month: { labels:['W1','W2','W3','W4'], income:[8200,9500,7800,10200], expense:[5100,6200,4800,7100] },
    year: { labels:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'], income:[72000,68000,80000,75000,88000,91000,84000,0,0,0,0,0], expense:[45000,42000,51000,48000,56000,59000,53000,0,0,0,0,0] }
  };
  const d = data[range];
  revenueChart.data.labels = d.labels;
  revenueChart.data.datasets[0].data = d.income;
  revenueChart.data.datasets[1].data = d.expense;
  revenueChart.update();
}

// Calendar
let calDate = new Date(2028, 6, 1); // July 2028
const CAL_EVENTS = [3,7,12,15,20,22,25,28];

function renderCalendar() {
  const grid = document.getElementById('cal-grid');
  const title = document.getElementById('cal-title');
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  title.textContent = months[calDate.getMonth()] + ' ' + calDate.getFullYear();

  const days = ['Su','Mo','Tu','We','Th','Fr','Sa'];
  let html = days.map(d=>`<div class="cal-day-name">${d}</div>`).join('');

  const firstDay = new Date(calDate.getFullYear(), calDate.getMonth(), 1).getDay();
  const daysInMonth = new Date(calDate.getFullYear(), calDate.getMonth()+1, 0).getDate();
  const prevDays = new Date(calDate.getFullYear(), calDate.getMonth(), 0).getDate();

  for (let i=0;i<firstDay;i++) {
    html += `<div class="cal-day other-month">${prevDays - firstDay + i + 1}</div>`;
  }
  for (let d=1;d<=daysInMonth;d++) {
    const isToday = d===20 && calDate.getMonth()===6 && calDate.getFullYear()===2028;
    const hasEvent = CAL_EVENTS.includes(d);
    html += `<div class="cal-day${isToday?' today':''}${hasEvent&&!isToday?' has-event':''}">${d}</div>`;
  }
  grid.innerHTML = html;
}

function calNav(dir) {
  calDate = new Date(calDate.getFullYear(), calDate.getMonth()+dir, 1);
  renderCalendar();
}

// Timeline
function renderTimeline() {
  const list = document.getElementById('timeline-list');
  const items = [
    {time:'08:00 AM', text:'Morning staff briefing — All departments'},
    {time:'09:00 AM', text:'Dr. Winsburry clinic begins — Room 101'},
    {time:'10:30 AM', text:'Cardiac consultation — Edgar Warrow'},
    {time:'11:00 AM', text:'Pediatrics — Ocean Jane Lupre with Dr. Sanchez'},
    {time:'01:00 PM', text:'Orthopedics surgery — OR-2'},
    {time:'02:30 PM', text:'Follow-up — Queen Lawnston with Dr. Winsburry'},
    {time:'04:00 PM', text:'Department heads meeting — Board Room'},
    {time:'06:00 PM', text:'Night shift handover — All wards'},
  ];
  list.innerHTML = items.map(i=>`
    <div class="timeline-item">
      <div class="timeline-dot"></div>
      <div style="flex:1"><div class="timeline-text">${i.text}</div><div class="timeline-time">${i.time}</div></div>
    </div>`).join('');
}

// Activity feed
function renderActivity() {
  const feed = document.getElementById('activity-feed');
  feed.innerHTML = DATA.recentActivity.map(a=>`
    <div class="activity-item">
      <div class="activity-icon" style="background:${a.bg}">${a.icon}</div>
      <div style="flex:1"><div style="font-size:13px;color:var(--slate-700)">${a.text}</div><div style="font-size:11px;color:var(--slate-400);margin-top:2px">${a.time}</div></div>
    </div>`).join('');
}

// Dashboard schedule
function renderDashSchedule() {
  const list = document.getElementById('dash-sched-list');
  list.innerHTML = DATA.doctors.slice(0,5).map(d=>`
    <div class="sched-item">
      <div class="ava ava-sm">${d.avatar}</div>
      <div style="flex:1">
        <div style="font-size:13px;font-weight:600;color:var(--navy)">${d.name}</div>
        <div style="font-size:11px;color:var(--slate-500)">${d.specialty}</div>
      </div>
      <div>
        <span class="badge ${d.status==='Available'?'badge-green':'badge-gray'}">${d.status}</span>
        <div class="sched-time">${d.hours}</div>
      </div>
    </div>`).join('');
}

// ═══════════════════════════════════════════════
// APPOINTMENTS
// ═══════════════════════════════════════════════
let apptFilter = 'all';

function cancelAppointment(id) {
  const appt = DATA.appointments.find(item => item.id === id);
  if (!appt || appt.status === 'Cancelled') return;
  appt.status = 'Cancelled';
  renderAppointments();
  showToast(`Appointment #${id} cancelled`);
}

function filterAppts(status, el) {
  apptFilter = status;
  if (el) {
    el.closest('.tabs').querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
    el.classList.add('active');
  }
  renderAppointments();
}

function renderAppointments() {
  const search = (document.getElementById('appt-search')||{value:''}).value.toLowerCase();
  const tbody = document.getElementById('appt-tbody');
  const statusColors = { Confirmed:'badge-teal', Pending:'badge-orange', Cancelled:'badge-gray' };
  let list = DATA.appointments;
  if (apptFilter !== 'all') list = list.filter(a=>a.status.toLowerCase()===apptFilter);
  if (search) list = list.filter(a=>a.patient.toLowerCase().includes(search)||a.doctor.toLowerCase().includes(search));

  tbody.innerHTML = list.map(a=>`
    <tr>
      <td><input type="checkbox"></td>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="ava ava-sm">${a.patient.split(' ').map(w=>w[0]).join('').slice(0,2)}</div>
          <span style="font-weight:600">${a.patient}</span>
        </div>
      </td>
      <td>${a.date}</td>
      <td>${a.time}</td>
      <td>${a.doctor}</td>
      <td><span style="color:var(--slate-500)">${a.treatment}</span></td>
      <td><span class="badge ${statusColors[a.status]}">${a.status}</span></td>
      <td>
        <div style="display:flex;gap:4px">
          <button class="btn btn-secondary btn-sm" onclick="showToast('Rescheduling appointment #${a.id}...')">Reschedule</button>
          ${a.status !== 'Cancelled' ? `<button class="btn btn-sm" style="background:var(--slate-100);color:var(--red);border:1px solid #FCA5A5" onclick="cancelAppointment(${a.id})">Cancel</button>` : ''}
        </div>
      </td>
    </tr>`).join('');
}

function toggleAllCB(master) {
  document.querySelectorAll('#appt-tbody input[type=checkbox]').forEach(cb=>cb.checked=master.checked);
}

// ═══════════════════════════════════════════════
// PATIENTS
// ═══════════════════════════════════════════════
function renderPatients(list) {
  const tbody = document.getElementById('patients-tbody');
  tbody.innerHTML = list.map(p=>`
    <tr style="cursor:pointer" onclick="showPatientDetail(${p.id})">
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="ava ava-sm">${p.name.split(' ').map(w=>w[0]).join('').slice(0,2)}</div>
          <div>
            <div style="font-weight:600;font-size:13px">${p.name}</div>
            <div style="font-size:11px;color:var(--slate-400)">${p.email}</div>
          </div>
        </div>
      </td>
      <td style="font-size:12px;color:var(--slate-500)">#${p.id}</td>
      <td>${p.age}y · ${p.gender}</td>
      <td style="font-size:12px">${p.phone}</td>
      <td style="font-size:12px">${p.insurance}</td>
      <td><span class="badge ${p.status==='Active'?'badge-green':'badge-gray'}">${p.status}</span></td>
      <td>
        <div style="display:flex;gap:4px">
          <button class="btn btn-secondary btn-sm" onclick="event.stopPropagation();showPatientDetail(${p.id})">View</button>
          <button class="btn btn-primary btn-sm" onclick="event.stopPropagation();showToast('Editing ${p.name}...')">Edit</button>
        </div>
      </td>
    </tr>`).join('');
}

function filterPatients(q) {
  const list = DATA.patients.filter(p=>p.name.toLowerCase().includes(q.toLowerCase())||String(p.id).includes(q));
  renderPatients(list);
}

function showPatientDetail(id) {
  const p = DATA.patients.find(pt=>pt.id===id);
  if (!p) return;
  const isSilver = (p.membership || '').toLowerCase().includes('silver') || p.id === 302;
  const isGold = (p.membership || '').toLowerCase().includes('gold') || p.id === 304;
  const isPlat = (p.membership || '').toLowerCase().includes('platinum') || p.id === 305;
  const tierClass = isSilver ? 'silver' : isGold ? 'gold' : isPlat ? 'platinum' : 'blue';
  const tierLabel = isSilver ? 'SILVER MEMBER' : isGold ? 'GOLD MEMBER' : isPlat ? 'PLATINUM MEMBER' : 'BLUE MEMBER';

  const panel = document.getElementById('patient-detail-panel');
  panel.innerHTML = `
    <div class="patient-detail-header">
      <div class="ava ava-lg">${p.name.split(' ').map(w=>w[0]).join('').slice(0,2)}</div>
      <div>
        <div style="font-size:16px;font-weight:700;color:var(--navy)">${p.name}</div>
        <div style="font-size:12px;color:var(--slate-500)">ID: #${p.id} · ${p.occupation}</div>
        <div style="margin-top:5px;display:flex;gap:6px">
          <span class="badge ${p.status==='Active'?'badge-green':'badge-gray'}">${p.status}</span>
          <span class="badge badge-blue">${p.membership}</span>
        </div>
      </div>
    </div>
    <div class="patient-detail-body">
      <!-- Contact Info -->
      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Contact Information</div>
      <div class="info-grid" style="margin-bottom:16px">
        <div class="info-item"><div class="label">📞 Phone</div><div class="value">${p.phone}</div></div>
        <div class="info-item"><div class="label">📧 Email</div><div class="value" style="font-size:11px">${p.email}</div></div>
        <div class="info-item"><div class="label">📍 Address</div><div class="value" style="font-size:11px">${p.address}</div></div>
        <div class="info-item"><div class="label">🆘 Emergency</div><div class="value" style="font-size:11px">${p.emergency}</div></div>
      </div>

      <!-- General Info -->
      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">General Information</div>
      <div class="info-grid" style="margin-bottom:16px">
        <div class="info-item"><div class="label">Date of Birth</div><div class="value">${p.dob}</div></div>
        <div class="info-item"><div class="label">Gender</div><div class="value">${p.gender}</div></div>
        <div class="info-item"><div class="label">Insurance</div><div class="value">${p.insurance}</div></div>
        <div class="info-item"><div class="label">Age</div><div class="value">${p.age} years</div></div>
      </div>

      <!-- Notes -->
      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Patient Notes</div>
      <div class="notes-scroll">
        ${p.notes.map(n=>`
          <div class="note-card">
            <div class="note-date">${n.date}</div>
            <div class="note-title">${n.title}</div>
            <div class="note-text">${n.text}</div>
          </div>`).join('')}
      </div>

      <!-- Medical Info -->
      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Medical Information</div>
      <div class="vitals-grid">
        <div class="vital-item"><div class="vital-label">Height</div><div class="vital-value">${p.height}</div></div>
        <div class="vital-item"><div class="vital-label">Weight</div><div class="vital-value">${p.weight}</div></div>
        <div class="vital-item"><div class="vital-label">BMI</div><div class="vital-value">${p.bmi}</div></div>
        <div class="vital-item"><div class="vital-label">Heart Rate</div><div class="vital-value">${p.heartRate}<span class="vital-unit"> bpm</span></div></div>
        <div class="vital-item"><div class="vital-label">Blood Pressure</div><div class="vital-value" style="font-size:12px">${p.bp}</div></div>
        <div class="vital-item"><div class="vital-label">Blood Sugar</div><div class="vital-value">${p.sugar}<span class="vital-unit"> mg/dL</span></div></div>
        <div class="vital-item"><div class="vital-label">Cholesterol</div><div class="vital-value">${p.cholesterol}<span class="vital-unit"> mg/dL</span></div></div>
        <div class="vital-item"><div class="vital-label">Respiratory</div><div class="vital-value">${p.respiratory}<span class="vital-unit"> /min</span></div></div>
        <div class="vital-item"><div class="vital-label">Hemoglobin</div><div class="vital-value">${p.hemoglobin}<span class="vital-unit"> g/dL</span></div></div>
      </div>

      <!-- Allergies -->
      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px">Allergies</div>
      <div class="tag-list" style="margin-bottom:12px">${p.allergies.map(a=>`<span class="tag allergy">⚠ ${a}</span>`).join('')}</div>

      <!-- Conditions -->
      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px">Conditions</div>
      <div class="tag-list" style="margin-bottom:12px">${p.conditions.map(c=>`<span class="tag condition">🔵 ${c}</span>`).join('')}</div>

      <!-- Medications -->
      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:6px">Current Medications</div>
      <div class="tag-list" style="margin-bottom:16px">${p.meds.map(m=>`<span class="tag med">💊 ${m}</span>`).join('')}</div>

      <!-- Authentic Membership Card (as seen in WellNest reference image) -->
      <div class="member-card">
        <div class="card-top-row">
          <div class="hosp-logo">
            <span>❖</span> WellNest Hospital
          </div>
          <div style="font-size:18px;opacity:0.6">📶</div>
        </div>
        <div style="margin:16px 0 20px 0">
          <div class="tier-badge ${tierClass}">
            ${tierLabel}
          </div>
        </div>
        <div style="display:flex;justify-content:space-between;align-items:flex-end">
          <div>
            <div class="holder-name">${p.name} | ${p.id}</div>
          </div>
          <div class="valid-thru">Valid till 12/31</div>
        </div>
      </div>
    </div>`;
}

// ═══════════════════════════════════════════════
// DOCTORS
// ═══════════════════════════════════════════════
function renderDoctors() {
  const container = document.getElementById('doc-cards');
  container.innerHTML = DATA.doctors.map(d=>`
    <div class="doc-card" id="doc-card-${d.id}" onclick="showDocDetail(${d.id})">
      <div class="doc-card-top">
        <div class="ava ava-lg">${d.avatar}</div>
        <div style="flex:1">
          <div style="font-size:14px;font-weight:700;color:var(--navy)">${d.name}</div>
          <div style="font-size:12px;color:var(--slate-500);margin-top:2px">${d.specialty}</div>
          <div class="doc-status ${d.status==='Available'?'avail':'unavail'}" style="margin-top:5px">
            <span class="dot"></span>${d.status}
          </div>
        </div>
      </div>
      <div style="font-size:11px;color:var(--slate-400);margin-bottom:8px">⏰ ${d.hours}</div>
      <div class="doc-stats">
        <div class="doc-stat"><div class="val">${d.patients}</div><div class="lbl">Patients</div></div>
        <div class="doc-stat"><div class="val">${d.appointments}</div><div class="lbl">Appointments</div></div>
        <div class="doc-stat"><div class="val">★ 4.8</div><div class="lbl">Rating</div></div>
      </div>
    </div>`).join('');
}

function showDocDetail(id) {
  const d = DATA.doctors.find(doc=>doc.id===id);
  if (!d) return;
  document.querySelectorAll('.doc-card').forEach(c=>c.classList.remove('selected'));
  document.getElementById('doc-card-'+id).classList.add('selected');

  document.getElementById('doc-detail-panel').innerHTML = `
    <div class="doc-detail-header">
      <div class="ava ava-xl" style="margin:0 auto 12px">${d.avatar}</div>
      <div style="font-size:18px;font-weight:700">${d.name}</div>
      <div style="font-size:13px;opacity:0.85;margin-top:3px">${d.specialty}</div>
      <span class="badge ${d.status==='Available'?'badge-green':'badge-red'}" style="margin-top:8px">${d.status}</span>
    </div>
    <div class="doc-detail-body">
      <div style="font-size:13px;color:var(--slate-600);line-height:1.6;margin-bottom:16px">${d.about}</div>

      <div class="stat-row">
        <div class="stat-box"><div class="val">${d.patients}</div><div class="lbl">Total Patients</div></div>
        <div class="stat-box"><div class="val">${d.appointments}</div><div class="lbl">Appointments</div></div>
      </div>

      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Contact</div>
      <div class="info-grid" style="margin-bottom:16px">
        <div class="info-item"><div class="label">📞 Phone</div><div class="value">${d.phone||'N/A'}</div></div>
        <div class="info-item"><div class="label">📧 Email</div><div class="value" style="font-size:11px">${d.email||'N/A'}</div></div>
        <div class="info-item"><div class="label">🏥 Department</div><div class="value">${d.specialty}</div></div>
        <div class="info-item"><div class="label">⏰ Hours</div><div class="value">${d.hours}</div></div>
      </div>

      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px">Appointment Stats</div>
      <canvas id="doc-chart-${d.id}" style="max-height:150px;margin-bottom:16px"></canvas>

      <div style="font-size:11px;font-weight:700;color:var(--slate-400);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:8px">Patient Feedback</div>
      <div style="display:flex;flex-direction:column;gap:8px">
        ${['Great doctor, very professional!','Very attentive and caring.','Thorough and knowledgeable.'].map((text,i)=>`
          <div style="display:flex;gap:8px;padding:8px;background:var(--slate-100);border-radius:8px">
            <div class="ava ava-sm" style="background:linear-gradient(135deg,#8B5CF6,#06B6D4)">${['JD','MK','LR'][i]}</div>
            <div><div style="font-size:11px;font-weight:600;color:var(--navy)">${['John Doe','Mary Kim','Luis Reyes'][i]}</div><div style="font-size:11px;color:var(--slate-500)">${text}</div><div style="font-size:10px;color:var(--orange)">★★★★★</div></div>
          </div>`).join('')}
      </div>
    </div>`;

  // Render doctor chart
  setTimeout(()=>{
    const ctx = document.getElementById('doc-chart-'+d.id);
    if (ctx) {
      new Chart(ctx.getContext('2d'),{
        type:'bar',
        data:{
          labels:['Mon','Tue','Wed','Thu','Fri'],
          datasets:[
            {label:'New',data:[8,12,6,10,9],backgroundColor:'#0D9488',borderRadius:4},
            {label:'Follow-Up',data:[15,20,12,18,16],backgroundColor:'#E2E8F0',borderRadius:4}
          ]
        },
        options:{responsive:true,plugins:{legend:{position:'bottom',labels:{boxWidth:10,font:{size:11}}}},scales:{x:{grid:{display:false}},y:{grid:{color:'rgba(0,0,0,0.04)'},beginAtZero:true}}}
      });
    }
  },100);
}

// ═══════════════════════════════════════════════
// DEPARTMENTS
// ═══════════════════════════════════════════════
function renderDepartments() {
  const grid = document.getElementById('dept-grid');
  grid.innerHTML = DATA.departments.map(d=>`
    <div class="dept-card" data-dept="${d.name}">
      <div style="width:100%;height:140px;overflow:hidden;background:${d.color};display:flex;align-items:center;justify-content:center;position:relative">
        <img src="${d.img}" alt="${d.name}" style="width:100%;height:100%;object-fit:cover" onerror="this.style.display='none'">
        <div style="position:absolute;font-size:48px;z-index:1">${d.emoji}</div>
      </div>
      <div class="dept-body">
        <div class="dept-name">${d.name}</div>
        <div class="dept-desc">${d.desc}</div>
        <div class="dept-footer">
          <div class="dept-staff">
            ${d.staff.map(s=>`<div class="ava ava-sm">${s}</div>`).join('')}
          </div>
          <button class="btn btn-outline btn-sm" onclick="event.stopPropagation();showDepartment('${d.name}')">See Detail</button>
        </div>
      </div>
    </div>`).join('');
}

// ═══════════════════════════════════════════════
// SCHEDULE (Weekly Grid)
// ═══════════════════════════════════════════════
const SCHED_COLORS = [
  {bg:'#CCFBF1',text:'#0D9488'},{bg:'#DBEAFE',text:'#2563EB'},{bg:'#FEF3C7',text:'#D97706'},
  {bg:'#EDE9FE',text:'#7C3AED'},{bg:'#FEE2E2',text:'#DC2626'},{bg:'#D1FAE5',text:'#059669'},
  {bg:'#F1F5F9',text:'#64748B'},{bg:'#FCE7F3',text:'#BE185D'}
];

const SCHED_DATA = {
  'Mon':[
    {doc:0,time:'09:00',label:'Dr. Winsburry\nRoutine Check-Up'},
    {doc:2,time:'10:00',label:'Dr. Martinez\nCardiac Consult'},
  ],
  'Tue':[
    {doc:1,time:'10:00',label:'Dr. Karim\nOrthopedics'},
    {doc:5,time:'08:00',label:'Dr. Smith\nGeneral'},
  ],
  'Wed':[
    {doc:3,time:'11:00',label:'Dr. Sanchez\nPediatrics'},
    {doc:6,time:'13:00',label:'Dr. Thompson\nCardiology'},
  ],
  'Thu':[
    {doc:0,time:'09:00',label:'Dr. Winsburry\nFollow-Up'},
    {doc:4,time:'09:00',label:'Dr. Harrington\nDermatology'},
    {doc:7,time:'09:00',label:'Dr. Johnson\nPediatrics'},
  ],
  'Fri':[
    {doc:2,time:'10:00',label:'Dr. Martinez\nEcho Test'},
    {doc:5,time:'08:00',label:'Dr. Smith\nPreventive'},
  ],
  'Sat':[
    {doc:3,time:'11:00',label:'Dr. Sanchez\nVaccinations'},
  ],
  'Sun':[
    {doc:6,time:'13:00',label:'Dr. Thompson\nEmergency On-Call'},
  ]
};

let SCHED_WEEK = 0;
const SCHED_MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

function scheduleMonday() {
  const monday = new Date(2028, 6, 17);
  monday.setDate(monday.getDate() + SCHED_WEEK * 7);
  return monday;
}

function submitNewAppointment() {
  const nameField = document.getElementById('appt-p-name');
  const whenField = document.getElementById('appt-datetime');
  const doctorField = document.getElementById('appt-doctor');
  const treatmentField = document.getElementById('appt-treatment');
  const statusField = document.getElementById('appt-status');

  const name = (nameField ? nameField.value : '').trim();
  if (!name) { showToast('Please enter the patient name first.'); if (nameField) nameField.focus(); return; }

  const when = new Date((whenField ? whenField.value : '') || '2028-07-20T09:00');
  if (isNaN(when)) { showToast('Please choose a valid date and time.'); return; }

  const dateLabel = when.toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
  const timeLabel = when.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }).replace(/^0/, '');
  const doctor = ((doctorField ? doctorField.value : '') || '').split(' — ')[0];
  const treatment = ((treatmentField ? treatmentField.value : '') || '').trim() || 'General Consultation';
  const status = (statusField ? statusField.value : '') || 'Confirmed';
  const nextId = DATA.appointments.reduce((max, a) => Math.max(max, Number(a.id) || 0), 0) + 1;

  DATA.appointments.push({ id: nextId, patient: name, date: dateLabel, time: timeLabel, doctor: doctor, treatment: treatment, status: status });
  renderAppointments();
  renderDashboardStats();
  refreshNotifications(false);
  closeModal('add-appt-modal');
  if (nameField) nameField.value = '';
  if (treatmentField) treatmentField.value = '';
  showToast('Appointment #' + nextId + ' booked for ' + name + ' on ' + dateLabel + ' at ' + timeLabel + '.');
}

function shiftScheduleWeek(dir) {
  SCHED_WEEK += dir;
  renderSchedule();
  showToast('Showing the week of ' + document.getElementById('sched-week-label').textContent.replace('Week of ', '') + '.');
}

function renderSchedule() {
  const grid = document.getElementById('schedule-grid');
  const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
  const hours = ['08:00','09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00'];
  const monday = scheduleMonday();

  let html = '<div class="sched-col-header">Time</div>';
  days.forEach((d, i) => {
    const date = new Date(monday);
    date.setDate(monday.getDate() + i);
    html += `<div class="sched-col-header">${d}<br><span style="font-size:9px;font-weight:400">${SCHED_MONTHS[date.getMonth()].slice(0,3)} ${date.getDate()}</span></div>`;
  });

  hours.forEach(h => {
    html += `<div class="sched-time-cell">${h}</div>`;
    days.forEach(day => {
      const events = (SCHED_DATA[day]||[]).filter(e=>e.time===h);
      if (events.length) {
        const e = events[0];
        const c = SCHED_COLORS[e.doc % SCHED_COLORS.length];
        html += `<div class="sched-cell"><div class="sched-event" style="background:${c.bg};color:${c.text}">${e.label.replace('\n','<br>')}</div></div>`;
      } else {
        html += `<div class="sched-cell"></div>`;
      }
    });
  });
  grid.innerHTML = html;

  // Week caption
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  const label = document.getElementById('sched-week-label');
  if (label) {
    const sameMonth = monday.getMonth() === sunday.getMonth();
    label.textContent = 'Week of ' + SCHED_MONTHS[monday.getMonth()] + ' ' + monday.getDate() + '–'
      + (sameMonth ? '' : SCHED_MONTHS[sunday.getMonth()] + ' ') + sunday.getDate() + ', ' + sunday.getFullYear();
  }

  // Legend
  const legend = document.getElementById('sched-legend');
  legend.innerHTML = DATA.doctors.map((d,i)=>{
    const c = SCHED_COLORS[i%SCHED_COLORS.length];
    return `<div style="display:flex;align-items:center;gap:5px;padding:4px 10px;background:${c.bg};color:${c.text};border-radius:99px;font-size:11px;font-weight:600">${d.name}</div>`;
  }).join('');
}

// ═══════════════════════════════════════════════
// BILLING
// ═══════════════════════════════════════════════
function renderBilling() {
  const tbody = document.getElementById('billing-tbody');
  const statusMap = { Paid:'badge-green', Pending:'badge-orange', Overdue:'badge-red' };
  tbody.innerHTML = DATA.billing.map(b=>`
    <tr>
      <td style="font-weight:600;color:var(--teal)">${b.id}</td>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="ava ava-sm">${b.patient.split(' ').map(w=>w[0]).join('').slice(0,2)}</div>
          ${b.patient}
        </div>
      </td>
      <td>${b.date}</td>
      <td>${b.treatment}</td>
      <td style="font-size:12px;color:var(--slate-500)">${b.doctor}</td>
      <td style="font-weight:700">$${b.amount.toFixed(2)}</td>
      <td><span class="badge ${statusMap[b.status]}">${b.status}</span></td>
      <td>
        <div style="display:flex;gap:4px">
          ${b.status!=='Paid'?`<button class="btn btn-primary btn-sm" onclick="showToast('Invoice ${b.id} marked as paid!')">Mark Paid</button>`:''}
          <button class="btn btn-secondary btn-sm" onclick="showToast('Downloading invoice ${b.id}...')">📄 PDF</button>
        </div>
      </td>
    </tr>`).join('');
}

function markInvoicePaid(id) {
  const invoice = DATA.billing.find(item => item.id === id);
  if (!invoice) return;
  invoice.status = 'Paid';
  renderBilling();
  showToast(`Invoice ${id} marked as paid`);
}

// ═══════════════════════════════════════════════
// INVENTORY
// ═══════════════════════════════════════════════
function renderInventory() {
  const tbody = document.getElementById('inventory-tbody');
  const statusBadge = { OK:'badge-green', LOW:'badge-orange', CRITICAL:'badge-red' };
  tbody.innerHTML = DATA.inventory.map(item=>{
    const pct = Math.round(item.stock/item.maxStock*100);
    const cls = item.status==='OK'?'stock-ok':item.status==='LOW'?'stock-low':'stock-critical';
    return `
      <tr>
        <td>
          <div style="font-weight:600;font-size:13px">${item.name}</div>
          <div style="font-size:11px;color:var(--slate-400)">${item.stock} ${item.unit} remaining</div>
        </td>
        <td><span class="badge badge-blue">${item.category}</span></td>
        <td style="min-width:140px">
          <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--slate-500);margin-bottom:3px">
            <span>${item.stock} ${item.unit}</span><span>${pct}%</span>
          </div>
          <div class="stock-bar"><div class="stock-fill ${cls}" style="width:${pct}%"></div></div>
        </td>
        <td style="font-weight:600">$${item.price.toFixed(2)}</td>
        <td>${item.reorder} ${item.unit}</td>
        <td><span class="badge ${statusBadge[item.status]}">${item.status}</span></td>
        <td>
          <div style="display:flex;gap:4px">
            <button class="btn btn-primary btn-sm" onclick="showToast('Reorder placed for ${item.name}!')">Reorder</button>
            <button class="btn btn-secondary btn-sm" onclick="showToast('Editing ${item.name}...')">Edit</button>
          </div>
        </td>
      </tr>`;
  }).join('');
}

// ═══════════════════════════════════════════════
// MESSAGES
// ═══════════════════════════════════════════════
let activeMsg = null;

function renderMessages() {
  const list = document.getElementById('msg-list-items');
  list.innerHTML = DATA.messages.map(m=>`
    <div class="msg-item${activeMsg===m.id?' active':''}" id="msg-item-${m.id}" onclick="openConversation(${m.id})">
      <div class="ava">${m.avatar}</div>
      <div class="msg-preview">
        <div class="msg-name">
          ${m.from}
          <span class="badge ${m.role==='Doctor'?'badge-blue':'badge-teal'}" style="font-size:9px;padding:1px 6px">${m.role}</span>
        </div>
        <div class="msg-last">${m.preview}</div>
      </div>
      <div class="msg-meta">
        <div class="msg-time">${m.time}</div>
        ${m.unread>0?`<div class="msg-unread">${m.unread}</div>`:''}
      </div>
    </div>`).join('');
}

function openConversation(id) {
  activeMsg = id;
  document.querySelectorAll('.msg-item').forEach(i=>i.classList.remove('active'));
  document.getElementById('msg-item-'+id).classList.add('active');
  const m = DATA.messages.find(msg=>msg.id===id);
  const panel = document.getElementById('chat-panel');
  panel.innerHTML = `
    <div class="chat-header">
      <div class="ava">${m.avatar}</div>
      <div>
        <div style="font-weight:700;font-size:14px;color:var(--navy)">${m.from}</div>
        <div style="font-size:11px;color:var(--green);display:flex;align-items:center;gap:4px"><span style="width:6px;height:6px;border-radius:50%;background:var(--green);display:inline-block"></span>Online</div>
      </div>
    </div>
    <div class="chat-messages" id="chat-msgs">
      ${m.conversation.map(c=>`
        <div class="msg-bubble-wrap${c.mine?' mine':''}">
          ${!c.mine?`<div class="ava ava-sm">${m.avatar}</div>`:''}
          <div>
            <div class="msg-bubble ${c.mine?'sent':'received'}">${escapeMsgText(c.text)}</div>
            <div class="msg-bubble-time">${c.time}</div>
          </div>
        </div>`).join('')}
    </div>
    <div class="chat-input-row">
      <input class="chat-input" id="chat-input-${id}" placeholder="Type a message..." onkeydown="if(event.key==='Enter')sendChatMsg(${id})">
      <button class="btn btn-primary" onclick="sendChatMsg(${id})">Send</button>
    </div>`;

  const msgs = document.getElementById('chat-msgs');
  if (msgs) msgs.scrollTop = msgs.scrollHeight;
}

function escapeMsgText(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/\n/g, '<br>');
}

function sendChatMsg(id) {
  const input = document.getElementById('chat-input-'+id);
  if (!input) return;
  const text = input.value.trim();
  if (!text) return;
  const thread = (DATA.messages || []).find(m => String(m.id) === String(id));
  if (!thread) return;
  if (!Array.isArray(thread.conversation)) thread.conversation = [];
  const time = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }).replace(/^0/, '');
  thread.conversation.push({ sender: 'Me', text: text, time: time, mine: true });
  thread.preview = text;
  thread.unread = 0;
  input.value = '';
  openConversation(thread.id);
  renderMessages();
  refreshNotifications(false);
  showToast('Message sent to ' + thread.from + '.');
}

function filterConversations(value) {
  const query = String(value || '').toLowerCase().trim();
  (DATA.messages || []).forEach(m => {
    const item = document.getElementById('msg-item-' + m.id);
    if (!item) return;
    const match = !query || (m.from + ' ' + (m.preview || '')).toLowerCase().indexOf(query) !== -1;
    item.style.display = match ? '' : 'none';
  });
}

// ═══════════════════════════════════════════════
// AI COPILOT
// ═══════════════════════════════════════════════
let currentEmotion = 'happy';
let aiInitialized = false;
const COPILOT_THREAD_ID = 'main';
const AI_HISTORY_LIMIT = 240;
let aiBusy = false;
let aiTopic = null;
let aiMoodTimer = null;

// ── conversation storage ───────────────────────────────
// The transcript belongs to the copilot alone: it lives in its own `copilot`
// collection, is written straight to SQLite by the Store layer, and nothing
// else in the app reads or renders it.
function copilotThread() {
  if (!Array.isArray(DATA.copilot)) DATA.copilot = [];
  let thread = null;
  for (let i = 0; i < DATA.copilot.length; i++) {
    if (DATA.copilot[i] && DATA.copilot[i].id === COPILOT_THREAD_ID) { thread = DATA.copilot[i]; break; }
  }
  if (!thread) {
    DATA.copilot.push({ id: COPILOT_THREAD_ID, created: new Date().toISOString(), updated: new Date().toISOString(), messages: [] });
    thread = DATA.copilot[DATA.copilot.length - 1];
  }
  if (!Array.isArray(thread.messages)) thread.messages = [];
  return thread;
}

function saveCopilotMessage(role, text, mood) {
  const thread = copilotThread();
  thread.messages.push({ role: role, text: String(text == null ? '' : text), at: Date.now(), mood: mood || null });
  if (thread.messages.length > AI_HISTORY_LIMIT) {
    thread.messages.splice(0, thread.messages.length - AI_HISTORY_LIMIT);
  }
  thread.updated = new Date().toISOString();
}

// ── chat rendering (ChatGPT-style transcript) ──────────
function aiEscapeHtml(text) {
  return String(text == null ? '' : text).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

// Renders **bold**, *italic* and bullets, and neutralises any HTML that
// arrives inside a record (a patient name, a note, a typed question).
function aiFormatReply(text) {
  return aiEscapeHtml(text)
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/(^|[\s(])\*([^*\n]+)\*/g, '$1<em>$2</em>')
    .replace(/(^|[\s(])_([^_\n]+)_/g, '$1<em>$2</em>')
    .replace(/\n/g, '<br>');
}

function aiClockLabel(at) {
  const d = at ? new Date(at) : new Date();
  return d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function renderCopilotMessage(msg) {
  const container = document.getElementById('ai-messages');
  if (!container) return null;
  const mine = msg.role === 'user';
  const wrap = document.createElement('div');
  wrap.className = 'ai-msg' + (mine ? ' user-msg' : '');
  wrap.innerHTML = `
    <div class="ava ava-sm ai-ava ${mine ? 'is-user' : 'is-bot'}">${mine ? 'YOU' : 'AI'}</div>
    <div class="ai-msg-body">
      <div class="ai-bubble ${mine ? 'user' : 'bot'}">${mine ? aiEscapeHtml(msg.text) : aiFormatReply(msg.text)}</div>
      <div class="ai-meta">${mine ? 'You' : 'Mr.Doc'} · ${aiClockLabel(msg.at)}</div>
    </div>`;
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
  return wrap;
}

function addAiMsg(text, type, mood) {
  const role = type === 'user' ? 'user' : 'bot';
  const wrap = renderCopilotMessage({ role: role, text: text, at: Date.now(), mood: mood });
  saveCopilotMessage(role, text, mood);
  return wrap;
}

function showTyping() {
  const container = document.getElementById('ai-messages');
  if (!container) return null;
  const wrap = document.createElement('div');
  wrap.className = 'ai-msg';
  wrap.id = 'typing-indicator';
  wrap.innerHTML = `
    <div class="ava ava-sm ai-ava is-bot">AI</div>
    <div class="ai-msg-body"><div class="ai-typing"><span></span><span></span><span></span></div></div>`;
  container.appendChild(wrap);
  container.scrollTop = container.scrollHeight;
  return wrap;
}

// Reveals the finished answer word by word, like a streamed reply.
function streamCopilotReply(text, mood) {
  return new Promise(function (resolve) {
    const full = String(text || '');
    const length = full.length;
    const perStep = Math.max(3, Math.ceil(length / 110));
    const wrap = renderCopilotMessage({ role: 'bot', text: '', at: Date.now(), mood: mood });
    const bubble = wrap ? wrap.querySelector('.ai-bubble') : null;
    if (!bubble) { resolve(null); return; }
    let shown = 0;
    const tick = function () {
      shown = Math.min(length, shown + perStep);
      let cut = shown;
      // stop on a word boundary so bold markers and bullets stay intact
      if (cut < length) {
        const nextSpace = full.indexOf(' ', cut);
        if (nextSpace !== -1 && nextSpace - cut < 12) cut = nextSpace;
      }
      bubble.innerHTML = aiFormatReply(full.slice(0, cut));
      const container = document.getElementById('ai-messages');
      if (container) container.scrollTop = container.scrollHeight;
      if (shown < length) setTimeout(tick, 14);
      else { bubble.innerHTML = aiFormatReply(full); resolve(wrap); }
    };
    tick();
  });
}

function initAiCopilot() {
  if (aiInitialized) return;
  aiInitialized = true;
  const container = document.getElementById('ai-messages');
  if (container) container.innerHTML = '';
  const thread = copilotThread();
  const badge = document.getElementById('ai-chat-badge');
  if (badge) badge.textContent = Store.isOnline() ? 'Saved to CARE OS' : 'Saved in this tab';
  if (!thread.messages.length) {
    const welcome = aiGreeting();
    renderCopilotMessage({ role: 'bot', text: welcome, at: Date.now(), mood: 'wave' });
    saveCopilotMessage('bot', welcome, 'wave');
    setMood('wave', 6000);
  } else {
    thread.messages.forEach(function (m) { renderCopilotMessage(m); });
    setMood('idle');
  }
  autoGrowAiInput(document.getElementById('ai-input'));
}

// ── emotions that follow the situation ─────────────────
const MRDOC_MOODS = {
  idle:       'Listening',
  wave:       'Greeting you',
  happy:      'Encouraged',
  think:      'Reading the records',
  explain:    'Explaining',
  concerned:  'Concerned',
  reassure:   'Reassuring',
  supportive: 'Supportive',
  speak:      'Speaking'
};

function setMood(key, holdMs) {
  const mood = MRDOC_MOODS[key] ? key : 'idle';
  setEmotion(mood);
  const label = document.getElementById('mrdoc-mood-label');
  if (label) label.textContent = MRDOC_MOODS[mood];
  clearTimeout(aiMoodTimer);
  if (mood !== 'idle' && mood !== 'speak') {
    aiMoodTimer = setTimeout(function () { if (!aiBusy) setMood('idle'); }, holdMs || 18000);
  }
}

// Reads the question and the answer and picks the expression that matches.
function aiMoodFor(userText, replyText) {
  const u = String(userText || '').toLowerCase();
  const r = String(replyText || '').toLowerCase();
  if (/emergency|code blue|critical|urgent|bleeding|chest pain|collapse|dying|unconscious|overdose/.test(u)) return 'concerned';
  if (/^(hi|hey|hello|good morning|good afternoon|good evening|namaste|hola|yo)\b/.test(u.trim())) return 'wave';
  if (/thank|thanks|great|perfect|awesome|helpful|brilliant|nice work|well done/.test(u)) return 'happy';
  if (/stable|within range|normal|all clear|no alerts?|improving|healthy|good news|above their reorder/.test(r)) return 'reassure';
  if (/critical|low on stock|overdue|outstanding|below|hypo|hyper|risk|alert|flagged|shortage/.test(r)) return 'concerned';
  if (/what can you|who are you|how do you|explain|why|compare|summar|difference/.test(u) || r.length > 700) return 'explain';
  if (/don't worry|reassure|it's fine|not to worry|we can help/.test(r)) return 'reassure';
  return 'happy';
}

function aiThinkingLabel(question) {
  const q = String(question || '').toLowerCase();
  if (/emergency|critical|code blue|icu/.test(q)) return '🚨 Scanning critical-care flags…';
  if (/bed|room|ward|occup|admit/.test(q)) return '🛏️ Checking the bed registry…';
  if (/appoint|schedul|booking|visit/.test(q)) return '📅 Reading the appointment book…';
  if (/medic|pharmacy|stock|drug|tablet|inventory/.test(q)) return '💊 Counting pharmacy stock…';
  if (/bill|invoice|revenue|payment|outstanding|collect/.test(q)) return '💳 Totalling the invoices…';
  if (/doctor|physician|staff|specialty|duty|roster/.test(q)) return '🩺 Checking the duty roster…';
  if (/patient|chart|report|bp|blood|sugar|cholesterol|bmi|haemoglobin|hemoglobin/.test(q)) return '📁 Opening the patient charts…';
  return '🔎 Searching CARE OS records…';
}

// ── follow-up handling, so the thread reads like a conversation ──
const AI_TOPIC_PHRASES = {
  beds: 'bed room occupancy',
  appointments: 'appointment schedule',
  pharmacy: 'pharmacy stock inventory',
  billing: 'billing invoices',
  doctors: 'doctor physician availability',
  patients: 'patient records',
  emergency: 'emergency critical care'
};

function aiDetectTopic(text) {
  // Only concrete nouns switch topic. Words like "critical" or "urgent"
  // describe the follow-up, not a new subject, so they stay in context.
  const q = ' ' + String(text || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ') + ' ';
  if (/emergency|code blue|rapid response/.test(q)) return 'emergency';
  if (/appoint|book|schedul|visit|consult/.test(q)) return 'appointments';
  if (/bed|room|ward|occup|admit|allot|inpatient|icc?u/.test(q)) return 'beds';
  if (/medic|pharmac|stock|drug|tablet|inventory|reorder/.test(q)) return 'pharmacy';
  if (/bill|invoice|revenue|payment|outstanding|collect/.test(q)) return 'billing';
  if (/doctor|physician|staff|specialty|duty|roster/.test(q)) return 'doctors';
  if (/patient|chart|record|vital|bp|sugar|cholesterol|h[ae]moglobin/.test(q)) return 'patients';
  return null;
}

function aiIsFollowUp(text) {
  const words = String(text || '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').split(/\s+/).filter(Boolean);
  if (!words.length || words.length > 7) return false;
  return /^(what|how|why|which|who|when|where|and|ok|so|then|more|any|tell)\b/.test(words[0])
    || /\b(it|its|them|they|those|these|that|this|his|her|their|he|she|same|also|another|more)\b/.test(' ' + words.join(' ') + ' ');
}

function aiResolveQuestion(text) {
  const topic = aiDetectTopic(text);
  if (topic) aiTopic = topic;
  if (topic || !aiTopic) return text;
  if (!aiIsFollowUp(text)) return text;
  return AI_TOPIC_PHRASES[aiTopic] + ' ' + text;
}

// ── composer ───────────────────────────────────────────
function autoGrowAiInput(el) {
  if (!el) return;
  el.style.height = 'auto';
  el.style.height = Math.min(160, Math.max(26, el.scrollHeight)) + 'px';
}

function handleAiKey(event) {
  if (event.key !== 'Enter' || event.shiftKey || event.isComposing) return;
  event.preventDefault();
  sendAiMessage();
}

async function sendAiMessage() {
  const input = document.getElementById('ai-input');
  if (!input || aiBusy) return;
  const text = input.value.trim();
  if (!text) return;

  input.value = '';
  autoGrowAiInput(input);

  const question = aiResolveQuestion(text);
  const typingMood = aiMoodFor(text, '');
  addAiMsg(text, 'user');
  aiBusy = true;
  const sendBtn = document.getElementById('ai-send');
  if (sendBtn) sendBtn.disabled = true;

  const bubble = document.getElementById('ai-thought-bubble');
  if (bubble) bubble.textContent = aiThinkingLabel(question);
  setMood('think');

  let typing = null;
  const typingTimer = setTimeout(function () { typing = showTyping(); }, 260);

  let answer = '';
  try {
    await loadAiLiveContext();
    answer = answerCopilotQuery(question);
    // The local engine is the source of truth; the SQLite endpoint is only
    // consulted when the engine has nothing to say about the question.
    if (!answer || /I could not find an answer/.test(answer)) {
      const remote = await aiPostJson('/api/ai/chat', { message: question, language: selectedLang });
      if (remote) answer = remote;
    }
  } catch (err) {
    console.warn('[copilot] answer failed:', err && err.message);
    answer = aiFallbackAnswer(text);
  }

  clearTimeout(typingTimer);
  if (typing) typing.remove();
  if (!answer) answer = aiFallbackAnswer(text);

  const mood = aiMoodFor(text, answer);
  setMood('speak');
  await streamCopilotReply(answer, mood);
  saveCopilotMessage('bot', answer, mood);
  aiBusy = false;
  if (sendBtn) sendBtn.disabled = false;
  setMood(mood, 20000);
  if (typingMood !== 'concerned') speak(aiSpeechSnippet(answer), mood);
  else speak(aiSpeechSnippet(answer), 'concerned');
}

function openNotificationsModal() {
  openModal('notifications-modal');
}

function openSettingsModal() {
  const session = readSession() || {};
  const account = readAccount() || {};
  const set = (id, value) => { const el = document.getElementById(id); if (el) el.value = value; };
  set('settings-admin', (session.name || account.name || 'Administrator') + ' · ' + (session.email || account.email || DEFAULT_ADMIN.email));
  set('settings-endpoint', (window.location.protocol === 'file:' ? 'http://localhost:8080' : window.location.origin) + '/api/');
  set('settings-store', Store.isOnline() ? 'SQLite database (server) — saved after every change' : 'In-memory only — backend not reachable');
  set('settings-session', session.signedInAt ? 'Signed in ' + new Date(session.signedInAt).toLocaleString('en-GB') + ' · active until you log out' : 'No active session');
  openModal('settings-modal');
}

function submitNewPatient() {
  const name = document.getElementById('new-p-name').value.trim();
  if (!name) { showToast('Please enter patient name'); return; }
  const dob = document.getElementById('new-p-dob').value;
  const gender = document.getElementById('new-p-gender').value;
  const phone = document.getElementById('new-p-phone').value || '+1 555-000-0000';
  const mem = document.getElementById('new-p-mem').value;
  const cond = document.getElementById('new-p-cond').value || 'Under Evaluation';

  const newPt = {
    id: 300 + DATA.patients.length + 1,
    name: name,
    dob: dob,
    gender: gender,
    age: new Date().getFullYear() - parseInt(dob.slice(0,4)),
    occupation: "Patient",
    insurance: "HealthCare Plus",
    phone: phone,
    email: name.toLowerCase().replace(/\s+/g, '.') + "@careos.ai",
    address: "Springfield, IL, USA",
    emergency: "Family Contact",
    status: "Active",
    membership: mem,
    height: "5 ft 8 in",
    weight: "160 lbs",
    bmi: 24.3,
    heartRate: 72,
    bp: "120/80 mmHg",
    sugar: 92,
    cholesterol: 175,
    respiratory: 16,
    hemoglobin: 14.2,
    allergies: ["None recorded"],
    conditions: [cond],
    meds: ["None active"],
    notes: [{ date: new Date().toLocaleDateString('en-US', {month:'short', day:'numeric', year:'numeric'}), title: "Initial Registration", text: "Registered through CARE OS AI Inpatient Intake." }]
  };

  DATA.patients.unshift(newPt);
  renderPatients(DATA.patients);
  closeModal('add-patient-modal');
  showToast(`Patient ${name} registered successfully with ${mem}!`);
  speak(`New patient ${name} registered successfully.`);
}

function submitNewDoctor() {
  const name = document.getElementById('new-d-name').value.trim();
  if (!name) { showToast('Please enter doctor name'); return; }
  const spec = document.getElementById('new-d-spec').value;
  const hours = document.getElementById('new-d-hours').value;

  const newDoc = {
    id: DATA.doctors.length + 1,
    name: name,
    specialty: spec,
    status: "Available",
    hours: hours,
    patients: 0,
    appointments: 0,
    phone: "+1 555-234-5690",
    email: name.toLowerCase().replace(/\s+/g, '.').replace('dr.', '') + "@careos.ai",
    avatar: name.split(' ').map(w=>w[0]).join('').slice(0,2),
    about: `Board-certified ${spec} physician affiliated with CARE OS AI Hospital System.`
  };

  DATA.doctors.push(newDoc);
  renderDoctors();
  closeModal('add-doctor-modal');
  showToast(`Physician ${name} added to ${spec} department!`);
  speak(`Physician ${name} has been added.`);
}

function submitNewInventory() {
  const name = document.getElementById('new-inv-name').value.trim();
  if (!name) { showToast('Please enter medication name'); return; }
  const cat = document.getElementById('new-inv-cat').value || 'General';
  const qty = parseInt(document.getElementById('new-inv-qty').value) || 50;

  DATA.inventory.push({
    id: DATA.inventory.length + 1,
    name: name,
    category: cat,
    stock: qty,
    maxStock: qty * 2,
    unit: "units",
    price: 15.00,
    reorder: 20,
    status: qty < 20 ? "LOW" : "OK"
  });

  renderInventory();
  closeModal('add-inventory-modal');
  showToast(`Item ${name} added to pharmacy inventory.`);
}


// ═══════════════════════════════════════════════
// GROUNDED ANSWER ENGINE — Mr.Doc Clinical Copilot
// Every figure in a reply is computed from the live records in DATA,
// or from the SQLite backend when it is reachable. Nothing is
// pre-written, so the copilot cannot report stale or invented numbers.
// ═══════════════════════════════════════════════
let AI_LIVE = { rooms: null, allotments: null, stats: null };
const AI_FETCH_TIMEOUT = 3500;

async function aiFetchJson(path, options) {
  if (typeof fetch !== 'function') return null;
  let timer = null;
  const controller = typeof AbortController === 'function' ? new AbortController() : null;
  if (controller) timer = setTimeout(function () { controller.abort(); }, AI_FETCH_TIMEOUT);
  try {
    const opts = Object.assign({}, options || {});
    if (controller) opts.signal = controller.signal;
    const res = await fetch(BACKEND_URL + path, opts);
    if (!res.ok) return null;
    return await res.json();
  } catch (e) {
    return null; // backend offline → the in-app records are used instead
  } finally {
    if (timer) clearTimeout(timer);
  }
}

async function aiPostJson(path, body) {
  const data = await aiFetchJson(path, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });
  if (data && typeof data.reply === 'string' && data.reply.trim()) return data.reply.trim();
  return null;
}

async function loadAiLiveContext() {
  const results = await Promise.all([
    aiFetchJson('/api/rooms'),
    aiFetchJson('/api/allotments'),
    aiFetchJson('/api/stats')
  ]);
  AI_LIVE = { rooms: results[0], allotments: results[1], stats: results[2] };
  return AI_LIVE;
}

// ── small helpers ─────────────────────────────
function aiWords(text) {
  return String(text || '').toLowerCase().match(/[a-z0-9]+/g) || [];
}
function aiHasAny(words, list) {
  return list.some(function (w) { return words.indexOf(w) !== -1; });
}
function aiJoin(value) {
  if (Array.isArray(value)) return value.length ? value.join(', ') : 'None recorded';
  return value ? String(value) : 'None recorded';
}
function aiMoney(n) {
  return '$' + Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function aiNumber(n, fallback) {
  const v = Number(n);
  return isFinite(v) ? v : (fallback === undefined ? 0 : fallback);
}

// ── live records (backend first, page records second) ──
function aiAllotmentRows() {
  const live = Array.isArray(AI_LIVE.allotments) && AI_LIVE.allotments.length ? AI_LIVE.allotments : null;
  return (live || DATA.allotments || []).slice();
}
function aiAdmittedRows() {
  return aiAllotmentRows().filter(function (a) {
    return String(a.status || '').toLowerCase() === 'admitted';
  });
}
function aiBedStats() {
  const rooms = Array.isArray(AI_LIVE.rooms) ? AI_LIVE.rooms : [];
  if (!rooms.length) return null;
  let total = 0, occupied = 0, available = 0;
  rooms.forEach(function (r) {
    total += aiNumber(r.total_beds);
    occupied += aiNumber(r.occupied_beds);
    available += aiNumber(r.available_beds);
  });
  return { rooms: rooms.length, totalBeds: total, occupied: occupied, available: available };
}
function aiInventoryRows() {
  return (DATA.inventory || []).map(function (item) {
    const stock = aiNumber(item.stock);
    const reorder = aiNumber(item.reorder);
    let level = 'OK';
    if (stock <= 0) level = 'CRITICAL';
    else if (reorder > 0 && stock <= reorder * 0.5) level = 'CRITICAL';
    else if (reorder > 0 && stock <= reorder) level = 'LOW';
    return Object.assign({}, item, { stock: stock, reorder: reorder, level: level });
  });
}
function aiCountByStatus(rows) {
  const counts = {};
  rows.forEach(function (r) {
    const key = String(r.status || 'Unknown');
    counts[key] = (counts[key] || 0) + 1;
  });
  return counts;
}

// ── record lookup ─────────────────────────────
function aiNameScore(queryText, words, name, id, idBonus) {
  const lowerName = String(name || '').toLowerCase();
  const parts = lowerName.replace(/[^a-z\s]/g, ' ').split(/\s+/).filter(function (w) { return w.length > 2; });
  let score = 0;
  if (lowerName && queryText.indexOf(lowerName) !== -1) {
    score = 100;
  } else {
    const hits = parts.filter(function (p) { return words.indexOf(p) !== -1; });
    if (parts.length && hits.length === parts.length) score = 60 + hits.length;
    else if (hits.length && hits.some(function (h) { return h.length >= 4; })) score = 30 + hits.length;
  }
  if (id !== undefined && id !== null && words.indexOf(String(id)) !== -1) {
    score = Math.max(score, idBonus || 90);
  }
  return score;
}
function aiFindPatients(queryText, words, skipIdMatch) {
  return DATA.patients
    .map(function (p) { return { p: p, score: aiNameScore(queryText, words, p.name, skipIdMatch ? null : p.id, 95) }; })
    .filter(function (r) { return r.score > 0; })
    .sort(function (a, b) { return b.score - a.score; })
    .map(function (r) { return r.p; });
}
function aiFindDoctors(queryText, words) {
  return DATA.doctors
    .map(function (d) { return { d: d, score: aiNameScore(queryText, words, d.name, null, 0) }; })
    .filter(function (r) { return r.score > 0; })
    .sort(function (a, b) { return b.score - a.score; })
    .map(function (r) { return r.d; });
}
function aiAdmissionFor(patient) {
  const rows = aiAllotmentRows();
  for (let i = 0; i < rows.length; i++) {
    const a = rows[i];
    if (String(a.patient_id) === String(patient.id)) return a;
    if (String(a.patient_name || '').toLowerCase() === String(patient.name).toLowerCase()) return a;
  }
  return null;
}

// ── clinical reference ranges (standard adult values) ──
const AI_METRIC_REFERENCE = {
  bp: 'Reference (ACC/AHA, adults): normal below 120/80 mmHg · elevated 120–129 systolic · stage 1 hypertension 130–139 or 80–89 diastolic · stage 2 140/90 or higher · hypertensive crisis 180/120 or higher.',
  glucose: 'Reference (fasting plasma glucose, adults): below 70 mg/dL is the hypoglycaemia range · 70–99 normal · 100–125 prediabetes range · 126 and above diabetes range.',
  cholesterol: 'Reference (total cholesterol, adults): below 200 mg/dL desirable · 200–239 borderline high · 240 and above high.',
  heart: 'Reference (resting heart rate, adults): 60–100 bpm normal · below 60 bradycardia · above 100 tachycardia.',
  bmi: 'Reference (adults): below 18.5 underweight · 18.5–24.9 normal · 25–29.9 overweight · 30 and above obese.',
  hemoglobin: 'Reference (adults): men 13.5–17.5 g/dL · women 12.0–15.5 g/dL. Children and pregnancy have different ranges.',
  respiratory: 'Reference (respiratory rate, resting adults): 12–20 breaths per minute.'
};
const AI_METRIC_LABEL = {
  bp: 'blood pressure',
  glucose: 'blood glucose',
  cholesterol: 'total cholesterol',
  heart: 'resting heart rate',
  bmi: 'body mass index',
  hemoglobin: 'haemoglobin',
  respiratory: 'respiratory rate'
};

function aiDetectMetric(queryText) {
  if (/blood pressure|\bbp\b|systolic|diastolic|hypertens/.test(queryText)) return 'bp';
  if (/sugar|glucose|diabet|insulin|hba1c/.test(queryText)) return 'glucose';
  if (/cholesterol|lipid/.test(queryText)) return 'cholesterol';
  if (/heart rate|pulse|\bhr\b|bradycard|tachycard/.test(queryText)) return 'heart';
  if (/\bbmi\b|body mass|weight/.test(queryText)) return 'bmi';
  if (/hemoglobin|haemoglobin|\bhb\b|anaemia|anemia/.test(queryText)) return 'hemoglobin';
  if (/respiratory|breathing rate|resp rate|spo2|oxygen saturation/.test(queryText)) return 'respiratory';
  return null;
}

function aiBpReading(value) {
  const m = String(value || '').match(/(\d{2,3})\s*\/\s*(\d{2,3})/);
  if (!m) return null;
  const sys = parseInt(m[1], 10);
  const dia = parseInt(m[2], 10);
  let category = 'Normal';
  if (sys >= 180 || dia >= 120) category = 'hypertensive crisis range';
  else if (sys >= 140 || dia >= 90) category = 'stage 2 hypertension range';
  else if (sys >= 130 || dia >= 80) category = 'stage 1 hypertension range';
  else if (sys >= 120) category = 'elevated range';
  else if (sys < 90 || dia < 60) category = 'hypotension range';
  return { sys: sys, dia: dia, category: category, text: sys + '/' + dia + ' mmHg' };
}

function aiMetricValue(metric, p) {
  switch (metric) {
    case 'bp': return p.bp ? String(p.bp) : 'not recorded';
    case 'glucose': return p.sugar != null ? aiNumber(p.sugar) + ' mg/dL' : 'not recorded';
    case 'cholesterol': return p.cholesterol != null ? aiNumber(p.cholesterol) + ' mg/dL' : 'not recorded';
    case 'heart': return p.heartRate != null ? aiNumber(p.heartRate) + ' bpm' : 'not recorded';
    case 'bmi': return p.bmi != null ? aiNumber(p.bmi) + ' (' + (p.weight || 'weight not recorded') + ', ' + (p.height || 'height not recorded') + ')' : 'not recorded';
    case 'hemoglobin': return p.hemoglobin != null ? aiNumber(p.hemoglobin) + ' g/dL' : 'not recorded';
    case 'respiratory': return p.respiratory != null ? aiNumber(p.respiratory) + ' breaths/min' : 'not recorded';
    default: return 'not recorded';
  }
}

function aiMetricInterpretation(metric, p) {
  const paedNote = aiNumber(p.age) > 0 && aiNumber(p.age) < 18;
  let verdict = 'not recorded';
  if (metric === 'bp') {
    const reading = aiBpReading(p.bp);
    verdict = reading ? reading.category : 'not recorded';
  } else if (metric === 'glucose') {
    const v = Number(p.sugar);
    if (!isFinite(v)) verdict = 'not recorded';
    else if (v < 70) verdict = 'below the reference range';
    else if (v <= 99) verdict = 'within the fasting reference range';
    else if (v <= 125) verdict = 'in the prediabetes range';
    else verdict = 'in the diabetes range';
  } else if (metric === 'cholesterol') {
    const v = Number(p.cholesterol);
    if (!isFinite(v)) verdict = 'not recorded';
    else if (v < 200) verdict = 'in the desirable range';
    else if (v <= 239) verdict = 'borderline high';
    else verdict = 'high';
  } else if (metric === 'heart') {
    const v = Number(p.heartRate);
    if (!isFinite(v)) verdict = 'not recorded';
    else if (v < 60) verdict = 'below the reference range (bradycardia range)';
    else if (v <= 100) verdict = 'within the reference range';
    else verdict = 'above the reference range (tachycardia range)';
  } else if (metric === 'bmi') {
    const v = Number(p.bmi);
    if (!isFinite(v)) verdict = 'not recorded';
    else if (v < 18.5) verdict = 'underweight range';
    else if (v < 25) verdict = 'normal range';
    else if (v < 30) verdict = 'overweight range';
    else verdict = 'obese range';
  } else if (metric === 'hemoglobin') {
    const v = Number(p.hemoglobin);
    const male = String(p.gender || '').toLowerCase().indexOf('male') === 0;
    if (!isFinite(v)) verdict = 'not recorded';
    else if (male) verdict = v < 13.5 ? 'below the adult male reference range' : (v > 17.5 ? 'above the adult male reference range' : 'within the adult male reference range');
    else verdict = v < 12 ? 'below the adult female reference range' : (v > 15.5 ? 'above the adult female reference range' : 'within the adult female reference range');
  } else if (metric === 'respiratory') {
    const v = Number(p.respiratory);
    if (!isFinite(v)) verdict = 'not recorded';
    else if (v < 12) verdict = 'below the reference range';
    else if (v <= 20) verdict = 'within the reference range';
    else verdict = 'above the reference range';
  }
  if (paedNote && metric !== 'bmi') verdict += ' — note the patient is under 18, so paediatric ranges differ';
  return verdict;
}

// ── answer sections ───────────────────────────
function aiGreeting() {
  const admitted = aiAdmittedRows().length;
  const appointments = (DATA.appointments || []).length;
  return '👋 **Hello — I am Mr.Doc, your CARE OS clinical copilot.**\n\n'
    + 'I answer strictly from the records held in CARE OS: **' + DATA.patients.length + '** patient charts, **'
    + admitted + '** current admissions, **' + appointments + '** appointments, **' + DATA.doctors.length
    + '** physicians and **' + (DATA.inventory || []).length + '** pharmacy lines.\n\n'
    + 'Try: *"What is Caren\'s blood pressure?"*, *"Which medicines are low on stock?"*, *"How many beds are free?"*';
}

function aiCapabilities() {
  return '🧭 **What I can answer accurately**\n'
    + '• Any patient\'s chart: vitals, conditions, prescriptions, allergies, insurance, admission\n'
    + '• A single vital across all patients (blood pressure, glucose, cholesterol, heart rate, BMI, haemoglobin, respiratory rate)\n'
    + '• Bed, room and ward occupancy — live from the room registry when the backend is running\n'
    + '• Appointment counts and scheduling\n'
    + '• Physician availability, duty hours and specialties\n'
    + '• Pharmacy stock levels and reorder warnings\n'
    + '• Billing totals, paid, pending and overdue invoices\n\n'
    + 'If a question is not covered by the records, I will say so instead of guessing.';
}

function aiPatientChart(p) {
  const admission = aiAdmissionFor(p);
  const lines = [];
  lines.push('📋 **Patient record — ' + p.name + '** (ID #' + p.id + ')');
  lines.push('• **Profile**: ' + p.age + ' years · ' + aiJoin(p.gender) + ' · DOB ' + aiJoin(p.dob));
  lines.push('• **Status**: ' + aiJoin(p.status) + ' · ' + aiJoin(p.membership) + ' · Insurance: ' + aiJoin(p.insurance));
  lines.push('• **Vitals**: BP ' + aiJoin(p.bp) + ' · HR ' + (p.heartRate != null ? p.heartRate + ' bpm' : 'not recorded') + ' · Glucose ' + (p.sugar != null ? p.sugar + ' mg/dL' : 'not recorded'));
  lines.push('• **Cholesterol**: ' + (p.cholesterol != null ? p.cholesterol + ' mg/dL' : 'not recorded') + ' · Respiratory ' + (p.respiratory != null ? p.respiratory + '/min' : 'not recorded') + ' · Hb ' + (p.hemoglobin != null ? p.hemoglobin + ' g/dL' : 'not recorded'));
  lines.push('• **BMI**: ' + (p.bmi != null ? p.bmi : 'not recorded') + ' (' + aiJoin(p.weight) + ', ' + aiJoin(p.height) + ')');
  lines.push('• **Conditions**: ' + aiJoin(p.conditions));
  lines.push('• **Current prescriptions**: ' + aiJoin(p.meds));
  lines.push('• **Allergies**: ⚠️ ' + aiJoin(p.allergies));
  lines.push('• **Contact**: ' + aiJoin(p.phone) + ' · ' + aiJoin(p.email));
  lines.push('• **Emergency contact**: ' + aiJoin(p.emergency));
  if (admission) {
    lines.push('• **Admission**: ' + admission.status + ' in Room ' + admission.room_number + ' (' + admission.bed_number + ', ' + admission.ward + ') under ' + admission.doctor_assigned
      + ' · admitted ' + aiJoin(admission.admitted_date) + ' · expected discharge ' + aiJoin(admission.expected_discharge));
  }
  const note = (p.notes && p.notes[0]) ? p.notes[0] : null;
  if (note) lines.push('• **Latest note** (' + note.date + ', ' + note.title + '): ' + note.text);
  return lines.join('\n');
}

function aiPatientFocus(p, focus) {
  if (focus === 'allergy') {
    return '⚠️ **Allergies recorded for ' + p.name + '** (ID #' + p.id + '): ' + aiJoin(p.allergies)
      + '\n\nVerify allergies with the patient before prescribing — the chart is only as current as the last update.';
  }
  if (focus === 'meds') {
    const meds = Array.isArray(p.meds) ? p.meds : [p.meds];
    const inventory = aiInventoryRows();
    const lines = ['💊 **Current prescriptions for ' + p.name + '** (ID #' + p.id + ')'];
    meds.forEach(function (m) {
      const label = String(m || '').toLowerCase();
      const match = inventory.filter(function (item) {
        const name = String(item.name || '').toLowerCase();
        const head = name.split(' ')[0];
        return label.indexOf(head) !== -1 || name.indexOf(label) !== -1;
      })[0];
      lines.push('• ' + m + (match ? ' — pharmacy stock: ' + match.stock + ' ' + match.unit + ' (' + match.level + ')' : ' — no matching pharmacy line recorded'));
    });
    return lines.join('\n');
  }
  return aiPatientChart(p);
}

function aiPatientShortlist(patients, metric) {
  const shown = patients.slice(0, 6);
  const lines = ['👥 **' + shown.length + ' patient' + (shown.length === 1 ? '' : 's') + ' matched that name**'];
  shown.forEach(function (p) {
    lines.push('• **' + p.name + '** (ID #' + p.id + ') — ' + aiJoin(p.gender) + ', ' + p.age + ' years · ' + aiJoin(p.status)
      + (metric ? ' · ' + AI_METRIC_LABEL[metric] + ': ' + aiMetricValue(metric, p) : ' · ' + aiJoin(p.conditions)));
  });
  lines.push('\nAsk with the full name or patient ID to see one complete chart.');
  return lines.join('\n');
}

function aiMetricForPatient(metric, p) {
  const value = aiMetricValue(metric, p);
  const verdict = aiMetricInterpretation(metric, p);
  return '🩺 **' + p.name.charAt(0).toUpperCase() + p.name.slice(1) + ' — ' + AI_METRIC_LABEL[metric] + '**\n'
    + '• **Recorded**: **' + value + '**\n'
    + '• **Interpretation**: ' + verdict + '\n'
    + '• **Conditions on chart**: ' + aiJoin(p.conditions) + '\n'
    + '• **Prescriptions**: ' + aiJoin(p.meds) + '\n\n'
    + '_' + AI_METRIC_REFERENCE[metric] + '_\n'
    + 'Treatment decisions belong to the treating physician.';
}

function aiMetricReference(metric) {
  const rows = DATA.patients.map(function (p) { return { p: p, value: aiMetricValue(metric, p), verdict: aiMetricInterpretation(metric, p) }; });
  const outlier = rows.filter(function (r) {
    return /hypertension|elevated|hypotension|prediabetes|diabetes|borderline|high|bradycardia|tachycardia|above|below|underweight|overweight|obese/.test(r.verdict);
  });
  const lines = ['📈 **' + AI_METRIC_LABEL[metric].charAt(0).toUpperCase() + AI_METRIC_LABEL[metric].slice(1) + ' across ' + rows.length + ' patient records**'];
  rows.forEach(function (r) {
    lines.push('• **' + r.p.name + '** (ID #' + r.p.id + '): ' + r.value + ' — ' + r.verdict);
  });
  lines.push('\n' + outlier.length + ' of ' + rows.length + ' records fall outside the reference range.');
  lines.push('_' + AI_METRIC_REFERENCE[metric] + '_');
  return lines.join('\n');
}

function aiCountsAnswer() {
  const patients = DATA.patients || [];
  const active = patients.filter(function (p) { return String(p.status).toLowerCase() === 'active'; }).length;
  const admitted = aiAdmittedRows();
  const beds = aiBedStats();
  const appointments = DATA.appointments || [];
  const apptCounts = aiCountByStatus(appointments);
  const doctors = DATA.doctors || [];
  const available = doctors.filter(function (d) { return String(d.status).toLowerCase() === 'available'; }).length;
  const inventory = aiInventoryRows();
  const belowReorder = inventory.filter(function (i) { return i.level !== 'OK'; });
  const billing = DATA.billing || [];
  const outstanding = billing.filter(function (b) { return String(b.status).toLowerCase() !== 'paid'; })
    .reduce(function (sum, b) { return sum + aiNumber(b.amount); }, 0);

  const lines = ['📊 **Live hospital counts**'];
  lines.push('• Patients on file: **' + patients.length + '** (' + active + ' active)');
  lines.push('• Current admissions: **' + admitted.length + '**');
  if (beds) lines.push('• Beds: **' + beds.totalBeds + '** total · ' + beds.occupied + ' occupied · **' + beds.available + ' available** across ' + beds.rooms + ' rooms');
  else lines.push('• Bed capacity: served by the backend room registry, which is not reachable from this view (allotment records show ' + admitted.length + ' admissions)');
  lines.push('• Appointments on file: **' + appointments.length + '** (' + (apptCounts['Confirmed'] || 0) + ' confirmed, ' + (apptCounts['Pending'] || 0) + ' pending, ' + (apptCounts['Cancelled'] || 0) + ' cancelled)');
  lines.push('• Physicians: **' + doctors.length + '** (' + available + ' marked available)');
  lines.push('• Pharmacy lines below reorder level: **' + belowReorder.length + '**' + (belowReorder.length ? ' — ' + belowReorder.map(function (i) { return i.name; }).join(', ') : ''));
  lines.push('• Outstanding invoices: **' + aiMoney(outstanding) + '** across ' + billing.filter(function (b) { return String(b.status).toLowerCase() !== 'paid'; }).length + ' invoices');
  lines.push('\nSource: live CARE OS records. Figures refresh every time you ask.');
  return lines.join('\n');
}

const AI_BED_STOPWORDS = { wing: 1, ward: 1, room: 1, rooms: 1, suite: 1, bed: 1, beds: 1, care: 1, general: 1, private: 1, semi: 1, standard: 1, free: 1, available: 1, now: 1, show: 1, which: 1 };

function aiMatchingRooms(queryText) {
  const rooms = Array.isArray(AI_LIVE.rooms) ? AI_LIVE.rooms : [];
  if (!queryText || !rooms.length) return [];
  return rooms.filter(function (r) {
    const tokens = aiWords(String(r.ward || '') + ' ' + String(r.room_type || '')).filter(function (w) {
      return w.length >= 3 && !AI_BED_STOPWORDS[w];
    });
    return tokens.some(function (t) { return queryText.indexOf(t) !== -1; });
  });
}

function aiBedsAnswer(queryText) {
  const admitted = aiAdmittedRows();
  const beds = aiBedStats();
  const lines = ['🛏️ **Bed and room occupancy**'];
  if (beds) {
    lines.push('• Registered beds: **' + beds.totalBeds + '** in **' + beds.rooms + '** rooms');
    lines.push('• Occupied now: **' + beds.occupied + '** · Available now: **' + beds.available + '**');
  } else {
    lines.push('• Live capacity is held by the backend room registry, which is not reachable from this view — start `care_os_server.py` and ask again for exact free-bed counts.');
    lines.push('• The room allotment records in this view show **' + admitted.length + '** active admissions.');
  }
  lines.push('• Admissions marked **Admitted**: **' + admitted.length + '**');
  admitted.forEach(function (a) {
    lines.push('   – ' + a.patient_name + ' · Room ' + a.room_number + ' (' + a.bed_number + ', ' + a.ward + ') · ' + a.doctor_assigned
      + ' · since ' + aiJoin(a.admitted_date) + ' · expected discharge ' + aiJoin(a.expected_discharge));
  });
  const wards = {};
  admitted.forEach(function (a) { wards[a.ward] = (wards[a.ward] || 0) + 1; });
  const wardNames = Object.keys(wards);
  if (wardNames.length) {
    lines.push('• By ward: ' + wardNames.map(function (w) { return w + ' (' + wards[w] + ')'; }).join(' · '));
  }
  const allRooms = Array.isArray(AI_LIVE.rooms) ? AI_LIVE.rooms : [];
  const matchedRooms = aiMatchingRooms(queryText);
  const scopedRooms = matchedRooms.length ? matchedRooms : allRooms;
  const freeRooms = scopedRooms.filter(function (r) { return aiNumber(r.available_beds) > 0; });
  if (freeRooms.length) {
    lines.push('\n**Rooms with free beds' + (matchedRooms.length ? ' (matching this question)' : '') + '**');
    freeRooms.forEach(function (r) {
      lines.push('   – Room ' + r.room_number + ' · ' + r.ward + ' · ' + r.room_type + ' · ' + aiNumber(r.available_beds) + '/' + aiNumber(r.total_beds) + ' free · ' + aiMoney(r.daily_rate) + '/day');
    });
  }
  return lines.join('\n');
}

function aiAppointmentsAnswer() {
  const rows = DATA.appointments || [];
  if (!rows.length) return '📅 No appointments are recorded in CARE OS right now.';
  const counts = aiCountByStatus(rows);
  const dates = [];
  rows.forEach(function (r) { if (r.date && dates.indexOf(r.date) === -1) dates.push(r.date); });
  const today = new Date();
  const todayLabel = today.toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' });
  const todayRows = rows.filter(function (r) { return String(r.date || '').trim() === todayLabel; });

  const lines = ['📅 **Appointments**'];
  if (todayRows.length) {
    lines.push('• Scheduled for today (' + todayLabel + '): **' + todayRows.length + '**');
  } else {
    lines.push('• No appointment is dated today (' + todayLabel + '). Every appointment on file is dated: ' + dates.join(', ') + '.');
  }
  lines.push('• Total on file: **' + rows.length + '** — ' + Object.keys(counts).map(function (k) { return counts[k] + ' ' + k.toLowerCase(); }).join(' · '));
  lines.push('\n**Schedule**');
  rows.forEach(function (r) {
    lines.push('   – ' + aiJoin(r.date) + ' ' + aiJoin(r.time) + ' · ' + r.patient + ' with ' + r.doctor + ' · ' + aiJoin(r.treatment) + ' · ' + aiJoin(r.status));
  });
  return lines.join('\n');
}

function aiDoctorsAnswer(specialtyFilter) {
  let doctors = DATA.doctors || [];
  if (specialtyFilter) {
    const filtered = doctors.filter(function (d) { return String(d.specialty || '').toLowerCase().indexOf(specialtyFilter) !== -1; });
    if (filtered.length) doctors = filtered;
  }
  if (!doctors.length) return '🩺 No physician matches that specialty in the current staff records.';
  const available = doctors.filter(function (d) { return String(d.status).toLowerCase() === 'available'; });
  const offline = doctors.filter(function (d) { return String(d.status).toLowerCase() !== 'available'; });
  const lines = ['🩺 **Physician availability** — ' + available.length + ' of ' + doctors.length + ' available'];
  lines.push('\n**Available now**');
  if (!available.length) lines.push('   – None of the listed physicians is currently marked available.');
  available.forEach(function (d) {
    lines.push('   – **' + d.name + '** · ' + d.specialty + ' · ' + d.hours + ' · ' + d.patients + ' patients on caseload');
  });
  if (offline.length) {
    lines.push('\n**Not available**');
    offline.forEach(function (d) {
      lines.push('   – ' + d.name + ' · ' + d.specialty + ' · duty hours ' + d.hours);
    });
  }
  return lines.join('\n');
}

function aiDoctorProfile(d) {
  const appointments = (DATA.appointments || []).filter(function (a) { return a.doctor === d.name; });
  return '🩺 **Physician profile — ' + d.name + '**\n'
    + '• **Specialty**: ' + aiJoin(d.specialty) + '\n'
    + '• **Availability**: **' + aiJoin(d.status) + '** · duty hours ' + aiJoin(d.hours) + '\n'
    + '• **Caseload on record**: ' + aiNumber(d.patients) + ' patients · ' + aiNumber(d.appointments) + ' appointments\n'
    + '• **Appointments in CARE OS**: ' + appointments.length + (appointments.length ? ' (' + appointments.map(function (a) { return a.patient + ' at ' + a.time; }).join(', ') + ')' : '') + '\n'
    + '• **Contact**: ' + aiJoin(d.email) + ' · ' + aiJoin(d.phone) + '\n'
    + '• **About**: ' + aiJoin(d.about);
}

function aiInventoryAnswer(focusName) {
  const items = aiInventoryRows();
  if (!items.length) return '💊 No pharmacy lines are recorded in CARE OS.';
  if (focusName) {
    const match = items.filter(function (i) {
      const name = String(i.name || '').toLowerCase();
      return name.indexOf(focusName) !== -1 || name.split(' ')[0] === focusName;
    })[0];
    if (match) {
      return '💊 **Pharmacy — ' + match.name + '**\n'
        + '• **Stock on hand**: **' + match.stock + ' ' + aiJoin(match.unit) + '**\n'
        + '• **Reorder level**: ' + match.reorder + ' ' + aiJoin(match.unit) + ' · **' + match.level + '**\n'
        + '• **Capacity**: ' + aiNumber(match.maxStock) + ' ' + aiJoin(match.unit) + '\n'
        + '• **Category**: ' + aiJoin(match.category) + ' · unit price ' + aiMoney(match.price)
        + '\n\nStock is computed from the quantity on hand against the reorder level, not from a stored flag.';
    }
  }
  const alerts = items.filter(function (i) { return i.level !== 'OK'; }).sort(function (a, b) { return a.stock - b.stock; });
  const lines = ['💊 **Pharmacy stock check** — ' + items.length + ' lines, ' + alerts.length + ' need attention'];
  if (alerts.length) {
    lines.push('\n**At or below reorder level**');
    alerts.forEach(function (i) {
      lines.push('   – **' + i.name + '**: ' + i.stock + ' ' + aiJoin(i.unit) + ' left (reorder at ' + i.reorder + ') · **' + i.level + '**');
    });
  } else {
    lines.push('\nAll pharmacy lines are above their reorder level.');
  }
  lines.push('\n**Full stock list**');
  items.forEach(function (i) {
    lines.push('   – ' + i.name + ': ' + i.stock + '/' + aiNumber(i.maxStock) + ' ' + aiJoin(i.unit) + ' · ' + i.level);
  });
  return lines.join('\n');
}

function aiBillingAnswer() {
  const rows = DATA.billing || [];
  if (!rows.length) return '💳 No invoices are recorded in CARE OS.';
  const total = rows.reduce(function (s, b) { return s + aiNumber(b.amount); }, 0);
  const byStatus = aiCountByStatus(rows);
  const outstandingRows = rows.filter(function (b) { return String(b.status).toLowerCase() !== 'paid'; });
  const outstanding = outstandingRows.reduce(function (s, b) { return s + aiNumber(b.amount); }, 0);
  const lines = ['💳 **Billing overview**'];
  lines.push('• Invoices on file: **' + rows.length + '** — ' + Object.keys(byStatus).map(function (k) { return byStatus[k] + ' ' + k.toLowerCase(); }).join(' · '));
  lines.push('• Total invoiced: **' + aiMoney(total) + '**');
  lines.push('• Collected (paid): **' + aiMoney(total - outstanding) + '**');
  lines.push('• Outstanding: **' + aiMoney(outstanding) + '** across ' + outstandingRows.length + ' invoice' + (outstandingRows.length === 1 ? '' : 's'));
  if (outstandingRows.length) {
    lines.push('\n**Unpaid invoices**');
    outstandingRows.forEach(function (b) {
      lines.push('   – ' + b.id + ' · ' + b.patient + ' · ' + aiMoney(b.amount) + ' · ' + b.status + ' · ' + aiJoin(b.date));
    });
  }
  return lines.join('\n');
}

function aiEmergencyAnswer() {
  const rooms = Array.isArray(AI_LIVE.rooms) ? AI_LIVE.rooms : [];
  const criticalRooms = rooms.filter(function (r) { return /icu|critical|emergency|recovery/i.test(String(r.ward || '') + ' ' + String(r.room_type || '')); });
  const admitted = aiAdmittedRows();
  const criticalPatients = admitted.filter(function (a) { return /icu|critical|telemetry|post-op|emergency/i.test(String(a.ward || '') + ' ' + String(a.condition || '')); });

  const lines = ['🚨 **Emergency and critical-care status**'];
  lines.push('• This copilot reports records only — it cannot page staff, dispatch a team or trigger a Code Blue. Use your hospital\'s emergency line for that.');
  if (criticalRooms.length) {
    lines.push('• Critical-care rooms in the registry: ' + criticalRooms.length);
    criticalRooms.forEach(function (r) {
      lines.push('   – Room ' + r.room_number + ' · ' + r.ward + ' (' + r.room_type + ') · ' + aiNumber(r.available_beds) + '/' + aiNumber(r.total_beds) + ' beds free');
    });
  } else {
    lines.push('• The live room registry is not reachable from this view, so free critical-care beds cannot be confirmed.');
  }
  lines.push('• Admissions flagged as critical or under telemetry: **' + criticalPatients.length + '**');
  criticalPatients.forEach(function (a) {
    lines.push('   – ' + a.patient_name + ' · Room ' + a.room_number + ' · ' + a.condition + ' · ' + a.doctor_assigned);
  });
  return lines.join('\n');
}

function aiFallbackAnswer(query) {
  const admitted = aiAdmittedRows().length;
  return '🤔 **I could not find an answer to "' + query + '" in the CARE OS records.**\n\n'
    + 'I do not guess: every answer I give is read from the records you see in the app. What is on file right now:\n'
    + '• **' + DATA.patients.length + '** patient charts · **' + admitted + '** current admissions\n'
    + '• **' + (DATA.appointments || []).length + '** appointments · **' + DATA.doctors.length + '** physicians\n'
    + '• **' + (DATA.inventory || []).length + '** pharmacy lines · **' + (DATA.billing || []).length + '** invoices\n\n'
    + 'Try asking about **a patient by name or ID**, a **vital sign** (blood pressure, glucose, cholesterol, heart rate, BMI, haemoglobin), **bed availability**, **appointment counts**, **physician availability**, **pharmacy stock** or **billing totals**.';
}

// ── entry point used by the chat UI ───────────
function answerCopilotQuery(query) {
  const raw = String(query || '').trim();
  if (!raw) return 'Ask me about a patient, a bed, an appointment, a physician, the pharmacy or billing.';

  const q = ' ' + raw.toLowerCase().replace(/[^a-z0-9\/\s#.-]/g, ' ').replace(/\s+/g, ' ').trim() + ' ';
  const words = aiWords(raw);

  // social
  if (aiHasAny(words, ['hello', 'hi', 'hey', 'namaste', 'hola', 'greetings']) && words.length <= 5) return aiGreeting();
  if (aiHasAny(words, ['thanks', 'thank', 'thankyou', 'cheers'])) return 'You are welcome. Ask me another question about the hospital records whenever you need.';
  if (aiHasAny(words, ['help', 'capabilities', 'commands']) || /what can you (do|answer)|how do you work/.test(q)) return aiCapabilities();

  // named records
  const bedWords = aiHasAny(words, ['bed', 'beds', 'room', 'rooms', 'ward', 'wards', 'occupancy']);
  const patients = aiFindPatients(q, words, bedWords);
  const doctors = aiFindDoctors(q, words);
  const metric = aiDetectMetric(q);

  const wantsAllergy = /allerg/.test(q);
  const wantsMeds = /prescription|medication|medicine|meds|drug|taking/.test(q);

  if (patients.length === 1) {
    const p = patients[0];
    if (metric) return aiMetricForPatient(metric, p);
    if (wantsAllergy) return aiPatientFocus(p, 'allergy');
    if (wantsMeds) return aiPatientFocus(p, 'meds');
    return aiPatientChart(p);
  }
  if (patients.length > 1) return aiPatientShortlist(patients, metric);
  if (doctors.length === 1 && patients.length === 0) return aiDoctorProfile(doctors[0]);

  // plain-language requests for the whole picture
  if (/\b(summary|summarise|summarize|overview|status report|snapshot|dashboard|round up|rundown)\b/.test(q)
    && !/\b(bill|billing|invoice|invoices|stock|pharmacy|appointment|appointments)\b/.test(q)) {
    return aiCountsAnswer();
  }
  if (/\b(what'?s going on|how is the hospital|how are we doing|anything i should know)\b/.test(q)) {
    return aiCountsAnswer();
  }

  // counts
  if (/how many|how much|total|count|number of/.test(q)
    && aiHasAny(words, ['patient', 'patients', 'bed', 'beds', 'admission', 'admissions', 'appointment', 'appointments', 'doctor', 'doctors', 'staff', 'invoice', 'invoices'])
    && !aiHasAny(words, ['bed', 'beds', 'room', 'rooms', 'ward', 'wards', 'occupancy', 'allotment', 'allotments'])) {
    return aiCountsAnswer();
  }
  if (/overview|summary|overall|status report|everything/.test(q) && aiHasAny(words, ['hospital', 'facility', 'operations', 'system', 'today'])) {
    return aiCountsAnswer();
  }

  // beds and rooms
  if (aiHasAny(words, ['bed', 'beds', 'room', 'rooms', 'ward', 'wards', 'admit', 'admitted', 'admission', 'admissions', 'allotment', 'allotments', 'inpatient', 'inpatients', 'occupancy', 'occupied', 'vacant']) && !aiHasAny(words, ['appointment', 'appointments'])) {
    return aiBedsAnswer(q);
  }

  // appointments
  if (aiHasAny(words, ['appointment', 'appointments', 'booking', 'bookings', 'schedule', 'scheduled', 'visit', 'visits', 'consult', 'consultation'])) {
    if (aiHasAny(words, ['doctor', 'doctors', 'staff', 'physician', 'physicians'])) return aiDoctorsAnswer(aiDetectSpecialty(q));
    return aiAppointmentsAnswer();
  }

  // physicians
  if (aiHasAny(words, ['doctor', 'doctors', 'physician', 'physicians', 'staff', 'surgeon', 'specialist', 'duty', 'roster', 'shift'])) {
    return aiDoctorsAnswer(aiDetectSpecialty(q));
  }

  // pharmacy
  if (aiHasAny(words, ['medicine', 'medicines', 'medication', 'medications', 'drug', 'drugs', 'pharmacy', 'stock', 'stocks', 'inventory', 'reorder', 'tablets'])) {
    const inventory = aiInventoryRows();
    let focus = null;
    for (let i = 0; i < inventory.length; i++) {
      const head = String(inventory[i].name || '').toLowerCase().split(' ')[0];
      if (head && head.length > 3 && q.indexOf(head) !== -1) { focus = head; break; }
    }
    return aiInventoryAnswer(focus);
  }

  // billing
  if (aiHasAny(words, ['revenue', 'bill', 'billing', 'invoice', 'invoices', 'payment', 'payments', 'financial', 'money', 'outstanding', 'collected'])) {
    return aiBillingAnswer();
  }

  // vitals without a named patient
  if (metric) return aiMetricReference(metric);

  // emergency
  if (/emergency|code blue|icu|critical|rapid response/.test(q)) return aiEmergencyAnswer();

  // empty/whole lists
  if (aiHasAny(words, ['patients', 'charts', 'records', 'directory'])) {
    const lines = ['📁 **Patient directory — ' + DATA.patients.length + ' charts on file**'];
    DATA.patients.forEach(function (p) {
      lines.push('• **' + p.name + '** (ID #' + p.id + ') · ' + p.age + ' yrs · ' + aiJoin(p.status) + ' · ' + aiJoin(p.conditions) + ' · BP ' + aiJoin(p.bp));
    });
    lines.push('\nAsk about any patient by name or ID for the full chart.');
    return lines.join('\n');
  }
  if (aiHasAny(words, ['doctors', 'physicians'])) return aiDoctorsAnswer(null);

  return aiFallbackAnswer(raw);
}

function aiDetectSpecialty(q) {
  const specialties = ['general medicine', 'cardiology', 'pediatrics', 'orthopedics', 'dermatology', 'neurology', 'radiology'];
  for (let i = 0; i < specialties.length; i++) {
    if (q.indexOf(specialties[i]) !== -1) return specialties[i];
  }
  return null;
}

function aiSpeechSnippet(answer) {
  const plain = String(answer || '')
    .replace(/\*\*/g, '')
    .replace(/[•_#⚠️📋🩺💊📅🛏️💳🚨📊📁🤔👋]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  const firstSentence = plain.match(/^[^.]*\./);
  return (firstSentence ? firstSentence[0] : plain).slice(0, 220);
}

// Backwards-compatible alias (older call sites use this name)
function generateComprehensiveClinicalAnswer(query) {
  return answerCopilotQuery(query);
}

let selectedLang = 'en-US';
function changeAiLanguage(lang) {
  selectedLang = lang;
  showToast(`Copilot voice set to ${lang}`);
  const greetings = {
    'en-US': "Hello, I am Mr.Doc. How can I help you?",
    'en-GB': "Good day. I am Mr.Doc, your clinical assistant.",
    'hi-IN': "नमस्ते, मैं मिस्टर डॉक हूँ। मैं आपकी क्या मदद कर सकता हूँ?",
    'te-IN': "నమస్కారం, నేను మిస్టర్ డాక్. నేను మీకు ఎలా సహాయపడగలను?",
    'ta-IN': "வணக்கம், நான் மிஸ்டர் டாக். நான் உங்களுக்கு எவ்வாறு உதவ முடியும்?",
    'es-ES': "Hola, soy el Sr. Doc. ¿Cómo puedo ayudarte hoy?",
    'fr-FR': "Bonjour, je suis Mr.Doc. Comment puis-je vous aider?",
    'de-DE': "Guten Tag, ich bin Mr.Doc. Wie kann ich Ihnen helfen?"
  };
  const msg = greetings[lang] || greetings['en-US'];
  speak(msg, 'speak');
}

// ═══════════════════════════════════════════════
// AUTHENTIC MR.DOC EMOTIONS & LIP-SYNC ENGINE
// (Directly adapted from MR.DOC app.js: showH, showB, setExp, scheduleBlink)
// ═══════════════════════════════════════════════
let expTimer, talkTimer, gestTimer, blinkTimer;
let currentExp = 'happy';

function showH(frameKey) {
  const hd = document.getElementById('mrdoc-hd');
  if (!hd) return;
  hd.querySelectorAll('img').forEach(img => {
    img.classList.toggle('on', img.dataset.k === frameKey);
  });
}

function showB(frameKey) {
  const bd = document.getElementById('mrdoc-bd');
  if (!bd) return;
  bd.querySelectorAll('img').forEach(img => {
    img.classList.toggle('on', img.dataset.k === frameKey);
  });
}

function setEmotion(emotionKey, holdTime) {
  clearTimeout(expTimer);
  clearTimeout(talkTimer);
  clearTimeout(gestTimer);
  currentExp = emotionKey;
  
  const stage = document.getElementById('mrdoc-stage-container');
  const bubble = document.getElementById('ai-thought-bubble');
  
  // Mapping matching MR.DOC app.js EXP:
  // happy:      { m: "idle",  h: "happy", b: "b_down" }
  // look/think: { m: "think", h: "gaze",  b: "b_down" }
  // speak:      { m: "speak", h: "happy", b: "b_open" }
  // supportive: { m: "cheer", h: "say_a", b: "b_wide" }
  if (stage) {
    if (emotionKey === 'think') stage.dataset.mode = 'think';
    else if (emotionKey === 'speak') stage.dataset.mode = 'speak';
    else stage.dataset.mode = 'idle';
  }

  if (bubble) {
    bubble.style.display = (emotionKey === 'think') ? 'block' : 'none';
  }

  if (window.syncEmotionUI) window.syncEmotionUI(emotionKey);

  if (emotionKey === 'think') {
    showH('gaze');
    showB('b_down');
  } else if (emotionKey === 'concerned') {
    showH('gaze');
    showB('b_down');
  } else if (emotionKey === 'supportive') {
    showH('say_a');
    showB('b_wide');
  } else if (emotionKey === 'speak') {
    // Dynamic lip-sync speech loop switching mouth phonemes [say_a, say_b, say_c, happy]
    const mouthPhonemes = ['say_a', 'say_b', 'say_c', 'say_a', 'happy', 'say_b', 'say_c', 'happy'];
    let n = 0;
    showB('b_open');
    const stepLipSync = () => {
      showH(mouthPhonemes[n++ % mouthPhonemes.length]);
      talkTimer = setTimeout(stepLipSync, 130);
    };
    stepLipSync();
    
    // Expressive body gesture while talking
    const bodyGestures = ['b_open', 'b_wide', 'b_open'];
    let m = 0;
    const stepGesture = () => {
      gestTimer = setTimeout(() => {
        if (currentExp === 'speak') {
          showB(bodyGestures[++m % bodyGestures.length]);
          stepGesture();
        }
      }, 2600);
    };
    stepGesture();
  } else if (emotionKey === 'wave') {
    showH('say_a');
    showB('b_open');
  } else if (emotionKey === 'reassure' || emotionKey === 'explain') {
    showH('say_b');
    showB('b_wide');
  } else {
    // Default happy / idle with occasional subtle hand gesture
    showH('happy');
    showB('b_down');
    
    const gestureLoop = () => {
      gestTimer = setTimeout(() => {
        if (currentExp === 'happy') {
          showB('b_open');
          showH('say_a');
          gestTimer = setTimeout(() => {
            if (currentExp === 'happy') {
              showB('b_down');
              showH('happy');
            }
            gestureLoop();
          }, 1600);
        } else {
          gestureLoop();
        }
      }, 7000 + Math.random() * 4000);
    };
    gestureLoop();
  }

  if (holdTime) {
    expTimer = setTimeout(() => setEmotion('happy'), holdTime);
  }
}

// Eye blinking scheduler (blinks every 2.6 - 5.6 seconds)
function scheduleNaturalBlink() {
  clearTimeout(blinkTimer);
  blinkTimer = setTimeout(() => {
    if (currentExp !== 'speak') {
      const activeImg = document.querySelector('#mrdoc-hd img.on');
      const prevKey = activeImg ? activeImg.dataset.k : 'happy';
      showH('blink');
      setTimeout(() => {
        if (currentExp !== 'speak') showH(prevKey);
        scheduleNaturalBlink();
      }, 140);
    } else {
      scheduleNaturalBlink();
    }
  }, 2600 + Math.random() * 3000);
}

// Each emotion gets its own delivery: pace, pitch and volume.
// Calm for bad news, brighter for greetings, steady for explanations.
const AI_VOICE_PROFILES = {
  happy:      { rate: 1.04, pitch: 1.08, volume: 0.95 },
  speak:      { rate: 0.97, pitch: 1.02, volume: 0.95 },
  wave:       { rate: 1.05, pitch: 1.12, volume: 1.00 },
  think:      { rate: 0.90, pitch: 1.00, volume: 0.85 },
  explain:    { rate: 0.94, pitch: 1.00, volume: 0.95 },
  reassure:   { rate: 0.88, pitch: 0.94, volume: 0.92 },
  supportive: { rate: 1.00, pitch: 1.05, volume: 0.95 }
};

// Multilingual Voice System
function speak(text, emotion='speak') {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  
  const trySpeak = () => {
    const voices = speechSynthesis.getVoices();
    const langPrefix = selectedLang.split('-')[0];
    const match = voices.find(v => v.lang.replace('_','-') === selectedLang) ||
                  voices.find(v => v.lang.startsWith(langPrefix)) ||
                  voices.find(v => v.name.includes('Google') && v.lang.startsWith('en')) ||
                  voices[0];
                  
    if (match) u.voice = match;
    u.lang = selectedLang;
    const profile = AI_VOICE_PROFILES[emotion] || AI_VOICE_PROFILES.speak;
    u.rate = profile.rate;
    u.pitch = profile.pitch;
    u.volume = profile.volume;
    // The mouth always animates while speaking; the emotion shapes delivery,
    // and the matching pose is held for a moment once the line ends.
    setEmotion('speak');
    const settle = () => setEmotion(emotion === 'speak' || emotion === 'happy' ? 'happy' : emotion, 2400);
    let safety = setTimeout(settle, Math.min(22000, 1500 + String(text).split(/\s+/).length * 380));
    u.onend = () => { clearTimeout(safety); settle(); };
    speechSynthesis.speak(u);
  };

  if (speechSynthesis.getVoices().length) trySpeak();
  else speechSynthesis.onvoiceschanged = trySpeak;
}

let isListening = false;
// Tells the voice orb when the mic is live so it pulses with the listener.
function setVoiceOrbListening(active) {
  const orb = document.getElementById('voice-orb');
  if (orb && orb.contentWindow) {
    orb.contentWindow.postMessage({ orb: { type: 'listening', value: !!active } }, '*');
  }
}

function toggleVoiceInput() {
  const btn = document.getElementById('voice-btn');
  if (!window.SpeechRecognition && !window.webkitSpeechRecognition) {
    showToast('Voice input not supported in this browser');
    setVoiceOrbListening(false);
    return;
  }
  if (isListening) {
    isListening = false;
    if (btn) btn.classList.remove('listening');
    setVoiceOrbListening(false);
    return;
  }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const rec = new SR();
  rec.lang = 'en-US';
  rec.onresult = e => {
    document.getElementById('ai-input').value = e.results[0][0].transcript;
    isListening = false;
    if (btn) btn.classList.remove('listening');
    setVoiceOrbListening(false);
  };
  rec.onend = () => {
    isListening = false;
    if (btn) btn.classList.remove('listening');
    setVoiceOrbListening(false);
  };
  rec.start();
  isListening = true;
  if (btn) btn.classList.add('listening');
  setVoiceOrbListening(true);
  showToast('🎤 Listening...');
}

// The orb lives in an iframe and reports taps / missing WebGL back here.
window.addEventListener('message', (event) => {
  const payload = event.data && event.data.orb;
  if (!payload) return;
  if (payload.type === 'activate') toggleVoiceInput();
  if (payload.type === 'nogl') {
    const orb = document.getElementById('voice-orb');
    if (orb) orb.style.display = 'none';
  }
});

// ═══════════════════════════════════════════════
// ROOM & BED ALLOTMENT SYSTEM
// ═══════════════════════════════════════════════
function renderAllotments() {
  const tbody = document.getElementById('allotments-tbody');
  if (!tbody) return;
  const q = (document.getElementById('allotment-search')?.value || '').toLowerCase();
  const wardFilter = document.getElementById('ward-filter')?.value || 'All';
  const statusFilter = document.getElementById('allotment-status-filter')?.value || 'All';

  let list = DATA.allotments || [];
  if (q) {
    list = list.filter(a =>
      (a.patient_name || '').toLowerCase().includes(q) ||
      (a.room_number || '').toLowerCase().includes(q) ||
      (a.ward || '').toLowerCase().includes(q) ||
      (a.doctor_assigned || '').toLowerCase().includes(q)
    );
  }
  if (wardFilter !== 'All') {
    list = list.filter(a => a.ward === wardFilter);
  }
  if (statusFilter !== 'All') {
    list = list.filter(a => a.status === statusFilter);
  }

  // Update counts
  const admittedCount = (DATA.allotments || []).filter(a => a.status === 'Admitted').length;
  const badge = document.getElementById('allotment-badge');
  if (badge) badge.textContent = admittedCount;
  const statOcc = document.getElementById('stat-occupied-beds');
  if (statOcc) statOcc.textContent = admittedCount;
  const statAvail = document.getElementById('stat-available-beds');
  if (statAvail) statAvail.textContent = Math.max(0, 18 - admittedCount);

  if (list.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:36px;color:var(--slate-400)">No room allotments matching filters</td></tr>`;
    return;
  }

  tbody.innerHTML = list.map(a => {
    const isAdmitted = a.status === 'Admitted';
    const statusBadge = isAdmitted 
      ? `<span class="badge badge-confirmed" style="background:#CCFBF1;color:#0F766E">● Admitted</span>` 
      : `<span class="badge badge-cancelled" style="background:#F1F5F9;color:#64748B">✓ Discharged</span>`;
    
    return `
      <tr>
        <td>
          <div style="display:flex;align-items:center;gap:10px">
            <div class="ava ava-sm" style="background:linear-gradient(135deg,var(--teal),#0284c7)">${a.patient_name.split(' ').map(n=>n[0]).join('')}</div>
            <div>
              <div style="font-weight:600;color:var(--navy)">${a.patient_name}</div>
              <div style="font-size:11px;color:var(--slate-400)">Condition: ${a.condition || 'Observation'}</div>
            </div>
          </div>
        </td>
        <td>
          <div style="font-weight:600;color:var(--navy)">Room ${a.room_number}</div>
          <div style="font-size:11px;color:var(--teal)">${a.ward}</div>
        </td>
        <td>
          <span style="display:inline-block;padding:2px 8px;border-radius:6px;background:var(--slate-100);font-weight:600;font-size:12px;color:var(--slate-700)">${a.bed_number}</span>
        </td>
        <td>
          <div style="font-size:13px;font-weight:500">${a.doctor_assigned}</div>
        </td>
        <td>
          <div style="font-size:12px;color:var(--slate-500)">${a.admitted_date}</div>
        </td>
        <td>
          <div style="font-size:12px;color:var(--slate-500)">${a.expected_discharge || 'Ongoing'}</div>
        </td>
        <td>${statusBadge}</td>
        <td>
          <div style="display:flex;gap:6px">
            ${isAdmitted ? `
              <button class="action-btn" onclick="dischargePatient(${a.id})" title="Discharge patient and release bed" style="color:var(--red)">
                Discharge
              </button>
            ` : `
              <span style="font-size:11px;color:var(--slate-400)">Closed on ${a.discharged_date || 'Discharged'}</span>
            `}
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function autoFillPatientData() {
  const sel = document.getElementById('modal-allot-patient');
  const opt = sel.options[sel.selectedIndex];
  const cond = opt.getAttribute('data-cond');
  if (cond) {
    document.getElementById('modal-allot-condition').value = cond;
  }
}

function updateRoomOptions() {
  const ward = document.getElementById('modal-allot-ward').value;
  const roomSel = document.getElementById('modal-allot-room');
  const wardRooms = {
    'Post-Op Recovery': [['205', 'Bed-A'], ['205', 'Bed-B']],
    'Cardiology Wing': [['201', 'Bed-A'], ['201', 'Bed-B'], ['202', 'Bed-A']],
    'Pediatric Wing': [['301', 'Bed-A'], ['301', 'Bed-B'], ['302', 'Bed-A']],
    'General Ward A': [['101', 'Bed-A'], ['101', 'Bed-B'], ['101', 'Bed-C'], ['102', 'Bed-A']],
    'Emergency ICU': [['108', 'Bed-A'], ['108', 'Bed-B']],
    'Deluxe VIP Suite': [['401', 'Bed-VIP'], ['402', 'Bed-VIP']]
  };
  const list = wardRooms[ward] || [['101', 'Bed-A']];
  roomSel.innerHTML = list.map(([r, b]) => `<option value="${r}|${b}">Room ${r} (${b})</option>`).join('');
}

async function submitNewAllotment() {
  const patientSel = document.getElementById('modal-allot-patient');
  const patientName = patientSel.value;
  const patientId = patientSel.options[patientSel.selectedIndex].getAttribute('data-id');
  const ward = document.getElementById('modal-allot-ward').value;
  const [roomNum, bedNum] = document.getElementById('modal-allot-room').value.split('|');
  const admDate = document.getElementById('modal-allot-date').value;
  const expDate = document.getElementById('modal-allot-exp').value;
  const doctor = document.getElementById('modal-allot-doctor').value;
  const condition = document.getElementById('modal-allot-condition').value;

  const payload = {
    patient_id: parseInt(patientId) || null,
    patient_name: patientName,
    room_number: roomNum,
    bed_number: bedNum,
    ward: ward,
    admitted_date: admDate,
    expected_discharge: expDate,
    doctor_assigned: doctor,
    condition: condition
  };

  // 1. Try syncing with backend server
  try {
    const res = await fetch(`${BACKEND_URL}/api/allotments`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      const resp = await res.json();
      payload.id = resp.allotment_id;
    } else {
      payload.id = Date.now();
    }
  } catch (err) {
    payload.id = Date.now();
  }

  payload.status = 'Admitted';
  DATA.allotments.unshift(payload);

  closeModal('add-allotment-modal');
  renderAllotments();
  showToast(`Room ${roomNum} (${bedNum}) successfully allotted to ${patientName}!`);
  speak(`Room ${roomNum} has been allotted to patient ${patientName}.`);
}

async function dischargePatient(allotmentId) {
  const item = DATA.allotments.find(a => a.id === allotmentId);
  if (!item) return;

  if (!confirm(`Confirm discharge for ${item.patient_name} from Room ${item.room_number}? This will free the bed.`)) {
    return;
  }

  try {
    await fetch(`${BACKEND_URL}/api/allotments/${allotmentId}/discharge`, { method: 'POST' });
  } catch (err) {}

  item.status = 'Discharged';
  item.discharged_date = new Date().toISOString().slice(0, 10);
  renderAllotments();
  showToast(`${item.patient_name} discharged. Bed is now available.`);
  speak(`${item.patient_name} has been discharged and Room ${item.room_number} is now cleared.`);
}

async function fetchBackendAllotments(silent) {
  try {
    const res = await fetch(`${BACKEND_URL}/api/allotments`);
    if (res.ok) {
      const data = await res.json();
      if (Array.isArray(data) && data.length > 0) {
        DATA.allotments = data;
        renderAllotments();
        if (!silent) showToast('Synchronised with the SQLite database.');
        return true;
      }
    }
  } catch (err) {
    if (!silent) showToast('Backend offline or not reachable. Running on local in-memory store.');
  }
  return false;
}

// ═══════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════
/* ═══════════════════════════════════════════════════════════
   CARE OS — UI MODULE 2
   Currency (INR), notifications, invoices, search, account menu,
   collapsible navigation and emotion-synced speech.
═══════════════════════════════════════════════════════════ */

// ── Money: everything is billed in Indian rupees ──────────
const INR_PER_UNIT = 60;                    // seeded demo amounts are USD-scale
function inrAmount(amount) { return Number(amount || 0) * INR_PER_UNIT; }
function inr(amount, decimals) {
  const digits = decimals === undefined ? 0 : decimals;
  return '₹' + inrAmount(amount).toLocaleString('en-IN', {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits
  });
}
function aiMoney(n) { return inr(n); }      // the copilot speaks INR as well
function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}

// ── Dashboard numbers ─────────────────────────────────────
function renderDashboardStats() {
  const billing = DATA.billing || [];
  const billed = billing.reduce((s, b) => s + aiNumber(b.amount), 0);
  const paid = billing.filter(b => b.status === 'Paid').reduce((s, b) => s + aiNumber(b.amount), 0);
  const due = billed - paid;
  const patients = DATA.patients || [];
  const active = patients.filter(p => String(p.status).toLowerCase() === 'active').length;
  const appts = DATA.appointments || [];
  const pending = appts.filter(a => a.status === 'Pending').length;
  const beds = aiBedStats();
  const admitted = aiAdmittedRows().length;

  setText('dash-revenue', inr(paid));
  setText('dash-revenue-sub', inr(due) + ' still outstanding');
  setText('dash-patients', String(patients.length));
  setText('dash-patients-sub', active + ' active records');
  setText('dash-appts', String(appts.length));
  setText('dash-appts-sub', pending + ' awaiting confirmation');
  setText('dash-beds', String(beds ? beds.occupied : admitted));
  setText('dash-beds-sub', beds ? beds.available + ' of ' + beds.totalBeds + ' beds free' : admitted + ' admissions open');
}

// ── Billing: live totals, filters, invoices ───────────────
let CURRENT_INVOICE = null;
const INVOICE_CSS = 'body{font-family:Inter,Arial,sans-serif;color:#0B1329;padding:28px;max-width:720px;margin:0 auto}'
  + 'table{width:100%;border-collapse:collapse;margin:14px 0}th{font-size:10px;letter-spacing:.1em;text-transform:uppercase;'
  + 'color:#64748B;text-align:left;padding:7px 8px;background:#F8FAFC}td{padding:9px 8px;font-size:12px;border-bottom:1px solid #E2E8F0}'
  + '.inv-head{display:flex;justify-content:space-between;border-bottom:1px solid #E2E8F0;padding-bottom:14px}'
  + '.inv-brand{display:flex;gap:10px;align-items:center}.inv-brand-name{font-size:15px;font-weight:700}'
  + '.inv-brand-sub,.inv-meta{font-size:10.5px;color:#64748B}.inv-meta{text-align:right;line-height:1.7}'
  + '.inv-party-label{font-size:9.5px;letter-spacing:.12em;text-transform:uppercase;color:#94A3B8;margin-bottom:3px}'
  + '.inv-party-name{font-size:12.5px;font-weight:600}.inv-party-sub{font-size:11px;color:#64748B;line-height:1.55}'
  + '.inv-parties{display:flex;justify-content:space-between;padding:14px 0}'
  + '.inv-totals{width:56%;margin-left:auto;font-size:12px}.inv-totals div{display:flex;justify-content:space-between;padding:5px 0;color:#64748B}'
  + '.inv-totals .grand{border-top:1px solid #E2E8F0;margin-top:4px;padding-top:8px;color:#0B1329;font-weight:700;font-size:13.5px}'
  + '.inv-foot{margin-top:14px;font-size:10.5px;color:#94A3B8;line-height:1.6;border-top:1px dashed #E2E8F0;padding-top:10px}'
  + '.badge{display:inline-block;padding:2px 9px;border-radius:99px;font-size:10px;font-weight:600}'
  + '.b-paid{background:#D1FAE5;color:#059669}.b-pending{background:#FEF3C7;color:#D97706}.b-overdue{background:#FEE2E2;color:#DC2626}';

function invoiceModel(invoice) {
  const inclusive = inrAmount(invoice.amount);
  const subtotal = Math.round(inclusive / 1.05);
  return { subtotal: subtotal, gst: inclusive - subtotal, total: inclusive };
}

function invoiceHtml(invoice) {
  const m = invoiceModel(invoice);
  const patient = (DATA.patients || []).find(p => p.name === invoice.patient);
  const cls = invoice.status === 'Paid' ? 'b-paid' : invoice.status === 'Overdue' ? 'b-overdue' : 'b-pending';
  return `
    <div class="invoice-doc">
      <div class="inv-head">
        <div class="inv-brand">
          <img src="assets/mrdoc-health-logo.svg" alt="">
          <div>
            <div class="inv-brand-name">CARE OS AI Hospital</div>
            <div class="inv-brand-sub">WellNest Health System · GSTIN 27AABCU9603R1ZM</div>
          </div>
        </div>
        <div class="inv-meta">
          TAX INVOICE<br>
          <b>${invoice.id}</b><br>
          ${invoice.date}
        </div>
      </div>
      <div class="inv-parties">
        <div>
          <div class="inv-party-label">Billed to</div>
          <div class="inv-party-name">${invoice.patient}</div>
          <div class="inv-party-sub">
            ${patient ? 'ID #' + patient.id + ' · ' + patient.phone : 'Patient account'}<br>
            ${patient ? patient.address : ''}
          </div>
        </div>
        <div style="text-align:right">
          <div class="inv-party-label">Status</div>
          <span class="badge ${cls}">${invoice.status}</span>
          <div class="inv-party-sub" style="margin-top:6px">Consultant<br>${invoice.doctor}</div>
        </div>
      </div>
      <table>
        <thead><tr><th>Description</th><th>Qty</th><th style="text-align:right">Rate</th><th style="text-align:right">Amount</th></tr></thead>
        <tbody>
          <tr>
            <td>${invoice.treatment}<br><span style="font-size:10.5px;color:#94A3B8">Consultation &amp; procedure charges</span></td>
            <td>1</td>
            <td style="text-align:right">₹${m.subtotal.toLocaleString('en-IN')}</td>
            <td style="text-align:right">₹${m.subtotal.toLocaleString('en-IN')}</td>
          </tr>
        </tbody>
      </table>
      <div class="inv-totals">
        <div><span>Subtotal</span><span>₹${m.subtotal.toLocaleString('en-IN')}</span></div>
        <div><span>GST @ 5%</span><span>₹${m.gst.toLocaleString('en-IN')}</span></div>
        <div class="grand"><span>Total payable</span><span>₹${m.total.toLocaleString('en-IN')}</span></div>
      </div>
      <div class="inv-foot">
        Payment is due within 15 days of the invoice date. This is a computer-generated invoice; no signature is required.
        Queries: billing@careos.health · +91 80 4000 1200
      </div>
    </div>`;
}

function openInvoice(id) {
  const invoice = (DATA.billing || []).find(b => String(b.id) === String(id));
  if (!invoice) return;
  CURRENT_INVOICE = invoice;
  const body = document.getElementById('invoice-body');
  if (body) body.innerHTML = invoiceHtml(invoice);
  openModal('invoice-modal');
}

function printInvoiceById(id) {
  openInvoice(id);
  setTimeout(printInvoice, 220);
}

function printInvoice() {
  const invoice = CURRENT_INVOICE;
  if (!invoice) return;
  const win = window.open('', '_blank', 'width=780,height=920');
  if (!win) { showToast('Allow pop-ups to open the printable invoice.'); return; }
  win.document.write('<!doctype html><html><head><title>' + invoice.id + '</title><style>'
    + INVOICE_CSS.split('}').join('}\n') + '</style></head><body>' + invoiceHtml(invoice) + '</body></html>');
  win.document.close();
  win.focus();
  setTimeout(() => win.print(), 400);
}

function renderBillingStats() {
  const billing = DATA.billing || [];
  const billed = billing.reduce((s, b) => s + aiNumber(b.amount), 0);
  const paid = billing.filter(b => b.status === 'Paid').reduce((s, b) => s + aiNumber(b.amount), 0);
  const dueRows = billing.filter(b => b.status !== 'Paid');
  setText('bill-total', inr(billed));
  setText('bill-total-sub', billing.length + ' invoices issued');
  setText('bill-paid', inr(paid));
  setText('bill-paid-sub', billing.filter(b => b.status === 'Paid').length + ' invoices settled');
  setText('bill-due', inr(billed - paid));
  setText('bill-due-sub', dueRows.length + ' invoices awaiting payment');
}

function resetBillingFilters() {
  const s = document.getElementById('bill-search');
  const st = document.getElementById('bill-status');
  if (s) s.value = '';
  if (st) st.value = 'all';
  renderBilling();
}

function renderBilling() {
  const tbody = document.getElementById('billing-tbody');
  if (!tbody) return;
  const q = ((document.getElementById('bill-search') || {}).value || '').toLowerCase().trim();
  const status = (document.getElementById('bill-status') || {}).value || 'all';
  const statusMap = { Paid: 'badge-green', Pending: 'badge-orange', Overdue: 'badge-red' };

  let rows = (DATA.billing || []).slice();
  if (status !== 'all') rows = rows.filter(b => b.status === status);
  if (q) rows = rows.filter(b => (b.id + ' ' + b.patient + ' ' + b.doctor + ' ' + b.treatment).toLowerCase().indexOf(q) !== -1);

  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="8" style="padding:28px;text-align:center;color:var(--slate-400);font-size:12.5px">No invoices match these filters.</td></tr>';
  } else {
    tbody.innerHTML = rows.map(b => `
      <tr>
        <td><span style="font-weight:600;font-family:var(--font-mono);font-size:11.5px;color:var(--teal)">${b.id}</span></td>
        <td>
          <div style="display:flex;align-items:center;gap:8px">
            <div class="ava ava-sm">${b.patient.split(' ').map(w => w[0]).join('').slice(0, 2)}</div>
            <span style="font-weight:500">${b.patient}</span>
          </div>
        </td>
        <td style="color:var(--slate-500)">${b.date}</td>
        <td>${b.treatment}</td>
        <td style="font-size:12px;color:var(--slate-500)">${b.doctor}</td>
        <td style="font-weight:600;font-variant-numeric:tabular-nums">${inr(b.amount)}</td>
        <td><span class="badge ${statusMap[b.status]}">${b.status}</span></td>
        <td>
          <div style="display:flex;gap:4px">
            <button class="btn btn-secondary btn-sm" onclick="openInvoice('${b.id}')">View</button>
            ${b.status !== 'Paid'
              ? `<button class="btn btn-primary btn-sm" onclick="markInvoicePaid('${b.id}')">Mark paid</button>`
              : `<button class="btn btn-secondary btn-sm" onclick="printInvoiceById('${b.id}')">Print</button>`}
          </div>
        </td>
      </tr>`).join('');
  }
  renderBillingStats();
  renderDashboardStats();
}

function markInvoicePaid(id) {
  const invoice = (DATA.billing || []).find(b => String(b.id) === String(id));
  if (!invoice) return;
  if (invoice.status === 'Paid') { showToast('Invoice ' + id + ' is already paid.'); return; }
  invoice.status = 'Paid';
  renderBilling();
  renderBillingStats();
  refreshNotifications(true);
  showToast('Invoice ' + id + ' marked as paid · ' + inr(invoice.amount));
}

// ── Pharmacy stock ────────────────────────────────────────
function stockLevel(item) {
  const stock = aiNumber(item.stock);
  const reorder = aiNumber(item.reorder);
  if (stock <= 0) return 'CRITICAL';
  if (reorder > 0 && stock <= reorder * 0.5) return 'CRITICAL';
  if (reorder > 0 && stock <= reorder) return 'LOW';
  return 'OK';
}

function renderInventoryStats() {
  const items = aiInventoryRows();
  const low = items.filter(i => i.level === 'LOW').length;
  const critical = items.filter(i => i.level === 'CRITICAL').length;
  setText('inv-total', String(items.length));
  setText('inv-low', String(low));
  setText('inv-critical', String(critical));
}

function populateInventoryCategories() {
  const select = document.getElementById('inv-category');
  if (!select || select.dataset.filled === '1') return;
  const categories = [];
  (DATA.inventory || []).forEach(i => { if (categories.indexOf(i.category) === -1) categories.push(i.category); });
  categories.sort().forEach(c => {
    const opt = document.createElement('option');
    opt.value = c; opt.textContent = c;
    select.appendChild(opt);
  });
  select.dataset.filled = '1';
}

function renderInventory() {
  const tbody = document.getElementById('inventory-tbody');
  if (!tbody) return;
  populateInventoryCategories();
  const q = ((document.getElementById('inv-search') || {}).value || '').toLowerCase().trim();
  const category = (document.getElementById('inv-category') || {}).value || 'all';
  const status = (document.getElementById('inv-status') || {}).value || 'all';
  const badge = { OK: 'badge-green', LOW: 'badge-orange', CRITICAL: 'badge-red' };

  let items = aiInventoryRows();
  if (category !== 'all') items = items.filter(i => i.category === category);
  if (status !== 'all') items = items.filter(i => i.level === status);
  if (q) items = items.filter(i => i.name.toLowerCase().indexOf(q) !== -1 || i.category.toLowerCase().indexOf(q) !== -1);

  if (!items.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="padding:28px;text-align:center;color:var(--slate-400);font-size:12.5px">No medicines match these filters.</td></tr>';
  } else {
    tbody.innerHTML = items.map(item => {
      const pct = Math.max(0, Math.min(100, Math.round((item.stock / (item.maxStock || 1)) * 100)));
      const cls = item.level === 'OK' ? 'stock-ok' : item.level === 'LOW' ? 'stock-low' : 'stock-critical';
      return `
        <tr>
          <td>
            <div style="font-weight:600;font-size:13px">${item.name}</div>
            <div style="font-size:11px;color:var(--slate-400)">${item.stock} ${item.unit} on hand</div>
          </td>
          <td><span class="badge badge-blue">${item.category}</span></td>
          <td style="min-width:140px">
            <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--slate-500);margin-bottom:3px">
              <span>${item.stock} ${item.unit}</span><span>${pct}%</span>
            </div>
            <div class="stock-bar"><div class="stock-fill ${cls}" style="width:${pct}%"></div></div>
          </td>
          <td style="font-weight:600;font-variant-numeric:tabular-nums">${inr(item.price, 2)}</td>
          <td>${item.reorder} ${item.unit}</td>
          <td><span class="badge ${badge[item.level]}">${item.level}</span></td>
          <td>
            <div style="display:flex;gap:4px">
              <button class="btn btn-primary btn-sm" onclick="restockItem(${item.id})">Restock</button>
              <button class="btn btn-secondary btn-sm" onclick="showItemHistory(${item.id})">Details</button>
            </div>
          </td>
        </tr>`;
    }).join('');
  }
  renderInventoryStats();
}

function restockItem(id) {
  const item = (DATA.inventory || []).find(i => String(i.id) === String(id));
  if (!item) return;
  const target = aiNumber(item.maxStock);
  const add = Math.max(0, target - aiNumber(item.stock));
  if (!add) { showToast(item.name + ' is already at full stock.'); return; }
  item.stock = target;
  item.status = stockLevel(item);
  renderInventory();
  refreshNotifications(true);
  showToast('Restocked ' + item.name + ' · +' + add + ' ' + item.unit + ' (' + inr(add * aiNumber(item.price)) + ')');
}

function showItemHistory(id) {
  const item = aiInventoryRows().find(i => String(i.id) === String(id));
  if (!item) return;
  openModal('department-modal');
  document.getElementById('department-title').textContent = item.name;
  document.getElementById('department-body').innerHTML = `
    <div class="grid-2" style="gap:10px;margin-bottom:12px">
      <div><div class="micro">Stock on hand</div><div style="font-weight:600">${item.stock} ${item.unit}</div></div>
      <div><div class="micro">Reorder level</div><div style="font-weight:600">${item.reorder} ${item.unit}</div></div>
      <div><div class="micro">Category</div><div style="font-weight:600">${item.category}</div></div>
      <div><div class="micro">Unit price</div><div style="font-weight:600">${inr(item.price, 2)}</div></div>
      <div><div class="micro">Stock value</div><div style="font-weight:600">${inr(item.stock * item.price)}</div></div>
      <div><div class="micro">Status</div><div style="font-weight:600">${item.level}</div></div>
    </div>
    <div style="font-size:11.5px;color:var(--slate-500);line-height:1.6">
      Stock levels are recalculated from the quantity on hand against the reorder threshold on every render, so the
      status always matches the figure above.
    </div>`;
}

// ── Notifications ─────────────────────────────────────────
let NOTIFICATIONS = [];
let NOTIF_READ = new Set();
try { NOTIF_READ = new Set(JSON.parse(localStorage.getItem('careos-notif-read') || '[]')); } catch (e) { NOTIF_READ = new Set(); }

function saveNotifRead() {
  try { localStorage.setItem('careos-notif-read', JSON.stringify([...NOTIF_READ].slice(-200))); } catch (e) {}
}

function buildNotifications() {
  const items = [];
  aiInventoryRows().forEach(item => {
    if (item.level === 'OK') return;
    items.push({
      id: 'stock-' + item.id,
      kind: item.level === 'CRITICAL' ? 'critical' : 'warning',
      icon: '💊',
      title: item.name + (item.level === 'CRITICAL' ? ' is critically low' : ' is running low'),
      detail: item.stock + ' ' + item.unit + ' left · reorder at ' + item.reorder + ' · ' + item.category,
      page: 'inventory'
    });
  });
  (DATA.billing || []).forEach(b => {
    if (b.status === 'Paid') return;
    items.push({
      id: 'inv-' + b.id,
      kind: b.status === 'Overdue' ? 'critical' : 'warning',
      icon: '₹',
      title: 'Invoice ' + b.id + ' is ' + b.status.toLowerCase(),
      detail: b.patient + ' · ' + inr(b.amount) + ' · ' + b.treatment,
      page: 'billing'
    });
  });
  (DATA.appointments || []).forEach(a => {
    if (a.status !== 'Pending') return;
    items.push({
      id: 'appt-' + a.id,
      kind: 'info',
      icon: '📅',
      title: 'Appointment awaiting confirmation',
      detail: a.patient + ' with ' + a.doctor + ' at ' + a.time + ' (' + a.treatment + ')',
      page: 'appointments'
    });
  });
  aiAdmittedRows().forEach(a => {
    items.push({
      id: 'adm-' + a.id,
      kind: 'info',
      icon: '🛏️',
      title: a.patient_name + ' is in Room ' + a.room_number,
      detail: a.ward + ' · ' + a.doctor_assigned + ' · expected discharge ' + (a.expected_discharge || 'not set'),
      page: 'allotments'
    });
  });
  (DATA.messages || []).forEach(m => {
    if (!m.unread) return;
    items.push({
      id: 'msg-' + m.id,
      kind: 'info',
      icon: '✉️',
      title: m.unread + ' unread message' + (m.unread > 1 ? 's' : '') + ' from ' + m.from,
      detail: m.preview,
      page: 'messages'
    });
  });
  const order = { critical: 0, warning: 1, info: 2 };
  return items.sort((a, b) => order[a.kind] - order[b.kind]);
}

function refreshNotifications(announce) {
  const previous = new Set(NOTIFICATIONS.map(n => n.id));
  NOTIFICATIONS = buildNotifications();
  const unread = NOTIFICATIONS.filter(n => !NOTIF_READ.has(n.id));

  const count = document.getElementById('notif-count');
  const dot = document.getElementById('notif-dot');
  if (count) {
    count.hidden = unread.length === 0;
    count.textContent = unread.length > 9 ? '9+' : String(unread.length);
  }
  if (dot) dot.hidden = unread.length === 0;

  const bell = document.getElementById('notif-btn');
  if (bell) {
    bell.title = unread.length
      ? unread.length + ' unread alert' + (unread.length > 1 ? 's' : '') + ' · ' + NOTIFICATIONS[0].title
      : 'Notifications — all clear';
  }

  if (announce) {
    const fresh = NOTIFICATIONS.filter(n => !previous.has(n.id) && !NOTIF_READ.has(n.id));
    if (fresh.length === 1) {
      showToast(fresh[0].title + ' — ' + fresh[0].detail);
    } else if (fresh.length > 1) {
      showToast(fresh.length + ' new alerts — ' + fresh[0].title + '; ' + fresh[1].title);
    }
    if (fresh.length && bell) {
      bell.classList.remove('ping');
      void bell.offsetWidth;
      bell.classList.add('ping');
    }
  }
  const modal = document.getElementById('notifications-modal');
  if (modal && modal.classList.contains('open')) renderNotificationList();
}

function renderNotificationList() {
  const list = document.getElementById('notif-list');
  if (!list) return;
  const unread = NOTIFICATIONS.filter(n => !NOTIF_READ.has(n.id)).length;
  setText('notif-summary', NOTIFICATIONS.length + ' alerts · ' + unread + ' unread');
  if (!NOTIFICATIONS.length) {
    list.innerHTML = '<div class="notif-empty">Nothing needs your attention right now.</div>';
    return;
  }
  list.innerHTML = NOTIFICATIONS.map(n => {
    const read = NOTIF_READ.has(n.id);
    const tone = n.kind === 'critical' ? 'background:#FEE2E2' : n.kind === 'warning' ? 'background:#FEF3C7' : 'background:#EFF6FF';
    return `<button class="notif-row ${read ? 'read' : 'unread'}" onclick="openNotification('${n.id}')">
      <span class="ndot"></span>
      <span class="notif-ico" style="${tone}">${n.icon}</span>
      <span style="flex:1">
        <span class="notif-title" style="display:block">${n.title}</span>
        <span class="notif-detail" style="display:block">${n.detail}</span>
      </span>
    </button>`;
  }).join('');
}

function openNotificationsModal() {
  refreshNotifications(false);
  renderNotificationList();
  openModal('notifications-modal');
}

function openNotification(id) {
  const item = NOTIFICATIONS.find(n => n.id === id);
  if (!item) return;
  NOTIF_READ.add(id);
  saveNotifRead();
  refreshNotifications(false);
  renderNotificationList();
  closeModal('notifications-modal');
  navTo(item.page, null);
  if (item.page === 'billing' && item.id.indexOf('inv-') === 0) openInvoice(item.id.replace('inv-', ''));
}

function markAllNotificationsRead() {
  NOTIFICATIONS.forEach(n => NOTIF_READ.add(n.id));
  saveNotifRead();
  refreshNotifications(false);
  renderNotificationList();
  showToast('All notifications marked as read.');
}

// ── Global search ─────────────────────────────────────────
function closeSearch() {
  const box = document.getElementById('search-results');
  if (box) box.classList.remove('open');
}

function runSearch(value) {
  const box = document.getElementById('search-results');
  if (!box) return;
  const q = String(value || '').toLowerCase().trim();
  if (!q) { box.innerHTML = ''; box.classList.remove('open'); return; }

  const rows = [];
  (DATA.patients || []).filter(p => p.name.toLowerCase().indexOf(q) !== -1 || String(p.id).indexOf(q) === 0).slice(0, 4)
    .forEach(p => rows.push({ icon: '👤', title: p.name, sub: 'Patient · ID #' + p.id + ' · ' + p.age + 'y', call: `searchGoPatient(${p.id})` }));
  (DATA.doctors || []).filter(d => d.name.toLowerCase().indexOf(q) !== -1 || d.specialty.toLowerCase().indexOf(q) !== -1).slice(0, 3)
    .forEach(d => rows.push({ icon: '🩺', title: d.name, sub: 'Doctor · ' + d.specialty, call: `searchGoDoctor(${d.id})` }));
  (DATA.billing || []).filter(b => b.id.toLowerCase().indexOf(q) !== -1 || b.patient.toLowerCase().indexOf(q) !== -1).slice(0, 3)
    .forEach(b => rows.push({ icon: '₹', title: b.id + ' · ' + inr(b.amount), sub: b.patient + ' · ' + b.status, call: `searchGoInvoice('${b.id}')` }));
  aiInventoryRows().filter(i => i.name.toLowerCase().indexOf(q) !== -1).slice(0, 3)
    .forEach(i => rows.push({ icon: '💊', title: i.name, sub: i.stock + ' ' + i.unit + ' · ' + i.level, call: `searchGoMedicine('${encodeURIComponent(i.name)}')` }));

  box.innerHTML = rows.length
    ? rows.map(r => `<button class="search-row" onclick="${r.call}">
        <span class="s-ico">${r.icon}</span>
        <span style="flex:1"><span class="s-title">${r.title}</span><br><span class="s-sub">${r.sub}</span></span>
      </button>`).join('')
    : '<div class="search-empty">No patients, doctors, invoices or medicines match that search.</div>';
  box.classList.add('open');
}

function searchGoPatient(id) { closeSearch(); navTo('patients', null); showPatientDetail(id); }
function searchGoDoctor(id) { closeSearch(); navTo('doctors', null); showDocDetail(id); }
function searchGoInvoice(id) { closeSearch(); navTo('billing', null); openInvoice(id); }
function searchGoMedicine(name) {
  closeSearch(); navTo('inventory', null);
  const input = document.getElementById('inv-search');
  if (input) { input.value = decodeURIComponent(name); renderInventory(); }
}

// ── Account menu + sign out ───────────────────────────────
function toggleUserMenu(event) {
  if (event) event.stopPropagation();
  const menu = document.getElementById('user-dropdown');
  const btn = document.getElementById('user-menu-btn');
  if (!menu) return;
  const open = menu.classList.toggle('open');
  if (btn) btn.setAttribute('aria-expanded', open ? 'true' : 'false');
}

function closeUserMenu() {
  const menu = document.getElementById('user-dropdown');
  const btn = document.getElementById('user-menu-btn');
  if (menu) menu.classList.remove('open');
  if (btn) btn.setAttribute('aria-expanded', 'false');
}

// ═══════════════════════════════════════════════════════════
// ADMIN AUTHENTICATION
// Email + password sign-in. The credential is stored as a hash,
// and the session persists on this device until the user logs out.
// ═══════════════════════════════════════════════════════════
const AUTH_ACCOUNT_KEY = 'careos-admin-account';
const AUTH_SESSION_KEY = 'careos-admin-session';
const AUTH_LAST_EMAIL_KEY = 'careos-last-email';
const DEFAULT_ADMIN = {
  name: 'Srinith',
  email: 'srinithcm@gmail.com',
  role: 'Hospital Administrator',
  password: '7800'
};

function authStore(key, value) {
  try {
    if (value === undefined) return localStorage.getItem(key);
    localStorage.setItem(key, value);
  } catch (e) { return null; }
  return value;
}

function hashPassword(value) {
  if (window.crypto && window.crypto.subtle && window.TextEncoder) {
    return window.crypto.subtle
      .digest('SHA-256', new TextEncoder().encode(value))
      .then(function (buffer) {
        return Array.prototype.map.call(new Uint8Array(buffer), function (b) {
          return b.toString(16).padStart(2, '0');
        }).join('');
      })
      .catch(function () { return fallbackHash(value); });
  }
  return Promise.resolve(fallbackHash(value));
}

function fallbackHash(value) {
  let h1 = 0x811c9dc5, h2 = 0x01000193;
  for (let i = 0; i < value.length; i++) {
    h1 ^= value.charCodeAt(i); h1 = Math.imul(h1, 16777619) >>> 0;
    h2 = Math.imul(h2 ^ value.charCodeAt(i), 2246822519) >>> 0;
  }
  return 'local-' + h1.toString(16).padStart(8, '0') + h2.toString(16).padStart(8, '0');
}

function readAccount() {
  try { return JSON.parse(authStore(AUTH_ACCOUNT_KEY) || 'null'); } catch (e) { return null; }
}

function saveAccount(account) {
  authStore(AUTH_ACCOUNT_KEY, JSON.stringify(account));
}

function ensureAdminAccount() {
  const existing = readAccount();
  // Accounts saved with any other email (including the old demo login) are
  // replaced by the configured administrator, and their session is dropped.
  if (existing && existing.email && existing.hash &&
      String(existing.email).toLowerCase() === DEFAULT_ADMIN.email.toLowerCase()) {
    return Promise.resolve(existing);
  }
  try {
    localStorage.removeItem(AUTH_SESSION_KEY);
    localStorage.removeItem(AUTH_LAST_EMAIL_KEY);
  } catch (e) {}
  return hashPassword(DEFAULT_ADMIN.password).then(function (hash) {
    const account = {
      name: DEFAULT_ADMIN.name,
      email: DEFAULT_ADMIN.email,
      role: DEFAULT_ADMIN.role,
      hash: hash,
      createdAt: new Date().toISOString()
    };
    saveAccount(account);
    return account;
  });
}

function readSession() {
  try { return JSON.parse(authStore(AUTH_SESSION_KEY) || 'null'); } catch (e) { return null; }
}

function initialsOf(name) {
  return String(name || '')
    .replace(/^Dr\.?\s*/i, '')
    .split(/\s+/)
    .filter(Boolean)
    .map(function (part) { return part[0]; })
    .join('')
    .slice(0, 2)
    .toUpperCase() || 'AD';
}

function applyIdentity(user) {
  const name = user.name || DEFAULT_ADMIN.name;
  const mail = user.email || DEFAULT_ADMIN.email;
  const role = user.role || DEFAULT_ADMIN.role;
  const initials = initialsOf(name);

  const sidebarName = document.querySelector('.sidebar-user-name');
  const sidebarRole = document.querySelector('.sidebar-user-role');
  const sidebarAva = document.querySelector('.sidebar-user-ava');
  if (sidebarName) sidebarName.textContent = name;
  if (sidebarRole) sidebarRole.textContent = role;
  if (sidebarAva) sidebarAva.textContent = initials;

  const topAva = document.querySelector('.user-menu .user-ava');
  const topName = document.querySelector('.user-info .name');
  const topRole = document.querySelector('.user-info .role');
  if (topAva) topAva.textContent = initials;
  if (topName) topName.textContent = name;
  if (topRole) topRole.textContent = 'Administrator';

  const dropAva = document.querySelector('.user-dropdown-head .ava');
  const dropName = document.querySelector('.user-dropdown-name');
  const dropMail = document.querySelector('.user-dropdown-mail');
  if (dropAva) dropAva.textContent = initials;
  if (dropName) dropName.textContent = name;
  if (dropMail) dropMail.textContent = mail;
}

function authError(message) {
  const box = document.getElementById('auth-error');
  const text = document.getElementById('auth-error-text');
  if (!box || !text) return;
  text.textContent = message;
  box.classList.add('show');
  const card = document.getElementById('auth-pane-inner');
  if (card) {
    card.classList.remove('shake');
    void card.offsetWidth;
    card.classList.add('shake');
  }
  const email = document.getElementById('auth-email');
  const password = document.getElementById('auth-password');
  if (email && password) {
    const field = (email.value.trim() ? password : email);
    const wrap = document.getElementById(field === password ? 'auth-password-wrap' : 'auth-email-wrap');
    if (wrap) wrap.classList.add('has-error');
    field.focus();
  }
}

function clearAuthError() {
  const box = document.getElementById('auth-error');
  if (box) box.classList.remove('show');
  ['auth-email-wrap', 'auth-password-wrap'].forEach(function (id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('has-error');
  });
}

function togglePasswordVisibility() {
  const input = document.getElementById('auth-password');
  const button = document.getElementById('auth-eye');
  if (!input) return;
  const showing = input.type === 'text';
  input.type = showing ? 'password' : 'text';
  if (button) {
    button.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
    button.classList.toggle('is-on', !showing);
  }
  input.focus();
}

function fillDemoCredentials() {
  const email = document.getElementById('auth-email');
  const password = document.getElementById('auth-password');
  if (email) email.value = DEFAULT_ADMIN.email;
  if (password) password.value = DEFAULT_ADMIN.password;
  clearAuthError();
  if (password) password.focus();
}

// Secondary actions on the sign-in card. Social sign-in and self-service
// registration are not wired to a provider yet, so instead of dead buttons
// they explain exactly what to do.
const AUTH_HELP = {
  forgot: 'Password recovery is handled by the hospital IT desk (ext. 2200). Your session stays on this device until you log out.',
  google: 'Google sign-in is not connected in this build. Use your administrator email and password above.',
  facebook: 'Facebook sign-in is not connected in this build. Use your administrator email and password above.',
  register: 'Administrator accounts are provisioned by IT — ask them to create your CARE OS login.'
};

function authHelp(kind) {
  const note = document.getElementById('auth-provider-note');
  if (!note) return;
  note.textContent = AUTH_HELP[kind] || '';
  note.classList.add('show');
  if (kind === 'forgot' || kind === 'register') {
    const email = document.getElementById('auth-email');
    if (email && email.value) email.focus();
    else if (email) email.focus();
  }
}

function setAuthBusy(busy) {
  const submit = document.getElementById('auth-submit');
  const label = document.getElementById('auth-submit-label');
  if (!submit) return;
  submit.disabled = busy;
  if (label) label.textContent = busy ? 'Checking credentials…' : 'Login';
}

function showAuthScreen() {
  const screen = document.getElementById('auth-screen');
  if (screen) screen.classList.add('open');
  document.body.classList.add('signed-out');
  closeUserMenu();
}

function hideAuthScreen() {
  const screen = document.getElementById('auth-screen');
  if (screen) screen.classList.remove('open');
  document.body.classList.remove('signed-out');
}

function handleLogin(event) {
  if (event) event.preventDefault();
  clearAuthError();

  const emailField = document.getElementById('auth-email');
  const passwordField = document.getElementById('auth-password');
  const email = (emailField ? emailField.value : '').trim().toLowerCase();
  const password = passwordField ? passwordField.value : '';

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    authError('Enter a valid email address, for example srinithcm@gmail.com.');
    return;
  }
  if (password.length < 4) {
    authError('Your password must be at least 4 characters long.');
    return;
  }

  setAuthBusy(true);
  ensureAdminAccount().then(function (account) {
    return hashPassword(password).then(function (hash) {
      if (email !== String(account.email).toLowerCase() || hash !== account.hash) {
        setAuthBusy(false);
        authError('That email and password do not match an administrator account.');
        return;
      }
      const session = {
        email: account.email,
        name: account.name,
        role: account.role,
        signedInAt: new Date().toISOString()
      };
      authStore(AUTH_SESSION_KEY, JSON.stringify(session));
      authStore(AUTH_LAST_EMAIL_KEY, account.email);
      if (passwordField) passwordField.value = '';
      applyIdentity(account);
      setAuthBusy(false);
      hideAuthScreen();
      showToast('Signed in as ' + account.name + '.');
      const firstField = document.getElementById('ai-input');
      if (firstField && window.innerWidth > 768) firstField.blur();
    });
  }).catch(function () {
    setAuthBusy(false);
    authError('Sign in could not be completed. Please try again.');
  });
}

function signOut() {
  try { localStorage.removeItem(AUTH_SESSION_KEY); } catch (e) {}
  closeUserMenu();
  document.querySelectorAll('.modal-overlay.open').forEach(function (modal) { modal.classList.remove('open'); });
  try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) {}
  showAuthScreen();
  clearAuthError();
  const password = document.getElementById('auth-password');
  if (password) password.value = '';
  showToast('Signed out of CARE OS AI.');
}

function logout() { signOut(); }

let AUTH_READY = null;

function bootstrapAuth() {
  AUTH_READY = ensureAdminAccount().then(function (account) {
    const session = readSession();
    const valid = session && String(session.email).toLowerCase() === String(account.email).toLowerCase();
    if (valid) {
      applyIdentity(account);
      hideAuthScreen();
      return true;
    }
    applyIdentity(account);
    const emailField = document.getElementById('auth-email');
    let remembered = null;
    try { remembered = localStorage.getItem(AUTH_LAST_EMAIL_KEY); } catch (e) {}
    if (emailField) emailField.value = remembered || account.email;
    showAuthScreen();
    setTimeout(function () {
      const field = document.getElementById('auth-password');
      if (field) field.focus();
    }, 220);
    return false;
  });
  return AUTH_READY;
}

// ── Sidebar: collapse to a rail, slide the active marker ──
let navCollapsed = false;
try { navCollapsed = localStorage.getItem('careos-nav-collapsed') === '1'; } catch (e) {}

function moveNavIndicator() {
  const indicator = document.getElementById('nav-indicator');
  const active = document.querySelector('.nav-item.active');
  if (!indicator || !active) return;
  if (document.body.classList.contains('nav-collapsed') || window.innerWidth <= 768) {
    indicator.style.opacity = '0';
    return;
  }
  indicator.style.height = Math.max(24, active.offsetHeight - 6) + 'px';
  indicator.style.transform = 'translateY(' + (active.offsetTop + 3) + 'px)';
  indicator.style.opacity = '1';
}

function applyNavCollapsed() {
  const collapsed = navCollapsed && window.innerWidth > 768;
  document.body.classList.toggle('nav-collapsed', collapsed);
  const btn = document.getElementById('menuBtn');
  if (btn) btn.setAttribute('aria-label', collapsed ? 'Expand menu' : 'Collapse menu');
  document.querySelectorAll('.nav-item').forEach(item => {
    const label = item.getAttribute('data-page') || '';
    const badge = item.querySelector('.nav-badge');
    item.title = collapsed ? (label.charAt(0).toUpperCase() + label.slice(1).replace('-', ' ')) : '';
    if (badge) badge.style.display = collapsed ? 'none' : '';
  });
  moveNavIndicator();
}

function toggleSidebar() {
  if (window.innerWidth <= 768) {
    document.getElementById('sidebar').classList.toggle('open');
    return;
  }
  navCollapsed = !navCollapsed;
  try { localStorage.setItem('careos-nav-collapsed', navCollapsed ? '1' : '0'); } catch (e) {}
  applyNavCollapsed();
}

const _originalNavTo = navTo;
navTo = function (page, el) {
  if (!document.getElementById('page-' + page)) return;
  _originalNavTo(page, el);
  moveNavIndicator();
  closeSearch();
  closeUserMenu();
  if (window.innerWidth <= 768) document.getElementById('sidebar').classList.remove('open');
  if (page === 'billing') renderBilling();
  if (page === 'inventory') renderInventory();
  if (page === 'dashboard') renderDashboardStats();
};

// ── Appointments: reschedule actually moves the booking ───
function shiftDateLabel(label, days) {
  const parsed = new Date(label);
  if (isNaN(parsed)) return label;
  parsed.setDate(parsed.getDate() + days);
  const text = parsed.toLocaleDateString('en-GB', { day: '2-digit', month: 'long', year: 'numeric' });
  return text.replace(/^0/, '');
}

function rescheduleAppointment(id) {
  const appt = (DATA.appointments || []).find(a => String(a.id) === String(id));
  if (!appt) return;
  if (appt.status === 'Cancelled') { showToast('Cancelled appointments cannot be moved. Book a new slot instead.'); return; }
  appt.date = shiftDateLabel(appt.date, 1);
  appt.status = 'Confirmed';
  renderAppointments();
  refreshNotifications(false);
  showToast('Appointment #' + id + ' moved to ' + appt.date + ' at ' + appt.time);
}

function renderAppointments() {
  const tbody = document.getElementById('appt-tbody');
  if (!tbody) return;
  const search = ((document.getElementById('appt-search') || {}).value || '').toLowerCase();
  const statusColors = { Confirmed: 'badge-teal', Pending: 'badge-orange', Cancelled: 'badge-gray' };
  let list = (DATA.appointments || []).slice();
  if (typeof apptFilter === 'string' && apptFilter !== 'all') list = list.filter(a => a.status.toLowerCase() === apptFilter);
  if (search) list = list.filter(a => a.patient.toLowerCase().indexOf(search) !== -1 || a.doctor.toLowerCase().indexOf(search) !== -1);

  if (!list.length) {
    tbody.innerHTML = '<tr><td colspan="8" style="padding:28px;text-align:center;color:var(--slate-400);font-size:12.5px">No appointments match this view.</td></tr>';
    return;
  }
  tbody.innerHTML = list.map(a => `
    <tr>
      <td><input type="checkbox" onclick="event.stopPropagation()"></td>
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="ava ava-sm">${a.patient.split(' ').map(w => w[0]).join('').slice(0, 2)}</div>
          <span style="font-weight:600">${a.patient}</span>
        </div>
      </td>
      <td style="color:var(--slate-500)">${a.date}</td>
      <td>${a.time}</td>
      <td>${a.doctor}</td>
      <td><span style="color:var(--slate-500)">${a.treatment}</span></td>
      <td><span class="badge ${statusColors[a.status]}">${a.status}</span></td>
      <td>
        <div style="display:flex;gap:4px">
          ${a.status !== 'Cancelled'
            ? `<button class="btn btn-secondary btn-sm" onclick="rescheduleAppointment(${a.id})">Reschedule</button>
               <button class="btn btn-sm" style="background:var(--slate-100);color:var(--red);border:1px solid #FCA5A5" onclick="cancelAppointment(${a.id})">Cancel</button>`
            : `<span style="font-size:11.5px;color:var(--slate-400)">Closed</span>`}
        </div>
      </td>
    </tr>`).join('');
}

// ── Patients: a working edit dialog ───────────────────────
let editingPatientId = null;

function editPatient(id) {
  const patient = (DATA.patients || []).find(p => String(p.id) === String(id));
  if (!patient) return;
  editingPatientId = patient.id;
  const map = {
    'new-p-name': patient.name,
    'new-p-dob': patient.dob,
    'new-p-gender': patient.gender,
    'new-p-phone': patient.phone,
    'new-p-mem': patient.membership,
    'new-p-cond': (patient.conditions || []).join(', ')
  };
  Object.keys(map).forEach(key => {
    const el = document.getElementById(key);
    if (el) el.value = map[key] || '';
  });
  const title = document.getElementById('add-patient-title');
  if (title) title.textContent = 'Edit patient — ' + patient.name;
  openModal('add-patient-modal');
}

function submitNewPatient() {
  const name = (document.getElementById('new-p-name') || {}).value || '';
  const trimmed = name.trim();
  if (!trimmed) { showToast('Please enter the patient name.'); return; }
  const dob = (document.getElementById('new-p-dob') || {}).value || '1995-04-12';
  const gender = (document.getElementById('new-p-gender') || {}).value || 'Female';
  const phone = (document.getElementById('new-p-phone') || {}).value || '+91 90000 00000';
  const membership = (document.getElementById('new-p-mem') || {}).value || 'Blue Member';
  const conditionsRaw = (document.getElementById('new-p-cond') || {}).value || '';

  if (editingPatientId !== null) {
    const patient = DATA.patients.find(p => p.id === editingPatientId);
    if (patient) {
      patient.name = trimmed;
      patient.dob = dob;
      patient.gender = gender;
      patient.phone = phone;
      patient.membership = membership;
      patient.age = new Date().getFullYear() - parseInt(String(dob).slice(0, 4), 10);
      if (conditionsRaw.trim()) patient.conditions = conditionsRaw.split(',').map(c => c.trim()).filter(Boolean);
    }
    editingPatientId = null;
    const title = document.getElementById('add-patient-title');
    if (title) title.textContent = 'Register New Patient';
    renderPatients(DATA.patients);
    closeModal('add-patient-modal');
    showToast('Patient record updated for ' + trimmed + '.');
    refreshNotifications(false);
    return;
  }

  const newPatient = {
    id: 300 + DATA.patients.length + 1,
    name: trimmed,
    dob: dob,
    gender: gender,
    age: new Date().getFullYear() - parseInt(String(dob).slice(0, 4), 10),
    occupation: 'Patient',
    insurance: 'HealthCare Plus',
    phone: phone,
    email: trimmed.toLowerCase().replace(/\s+/g, '.') + '@careos.ai',
    address: 'Springfield, IL, USA',
    emergency: 'Family contact on file',
    status: 'Active',
    membership: membership,
    height: '5 ft 8 in',
    weight: '160 lbs',
    bmi: 24.3,
    heartRate: 72,
    bp: '120/80 mmHg',
    sugar: 92,
    cholesterol: 175,
    respiratory: 16,
    hemoglobin: 14.2,
    allergies: ['None recorded'],
    conditions: conditionsRaw.trim() ? conditionsRaw.split(',').map(c => c.trim()).filter(Boolean) : ['Under evaluation'],
    meds: ['None active'],
    notes: [{ date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }), title: 'Registration', text: 'Registered through CARE OS AI inpatient intake.' }]
  };
  DATA.patients.unshift(newPatient);
  renderPatients(DATA.patients);
  renderDashboardStats();
  closeModal('add-patient-modal');
  showToast('Patient ' + trimmed + ' registered.');
  refreshNotifications(false);
}

function renderPatients(list) {
  const tbody = document.getElementById('patients-tbody');
  if (!tbody) return;
  const rows = Array.isArray(list) ? list : DATA.patients;
  if (!rows.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="padding:28px;text-align:center;color:var(--slate-400);font-size:12.5px">No patients match this search.</td></tr>';
    return;
  }
  tbody.innerHTML = rows.map(p => `
    <tr style="cursor:pointer" onclick="showPatientDetail(${p.id})">
      <td>
        <div style="display:flex;align-items:center;gap:8px">
          <div class="ava ava-sm">${p.name.split(' ').map(w => w[0]).join('').slice(0, 2)}</div>
          <div>
            <div style="font-weight:600;font-size:13px">${p.name}</div>
            <div style="font-size:11px;color:var(--slate-400)">${p.email}</div>
          </div>
        </div>
      </td>
      <td style="font-size:12px;color:var(--slate-500);font-family:var(--font-mono)">#${p.id}</td>
      <td>${p.age}y · ${p.gender}</td>
      <td style="font-size:12px">${p.phone}</td>
      <td style="font-size:12px">${p.insurance}</td>
      <td><span class="badge ${p.status === 'Active' ? 'badge-green' : 'badge-gray'}">${p.status}</span></td>
      <td>
        <div style="display:flex;gap:4px">
          <button class="btn btn-secondary btn-sm" onclick="event.stopPropagation();showPatientDetail(${p.id})">View</button>
          <button class="btn btn-primary btn-sm" onclick="event.stopPropagation();editPatient(${p.id})">Edit</button>
        </div>
      </td>
    </tr>`).join('');
}

// ── Departments: open the roster for a card ───────────────
function showDepartment(name) {
  const doctors = (DATA.doctors || []).filter(d => d.specialty === name);
  const admitted = aiAdmittedRows().filter(a => (a.ward || '').toLowerCase().indexOf(String(name).toLowerCase().split(' ')[0]) !== -1);
  openModal('department-modal');
  document.getElementById('department-title').textContent = name;
  document.getElementById('department-body').innerHTML = `
    <div class="micro">Consultants on rota</div>
    <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:14px">
      ${doctors.length ? doctors.map(d => `
        <div style="display:flex;align-items:center;gap:9px;padding:8px 10px;border:1px solid var(--slate-200);border-radius:10px">
          <div class="ava ava-sm">${d.avatar}</div>
          <div style="flex:1">
            <div style="font-size:12.5px;font-weight:600;color:var(--navy)">${d.name}</div>
            <div style="font-size:11px;color:var(--slate-500)">${d.hours} · ${d.patients} patients</div>
          </div>
          <span class="badge ${d.status === 'Available' ? 'badge-green' : 'badge-gray'}">${d.status}</span>
        </div>`).join('') : '<div style="font-size:12px;color:var(--slate-400)">No consultant is assigned to this department yet.</div>'}
    </div>
    <div class="micro">Inpatients in this unit</div>
    <div style="font-size:12px;color:var(--slate-600);line-height:1.6">
      ${admitted.length ? admitted.map(a => a.patient_name + ' · Room ' + a.room_number).join('<br>') : 'No inpatient is currently admitted under this department.'}
    </div>`;
}

// ── Charts fed by real records, priced in rupees ──────────
function initCharts() {
  if (typeof Chart === 'undefined') return;

  const bands = { Child: 0, Adult: 0, Senior: 0 };
  (DATA.patients || []).forEach(p => {
    const age = aiNumber(p.age);
    if (age < 18) bands.Child++;
    else if (age < 60) bands.Adult++;
    else bands.Senior++;
  });
  const pCanvas = document.getElementById('patientChart');
  if (pCanvas) {
    patientChart = new Chart(pCanvas.getContext('2d'), {
      type: 'bar',
      data: {
        labels: Object.keys(bands),
        datasets: [{ label: 'Patients', data: Object.values(bands), backgroundColor: ['#0D9488', '#0B1329', '#94A3B8'], borderRadius: 6, maxBarThickness: 46 }]
      },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } }, y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: 'rgba(0,0,0,0.04)' } } } }
    });
  }

  const rCanvas = document.getElementById('revenueChart');
  if (rCanvas) {
    const days = [], billed = [], collected = [];
    (DATA.billing || []).forEach(b => { if (days.indexOf(b.date) === -1) days.push(b.date); });
    days.forEach(day => {
      let dayBilled = 0, dayPaid = 0;
      (DATA.billing || []).filter(b => b.date === day).forEach(b => {
        dayBilled += inrAmount(b.amount);
        if (b.status === 'Paid') dayPaid += inrAmount(b.amount);
      });
      billed.push(dayBilled);
      collected.push(dayPaid);
    });
    revenueChart = new Chart(rCanvas.getContext('2d'), {
      type: 'line',
      data: {
        labels: days,
        datasets: [
          { label: 'Billed', data: billed, borderColor: '#0D9488', backgroundColor: 'rgba(13,148,136,0.08)', borderWidth: 2.5, pointRadius: 3, tension: 0.35, fill: true },
          { label: 'Collected', data: collected, borderColor: '#0B1329', backgroundColor: 'rgba(11,19,41,0.04)', borderWidth: 2, pointRadius: 3, tension: 0.35, fill: true }
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } },
        scales: { x: { grid: { display: false } }, y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.04)' }, ticks: { callback: v => '₹' + (v / 1000) + 'k' } } }
      }
    });
  }

  const dCanvas = document.getElementById('deptChart');
  if (dCanvas) {
    const counts = {};
    (DATA.appointments || []).forEach(a => {
      const doc = (DATA.doctors || []).find(d => d.name === a.doctor);
      const dept = doc ? doc.specialty : 'Other';
      counts[dept] = (counts[dept] || 0) + 1;
    });
    const labels = Object.keys(counts);
    const colours = ['#0D9488', '#06B6D4', '#0B1329', '#94A3B8', '#F59E0B', '#8B5CF6', '#EF4444'];
    deptChart = new Chart(dCanvas.getContext('2d'), {
      type: 'doughnut',
      data: { labels: labels, datasets: [{ data: Object.values(counts), backgroundColor: labels.map((_, i) => colours[i % colours.length]), borderWidth: 0, hoverOffset: 6 }] },
      options: { responsive: true, cutout: '66%', plugins: { legend: { display: false } } }
    });
    const legend = document.getElementById('deptLegend');
    if (legend) {
      const total = Object.values(counts).reduce((s, n) => s + n, 0) || 1;
      legend.innerHTML = labels.map((l, i) =>
        `<div style="display:flex;align-items:center;gap:6px"><div style="width:10px;height:10px;border-radius:50%;background:${colours[i % colours.length]};flex-shrink:0"></div><span style="font-size:12px;color:var(--slate-500)">${l} · ${Math.round((counts[l] / total) * 100)}%</span></div>`
      ).join('');
    }
  }
}

function switchRevenueTab(el, range) {
  el.closest('.tabs').querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  const group = (keyFn) => {
    const totals = {};
    (DATA.billing || []).forEach(b => {
      const key = keyFn(b);
      totals[key] = (totals[key] || 0) + inrAmount(b.amount);
    });
    return totals;
  };
  const totals = range === 'month'
    ? group(b => b.status)
    : range === 'year'
      ? group(b => b.doctor)
      : group(b => b.date);
  if (!revenueChart) return;
  revenueChart.data.labels = Object.keys(totals);
  revenueChart.data.datasets[0].data = Object.values(totals);
  revenueChart.data.datasets[1].data = Object.values(totals).map(v => Math.round(v * 0.7));
  revenueChart.update();
}

// ── Emotion-synced speech ─────────────────────────────────
  const AI_EMOTION_CUES = [
  { key: 'concerned', re: /\b(concerning|monitor closely|borderline|slightly (low|high|elevated)|abnormal|follow up|needs review)\b/i },
  { key: 'reassure', re: /critical|emergency|overdue|urgent|warning|out of stock|hypotens|hypertens|risk|attention/i },
  { key: 'wave', re: /^(hello|hi\b|good morning|good afternoon|welcome)/i },
  { key: 'supportive', re: /all good|within range|normal range|no .*recorded|settled|paid|available|cleared|is on file/i },
  { key: 'explain', re: /\b(because|means|reference|range|protocol|for example|which means|guideline)\b/i }
];

function emotionForText(text) {
  const value = String(text || '');
  for (let i = 0; i < AI_EMOTION_CUES.length; i++) {
    if (AI_EMOTION_CUES[i].re.test(value)) return AI_EMOTION_CUES[i].key;
  }
  return 'happy';
}

function pickVoice() {
  if (!window.speechSynthesis) return null;
  const voices = window.speechSynthesis.getVoices();
  if (!voices.length) return null;
  const prefix = String(selectedLang).split('-')[0];
  return voices.find(v => v.lang.replace('_', '-') === selectedLang)
    || voices.find(v => v.lang.replace('_', '-').indexOf(prefix) === 0)
    || voices.find(v => /^en/i.test(v.lang))
    || voices[0];
}

function speak(text, emotion) {
  if (!window.speechSynthesis) return;
  try { window.speechSynthesis.cancel(); } catch (e) {}
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  if (!clean) return;

  const sentences = (clean.match(/[^.!?]+[.!?]*/g) || [clean]).map(s => s.trim()).filter(Boolean).slice(0, 5);
  const closingMood = emotion && emotion !== 'speak' ? emotion : 'happy';
  let index = 0;

  const speakNext = () => {
    if (index >= sentences.length) { setEmotion(closingMood, 2600); return; }
    const sentence = sentences[index++];
    const mood = emotionForText(sentence);
    const utterance = new SpeechSynthesisUtterance(sentence);
    const voice = pickVoice();
    if (voice) utterance.voice = voice;
    const profile = (typeof AI_VOICE_PROFILES !== 'undefined' && AI_VOICE_PROFILES[mood]) || AI_VOICE_PROFILES.speak;
    utterance.lang = selectedLang;
    utterance.rate = profile.rate;
    utterance.pitch = profile.pitch;
    utterance.volume = profile.volume;

    let advanced = false;
    const advance = () => {
      if (advanced) return;
      advanced = true;
      setEmotion(mood, 900);
      setTimeout(speakNext, 220);
    };
    utterance.onend = advance;
    utterance.onerror = advance;
    setTimeout(advance, 1800 + sentence.length * 95);
    try { window.speechSynthesis.speak(utterance); } catch (e) { advance(); }
  };
  setEmotion('speak');
  speakNext();
}

// ── Startup wiring ────────────────────────────────────────
function bindGlobalUi() {
  document.addEventListener('click', event => {
    if (!event.target.closest('.user-menu-wrap')) closeUserMenu();
    if (!event.target.closest('.topbar-search')) closeSearch();
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape') { closeUserMenu(); closeSearch(); }
  });

  const grid = document.getElementById('dept-grid');
  if (grid) {
    grid.addEventListener('click', event => {
      const card = event.target.closest('.dept-card, [data-dept]');
      if (!card) return;
      const heading = card.querySelector('.dept-name, .card-title, .section-title, h3');
      const label = card.getAttribute('data-dept') || (heading ? heading.textContent.trim() : '');
      if (label) showDepartment(label);
    });
  }

  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => setTimeout(moveNavIndicator, 40));
    Array.prototype.slice.call(item.childNodes).forEach(node => {
      if (node.nodeType === 3 && node.textContent.trim()) {
        const span = document.createElement('span');
        span.className = 'nav-label';
        span.textContent = node.textContent.trim();
        item.replaceChild(span, node);
      }
    });
  });

  window.addEventListener('resize', () => { applyNavCollapsed(); moveNavIndicator(); });
  setInterval(() => refreshNotifications(true), 30000);
  refreshNotifications(false);
}

(async function init() {
  // Load the database before the first render, so the screen never flashes
  // seed data that is about to be replaced.
  const boot = await Store.bootstrap();
  renderAppointments();
  renderPatients(DATA.patients);
  renderDoctors();
  renderDepartments();
  renderSchedule();
  renderBilling();
  renderInventory();
  renderMessages();
  renderAllotments();
  fetchBackendAllotments(true);
  initDashboard();
  scheduleNaturalBlink();
  setEmotion('happy');

  // Sidebar toggle is available on every screen size
  document.getElementById('menuBtn').style.display = 'flex';
  applyNavCollapsed();
  moveNavIndicator();
  bindGlobalUi();
  renderDashboardStats();
  renderInventoryStats();
  refreshNotifications(false);
  bootstrapAuth();
  if (!boot.online) {
    console.warn('[store] persistence disabled for this session');
  }
})();
