"""
CARE OS AI — Backend Server
===========================
Serves the single-page app and is the system of record for its data.

Storage layout
--------------
* ``rooms`` and ``allotments`` are normalised tables (wards, beds, admissions).
* Every other module (patients, doctors, appointments, billing, inventory,
  messages, activity) is stored in ``records`` as one JSON document per row,
  keyed by ``(collection, id)``.  The app's objects carry nested arrays
  (allergies, clinical notes, chat threads), so a document per row keeps those
  intact without a migration every time a field is added.

API
---
GET  /api/health                  → service + database status
GET  /api/bootstrap               → every collection in one round trip
GET  /api/collections/<name>      → rows of one collection
PUT  /api/collections/<name>      → replace a collection (used by the app after
                                    each edit; rows missing from the payload are
                                    deleted, so deletes persist too)
GET  /api/rooms                   → rooms with live occupancy
GET  /api/allotments              → admissions
POST /api/allotments              → admit a patient
POST /api/allotments/<id>/discharge
GET  /api/stats                   → bed occupancy summary
POST /api/ai/chat                 → SQLite-backed occupancy answers

No third-party dependencies: Python 3 standard library only.
"""

import http.server
import json
import os
import re
import sqlite3
import threading
from datetime import datetime, timezone
from urllib.parse import urlparse

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PORT = int(os.environ.get("PORT", 8080))
DB_PATH = os.path.join(BASE_DIR, "care_os.sqlite3")
STATIC_FILE = os.path.join(BASE_DIR, "index.html")

# Collections the app persists.  Order is used when seeding a fresh database.
COLLECTIONS = (
    "patients",
    "doctors",
    "appointments",
    "billing",
    "inventory",
    "messages",
    "recentActivity",
    "copilot",
)

_db_lock = threading.Lock()


def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def connect():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db():
    with _db_lock, connect() as conn:
        cur = conn.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS rooms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                room_number TEXT UNIQUE NOT NULL,
                ward TEXT NOT NULL,
                room_type TEXT NOT NULL,
                total_beds INTEGER DEFAULT 1,
                daily_rate REAL DEFAULT 150.00
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS allotments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id INTEGER,
                patient_name TEXT NOT NULL,
                room_number TEXT NOT NULL,
                bed_number TEXT NOT NULL,
                ward TEXT NOT NULL,
                admitted_date TEXT NOT NULL,
                expected_discharge TEXT,
                discharged_date TEXT,
                doctor_assigned TEXT,
                condition TEXT,
                status TEXT DEFAULT 'Admitted'
            )
            """
        )
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS records (
                collection TEXT NOT NULL,
                id TEXT NOT NULL,
                body TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (collection, id)
            )
            """
        )
        cur.execute("CREATE INDEX IF NOT EXISTS idx_records_collection ON records(collection)")
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS meta (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            )
            """
        )

        cur.execute("SELECT COUNT(*) FROM rooms")
        if cur.fetchone()[0] == 0:
            cur.executemany(
                "INSERT INTO rooms (room_number, ward, room_type, total_beds, daily_rate) VALUES (?, ?, ?, ?, ?)",
                [
                    ("101", "General Ward A", "Standard", 4, 100.0),
                    ("102", "General Ward A", "Standard", 4, 100.0),
                    ("108", "Emergency ICU", "Critical Care", 2, 450.0),
                    ("201", "Cardiology Wing", "Semi-Private", 2, 220.0),
                    ("205", "Post-Op Recovery", "Private", 1, 300.0),
                    ("301", "Pediatric Wing", "Semi-Private", 2, 180.0),
                    ("312", "Surgical Ward B", "Private", 1, 350.0),
                    ("401", "Deluxe VIP Suite", "Deluxe VIP", 1, 600.0),
                    ("402", "Deluxe VIP Suite", "Deluxe VIP", 1, 600.0),
                ],
            )

        cur.execute("SELECT COUNT(*) FROM allotments")
        if cur.fetchone()[0] == 0:
            cur.executemany(
                """
                INSERT INTO allotments (patient_id, patient_name, room_number, bed_number, ward,
                    admitted_date, expected_discharge, discharged_date, doctor_assigned, condition, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                [
                    (301, "Caren G. Simpson", "205", "Bed-A", "Post-Op Recovery", "2028-07-16",
                     "2028-07-22", None, "Dr. Petra Winsburry", "Hypertension & Asthma Observation", "Admitted"),
                    (302, "Edgar Warrow", "201", "Bed-B", "Cardiology Wing", "2028-07-18",
                     "2028-07-25", None, "Dr. Olivia Martinez", "Cardiac Arrhythmia Telemetry", "Admitted"),
                    (303, "Ocean Jane Lupre", "301", "Bed-A", "Pediatric Wing", "2028-07-19",
                     "2028-07-21", None, "Dr. Damian Sanchez", "Pediatric Asthma Care", "Admitted"),
                    (305, "Queen Lawnston", "101", "Bed-C", "General Ward A", "2028-07-10",
                     "2028-07-19", "2028-07-19", "Dr. Petra Winsburry", "Hypertension Stabilized", "Discharged"),
                ],
            )
        conn.commit()
    print(f"[db] ready at {DB_PATH}")


# ── Collection storage ────────────────────────────────────────


def collection_rows(name):
    with connect() as conn:
        cur = conn.execute(
            "SELECT body FROM records WHERE collection = ? ORDER BY rowid", (name,)
        )
        return [json.loads(r["body"]) for r in cur.fetchall()]


def replace_collection(name, rows):
    """Swap a whole collection atomically; rows not present are removed."""
    stamp = now_iso()
    with _db_lock, connect() as conn:
        cur = conn.cursor()
        cur.execute("BEGIN")
        cur.execute("DELETE FROM records WHERE collection = ?", (name,))
        payload = []
        for row in rows:
            if not isinstance(row, dict) or "id" not in row:
                continue
            payload.append((name, str(row["id"]), json.dumps(row, ensure_ascii=False), stamp))
        cur.executemany(
            "INSERT OR REPLACE INTO records (collection, id, body, updated_at) VALUES (?, ?, ?, ?)",
            payload,
        )
        conn.commit()
        return len(payload)


def bootstrap_payload():
    data = {}
    for name in COLLECTIONS:
        rows = collection_rows(name)
        if rows:
            data[name] = rows
    with connect() as conn:
        admitted = conn.execute(
            "SELECT COUNT(*) FROM allotments WHERE status = 'Admitted'"
        ).fetchone()[0]
        rooms_total = conn.execute("SELECT COUNT(*) FROM rooms").fetchone()[0]
        beds_total = conn.execute("SELECT COALESCE(SUM(total_beds), 0) FROM rooms").fetchone()[0]
    return {
        "collections": data,
        "seeded": bool(data),
        "allotments": admitted,
        "rooms": rooms_total,
        "beds": beds_total,
        "server_time": now_iso(),
    }


# ── Copilot: occupancy answers straight from SQLite ───────────

BED_WORDS = {
    "bed", "beds", "room", "rooms", "ward", "wards", "admit", "admitted",
    "admission", "admissions", "allotment", "allotments", "inpatient",
    "inpatients", "occupancy", "occupied", "vacant", "icu",
}


def ai_chat_reply(message):
    text = (message or "").lower()
    words = set(re.findall(r"[a-z0-9]+", text))
    if not words & BED_WORDS:
        return None

    with connect() as conn:
        rooms = [dict(r) for r in conn.execute(
            "SELECT room_number, ward, room_type, total_beds, daily_rate FROM rooms ORDER BY room_number"
        ).fetchall()]
        admitted = [dict(r) for r in conn.execute(
            """SELECT patient_name, room_number, bed_number, ward, doctor_assigned,
                      admitted_date, expected_discharge
               FROM allotments WHERE status = 'Admitted' ORDER BY admitted_date"""
        ).fetchall()]

    if not rooms:
        return None

    occupied = {}
    for a in admitted:
        occupied[a["room_number"]] = occupied.get(a["room_number"], 0) + 1

    total_beds = sum(int(r.get("total_beds") or 0) for r in rooms)
    occupied_beds = sum(occupied.values())
    available_beds = max(0, total_beds - occupied_beds)

    lines = [
        "🛏️ **Live room registry (SQLite)**",
        f"• Beds: **{total_beds}** in **{len(rooms)}** rooms",
        f"• Occupied: **{occupied_beds}** · Available: **{available_beds}**",
        f"• Admissions marked Admitted: **{len(admitted)}**",
    ]
    if admitted:
        lines += ["", "**Admitted patients**"]
        for a in admitted:
            lines.append(
                f"   – {a['patient_name']} · Room {a['room_number']} ({a['bed_number']}, {a['ward']})"
                f" · {a['doctor_assigned']} · admitted {a['admitted_date']}"
            )
    free = [r for r in rooms if int(r.get("total_beds") or 0) - occupied.get(r["room_number"], 0) > 0]
    if free:
        lines += ["", "**Rooms with free beds**"]
        for r in free:
            free_beds = int(r.get("total_beds") or 0) - occupied.get(r["room_number"], 0)
            lines.append(
                f"   – Room {r['room_number']} · {r['ward']} · {r['room_type']}"
                f" · {free_beds}/{int(r.get('total_beds') or 0)} free"
                f" · ₹{float(r.get('daily_rate') or 0):,.2f}/day"
            )
    return "\n".join(lines)


# ── HTTP layer ────────────────────────────────────────────────


class CareOSRequestHandler(http.server.SimpleHTTPRequestHandler):
    server_version = "CareOS/2.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=BASE_DIR, **kwargs)

    def log_message(self, fmt, *args):
        pass  # keep the console readable; errors still surface via stderr

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, PUT, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Cache-Control", "no-store")
        super().end_headers()

    # ── helpers ──
    def send_json(self, data, code=200):
        payload = json.dumps(data, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def read_body(self):
        """Read the request body.

        Reverse proxies (and fetch with keepalive) may forward the body with
        ``Transfer-Encoding: chunked`` and no Content-Length, so both framings
        have to be supported.
        """
        encoding = (self.headers.get("Transfer-Encoding") or "").lower()
        if "chunked" in encoding:
            chunks = []
            while True:
                line = self.rfile.readline().strip()
                if not line:
                    break
                size = int(line.split(b";")[0], 16)
                if size == 0:
                    self.rfile.readline()
                    break
                chunks.append(self.rfile.read(size))
                self.rfile.read(2)  # trailing CRLF
            return b"".join(chunks)
        length = int(self.headers.get("Content-Length") or 0)
        return self.rfile.read(length) if length > 0 else b""

    def read_json(self):
        try:
            raw = self.read_body()
            if not raw:
                return {}
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    # ── GET ──
    def do_GET(self):
        path = urlparse(self.path).path

        if path in ("/", "/index.html", "/app"):
            return self.serve_app()

        if path == "/api/health":
            with connect() as conn:
                rows = conn.execute("SELECT COUNT(*) FROM records").fetchone()[0]
            return self.send_json({
                "status": "ok",
                "database": DB_PATH,
                "records": rows,
                "time": now_iso(),
            })

        if path == "/api/bootstrap":
            return self.send_json(bootstrap_payload())

        if path.startswith("/api/collections/"):
            name = path.split("/")[3]
            if name not in COLLECTIONS:
                return self.send_json({"error": f"unknown collection '{name}'"}, 404)
            return self.send_json(collection_rows(name))

        if path == "/api/allotments":
            with connect() as conn:
                rows = [dict(r) for r in conn.execute("SELECT * FROM allotments ORDER BY id DESC").fetchall()]
            return self.send_json(rows)

        if path == "/api/rooms":
            with connect() as conn:
                rooms = [dict(r) for r in conn.execute("SELECT * FROM rooms ORDER BY room_number").fetchall()]
                for r in rooms:
                    occupied = conn.execute(
                        "SELECT COUNT(*) FROM allotments WHERE room_number = ? AND status = 'Admitted'",
                        (r["room_number"],),
                    ).fetchone()[0]
                    r["occupied_beds"] = occupied
                    r["available_beds"] = max(0, r["total_beds"] - occupied)
            return self.send_json(rooms)

        if path == "/api/stats":
            with connect() as conn:
                active = conn.execute("SELECT COUNT(*) FROM allotments WHERE status = 'Admitted'").fetchone()[0]
                beds = conn.execute("SELECT COALESCE(SUM(total_beds), 0) FROM rooms").fetchone()[0]
                rooms = conn.execute("SELECT COUNT(*) FROM rooms").fetchone()[0]
            return self.send_json({
                "active_admissions": active,
                "total_beds": beds,
                "available_beds": max(0, beds - active),
                "total_rooms": rooms,
                "system_status": "Operational & Synced",
                "timestamp": now_iso(),
            })

        if path.startswith("/api/"):
            return self.send_json({"error": "Endpoint not found"}, 404)

        # Static assets (css, js, images, model) fall through here.
        return super().do_GET()

    # ── PUT ──
    def do_PUT(self):
        path = urlparse(self.path).path
        if path.startswith("/api/collections/"):
            name = path.split("/")[3]
            if name not in COLLECTIONS:
                return self.send_json({"error": f"unknown collection '{name}'"}, 404)
            body = self.read_json()
            rows = body.get("rows") if isinstance(body, dict) else None
            if not isinstance(rows, list):
                return self.send_json({"error": "'rows' must be an array"}, 400)
            saved = replace_collection(name, rows)
            return self.send_json({
                "collection": name,
                "saved": saved,
                "updated_at": now_iso(),
            })
        return self.send_json({"error": "Endpoint not found"}, 404)

    # ── POST ──
    def do_POST(self):
        path = urlparse(self.path).path
        data = self.read_json()

        if path == "/api/allotments":
            patient_name = str(data.get("patient_name", "")).strip()
            room_number = str(data.get("room_number", "")).strip()
            if not patient_name or not room_number:
                return self.send_json({"error": "Patient name and room number are required"}, 400)
            with connect() as conn:
                cur = conn.cursor()
                cur.execute(
                    """
                    INSERT INTO allotments (patient_id, patient_name, room_number, bed_number, ward,
                        admitted_date, expected_discharge, doctor_assigned, condition, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Admitted')
                    """,
                    (
                        data.get("patient_id"),
                        patient_name,
                        room_number,
                        str(data.get("bed_number", "Bed-1")).strip(),
                        str(data.get("ward", "General")).strip(),
                        data.get("admitted_date") or datetime.now().strftime("%Y-%m-%d"),
                        data.get("expected_discharge", ""),
                        data.get("doctor_assigned", "Dr. Petra Winsburry"),
                        data.get("condition", "General Care"),
                    ),
                )
                new_id = cur.lastrowid
                conn.commit()
            return self.send_json({
                "success": True,
                "message": f"Room {room_number} allotted to {patient_name}",
                "allotment_id": new_id,
            }, 201)

        if path.startswith("/api/allotments/") and path.endswith("/discharge"):
            allotment_id = path.split("/")[3]
            today = datetime.now().strftime("%Y-%m-%d")
            with connect() as conn:
                conn.execute(
                    "UPDATE allotments SET status = 'Discharged', discharged_date = ? WHERE id = ?",
                    (today, allotment_id),
                )
                conn.commit()
            return self.send_json({"success": True, "message": f"Discharged on {today}"})

        if path == "/api/ai/chat":
            message = data.get("message", "") if isinstance(data, dict) else ""
            reply = ai_chat_reply(message)
            return self.send_json({
                "reply": reply,
                "source": "sqlite" if reply else "client-records",
                "timestamp": now_iso(),
            })

        return self.send_json({"error": "Endpoint not found"}, 404)

    # ── app shell ──
    def serve_app(self):
        try:
            with open(STATIC_FILE, "rb") as fh:
                page = fh.read()
        except OSError:
            self.send_json({"error": "index.html not found"}, 500)
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.end_headers()
        self.wfile.write(page)


def run():
    init_db()
    server = http.server.ThreadingHTTPServer(("0.0.0.0", PORT), CareOSRequestHandler)
    print("=" * 64)
    print(f" CARE OS AI server        http://localhost:{PORT}")
    print(f" SQLite system of record  {DB_PATH}")
    print(" API  /api/bootstrap · /api/collections/<name> · /api/allotments")
    print("=" * 64)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.server_close()


if __name__ == "__main__":
    run()
